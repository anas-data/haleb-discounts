/**
 * حلب خصومات — Cloud Functions
 * verifyOtdCode / recordTransaction / checkExpiredSubscriptions
 * Node.js 20 + TypeScript + Firebase Admin + TOTP (speakeasy)
 */
import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import * as speakeasy from 'speakeasy';
import * as crypto from 'crypto';

admin.initializeApp();
const db = admin.firestore();

const OTD_WINDOW_SECONDS = 60;

function base32Secret(raw: string): string {
  // y Cooperates with speakeasy which expects base32 secrets.
  return raw.toUpperCase().replace(/[^A-Z2-7]/g, '');
}

function verifyUserToken(secret: string, token: string, window: number): boolean {
  try {
    return speakeasy.totp.verify({
      secret: base32Secret(secret),
      encoding: 'base32',
      token,
      step: OTD_WINDOW_SECONDS,
      window: 1,
      time: window * OTD_WINDOW_SECONDS,
    });
  } catch (error) {
    functions.logger.error('TOTP verify failed', error);
    return false;
  }
}

function currentWindow(): number {
  return Math.floor(Date.now() / 1000 / OTD_WINDOW_SECONDS);
}

async function assertActiveSubscriber(userId: string) {
  const snap = await db.collection('users').doc(userId).get();
  if (!snap.exists) throw new functions.https.HttpsError('not-found', 'المستخدم غير موجود');
  const data = snap.data() as admin.firestore.DocumentData;
  if (data.role !== 'subscriber' || data.isSubscriber !== true) {
    throw new functions.https.HttpsError('permission-denied', 'العضوية غير نشطة');
  }
  const end = data.subscriptionEndDate?.toDate?.() as Date | undefined;
  if (!end || end.getTime() <= Date.now()) {
    throw new functions.https.HttpsError('permission-denied', 'انتهى الاشتراك');
  }
  if (!data.qrSecret) throw new functions.https.HttpsError('failed-precondition', 'لا يوجد سر OTD');
  return { data, end };
}

async function getMerchant(merchantId: string) {
  const snap = await db.collection('merchants').doc(merchantId).get();
  if (!snap.exists) throw new functions.https.HttpsError('not-found', 'التاجر غير موجود');
  const data = snap.data() as admin.firestore.DocumentData;
  if (data.isActive !== true) throw new functions.https.HttpsError('failed-precondition', 'التاجر غير مفعّل');
  return data;
}

async function assertMerchantCaller(context: functions.https.CallableContext, merchantId: string) {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'يلزم تسجيل الدخول');
  const merchant = await getMerchant(merchantId);
  if (merchant.ownerUid !== context.auth.uid) {
    const userDoc = await db.collection('users').doc(context.auth.uid).get();
    if (userDoc.data()?.role !== 'admin') {
      throw new functions.https.HttpsError('permission-denied', 'هذا الحساب لا يملك هذا المحل');
    }
  }
  return merchant;
}

/**
 * التحقق من كود OTD الذي يعرضه المشترك.
 * Input: { code, merchantId, branchId, userId }
 * Output: بيانات العضوية + نسبة الخصم.
 */
export const verifyOtdCode = functions
  .region('europe-west1')
  .runWith({ timeoutSeconds: 30, memory: '256MB' })
  .https.onCall(async (data, context) => {
    const { code, merchantId, branchId, userId } = data ?? {};
    if (!code || !merchantId || !userId) {
      throw new functions.https.HttpsError('invalid-argument', 'code وmerchantId وuserId مطلوبة');
    }
    await assertMerchantCaller(context, merchantId);

    const merchant = await getMerchant(merchantId);
    const branch = (merchant.branches ?? []).find((b: { branchId?: string; id?: string }) => (b.branchId ?? b.id) === branchId);
    if (!branch) throw new functions.https.HttpsError('invalid-argument', 'الفرع غير موجود');

    const { data: user } = await assertActiveSubscriber(userId);
    const window = currentWindow();
    const ok = verifyUserToken(user.qrSecret, String(code), window);
    if (!ok) {
      throw new functions.https.HttpsError('invalid-argument', 'كود OTD غير صحيح أو انتهت صلاحيته');
    }

    // منع استخدام الكود أكثر من مرة في نفس النافذة الزمنية
    const useId = `${userId}_${merchantId}_${window}`;
    const useRef = db.collection('otd_uses').doc(useId);
    await db.runTransaction(async (tx) => {
      const useSnap = await tx.get(useRef);
      if (useSnap.exists) {
        throw new functions.https.HttpsError('already-exists', 'تم استخدام هذا الكود بالفعل في الدقيقة الحالية');
      }
      tx.set(useRef, {
        userId,
        merchantId,
        branchId: branch.id ?? branchId,
        window,
        code: String(code),
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    });

    return {
      valid: true,
      user: {
        userId,
        name: user.name,
        memberId: user.memberId,
        photoUrl: user.profilePhotoUrl ?? null,
        subscriptionEndsAt: user.subscriptionEndDate?.toDate?.().toISOString?.() ?? null,
      },
      merchant: { merchantId, name: merchant.name },
      branch: { branchId: branch.id ?? branchId, name: branch.name ?? branch.nameAr ?? 'الفرع' },
      discountPercentage: merchant.discountPercentage ?? merchant.discount ?? 0,
      window,
      remainingSeconds: OTD_WINDOW_SECONDS - (Math.floor(Date.now() / 1000) % OTD_WINDOW_SECONDS),
      transactionToken: crypto.randomBytes(18).toString('hex'),
    };
  });

/**
 * تسجيل المعاملة بعد تأكيد التاجر.
 * Input: { userId, merchantId, branchId, code, amount, transactionToken }
 */
export const recordTransaction = functions
  .region('europe-west1')
  .runWith({ timeoutSeconds: 30, memory: '256MB' })
  .https.onCall(async (data, context) => {
    const { userId, merchantId, branchId, code, amount } = data ?? {};
    const parsedAmount = Number(amount);
    if (!userId || !merchantId || !code || !Number.isFinite(parsedAmount) || parsedAmount <= 0) {
      throw new functions.https.HttpsError('invalid-argument', 'بيانات المعاملة غير مكتملة');
    }
    await assertMerchantCaller(context, merchantId);
    const { data: user } = await assertActiveSubscriber(userId);
    const merchant = await getMerchant(merchantId);
    const window = currentWindow();
    if (!verifyUserToken(user.qrSecret, String(code), window)) {
      throw new functions.https.HttpsError('invalid-argument', 'انتهت صلاحية الكود — أعد توليده');
    }
    const pct = Number(merchant.discountPercentage ?? merchant.discount ?? 0);
    const discountAmount = Math.round((parsedAmount * pct) / 100);
    const transactionRef = db.collection('transactions').doc();

    await db.runTransaction(async (tx) => {
      tx.set(transactionRef, {
        transactionId: transactionRef.id,
        userId,
        userName: user.name,
        merchantId,
        merchantName: merchant.name,
        branchId: branchId ?? null,
        code: String(code),
        discountPct: pct,
        amount: parsedAmount,
        discountAmount,
        finalAmount: parsedAmount - discountAmount,
        status: 'completed',
        verifiedBy: context.auth?.uid ?? null,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });
      tx.set(
        db.collection('users').doc(userId),
        {
          totalSavings: admin.firestore.FieldValue.increment(discountAmount),
          totalVisits: admin.firestore.FieldValue.increment(1),
          lastDiscountAt: admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true },
      );
      tx.set(
        db.collection('merchants').doc(merchantId),
        {
          totalScans: admin.firestore.FieldValue.increment(1),
          totalDiscountGiven: admin.firestore.FieldValue.increment(discountAmount),
        },
        { merge: true },
      );
    });

    return {
      transactionId: transactionRef.id,
      amount: parsedAmount,
      discountPercentage: pct,
      discountAmount,
      finalAmount: parsedAmount - discountAmount,
    };
  });

/**
 * إيقاف الاشتراكات المنتهية يومياً (00:05 بتوقيت دمشق).
 */
export const checkExpiredSubscriptions = functions
  .region('europe-west1')
  .pubsub.schedule('5 0 * * *')
  .timeZone('Asia/Damascus')
  .onRun(async () => {
    const now = admin.firestore.Timestamp.now();
    const expired = await db
      .collection('users')
      .where('role', '==', 'subscriber')
      .where('isSubscriber', '==', true)
      .where('subscriptionEndDate', '<=', now)
      .get();

    if (expired.empty) {
      functions.logger.info('No expired subscriptions today');
      return null;
    }

    const batch = db.batch();
    expired.forEach((doc) => {
      batch.update(doc.ref, {
        isSubscriber: false,
        lastExpiredAt: admin.firestore.FieldValue.serverTimestamp(),
      });
      batch.set(db.collection('audit_logs').doc(), {
        type: 'SUBSCRIPTION_EXPIRED',
        userId: doc.id,
        at: admin.firestore.FieldValue.serverTimestamp(),
      });
    });
    await batch.commit();
    functions.logger.info(`Expired ${expired.size} subscriptions`);
    return null;
  });

/**
 * منح دور Admin/Trader يدوياً فقط بواسطة مدير.
 * يُستدعى من لوحة الإدارة ولا يُسمح بالنداء الذاتي للترقية.
 */
export const setUserRole = functions
  .region('europe-west1')
  .https.onCall(async (data, context) => {
    if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'يلزم تسجيل الدخول');
    const caller = await db.collection('users').doc(context.auth.uid).get();
    if (caller.data()?.role !== 'admin') {
      throw new functions.https.HttpsError('permission-denied', 'مدير المنصة فقط');
    }
    const { userId, role } = data ?? {};
    if (!['subscriber', 'merchant', 'admin'].includes(role)) {
      throw new functions.https.HttpsError('invalid-argument', 'دور غير معروف');
    }
    await db.collection('users').doc(userId).update({ role });
    await admin.auth().setCustomUserClaims(userId, { role });
    await db.collection('audit_logs').add({
      type: 'ROLE_CHANGED',
      userId,
      role,
      by: context.auth.uid,
      at: admin.firestore.FieldValue.serverTimestamp(),
    });
    return { ok: true };
  });
