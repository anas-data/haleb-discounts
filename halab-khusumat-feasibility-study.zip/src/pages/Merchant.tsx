import { useEffect, useMemo, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import {
  ArrowRight, BadgeCheck, CalendarDays, Check, Clock3, Copy, Gift, Info, Lock,
  MapPin, Phone, QrCode, ScanLine, ShieldCheck, Sparkles, Star, Store, Timer, UserCheck, Users, X,
} from 'lucide-react';
import { useStore } from '../app/store';
import { formatDate, isActiveSubscriber, remainingSeconds, subscriptionDaysLeft, totpCode } from '../app/logic';
import { Badge, Button, Card, EmptyState } from '../components/ui';

const REVIEW_SAMPLES = [
  { name: 'محمد ح.', rate: 5, text: 'الخدمة ممتازة والخصم مطبق بدون أي نقاش. تجربة سلسة جداً.', days: 3 },
  { name: 'رنا ع.', rate: 5, text: 'أول مرة أستخدم التطبيق، الكود ظهر بسرعة وأمين الصندوق مسحه مباشرة.', days: 8 },
  { name: 'خالد س.', rate: 4, text: 'جودة الطعام رائعة، أتمنى إضافة فروع أكثر في المدينة.', days: 14 },
];

export function MerchantDetailsPage() {
  const { merchants, params, currentUser, navigate, notify } = useStore();
  const merchant = merchants.find((m) => m.id === params.merchantId) ?? merchants[0];
  const [branchId, setBranchId] = useState(merchant?.branches[0]?.id ?? '');
  const [tab, setTab] = useState<'branches' | 'about' | 'reviews'>('branches');
  const active = isActiveSubscriber(currentUser);

  useEffect(() => {
    if (merchant && !merchant.branches.some((b) => b.id === branchId)) {
      setBranchId(merchant.branches[0]?.id ?? '');
    }
  }, [merchant, branchId]);

  const selectedBranch = useMemo(
    () => merchant?.branches.find((b) => b.id === branchId) ?? merchant?.branches[0],
    [merchant, branchId],
  );

  if (!merchant) return <EmptyState title="المحل غير موجود" text="اختر شريكاً آخر من الصفحة الرئيسية." />;

  const startDiscount = () => {
    if (!active) {
      navigate(currentUser ? 'subscription' : 'register');
      return;
    }
    navigate('otd', { merchantId: merchant.id, branchId: selectedBranch?.id });
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      <button onClick={() => navigate('home')} className="mb-4 flex items-center gap-1.5 text-xs font-bold text-[#6C7A87] hover:text-[#0E2233]">
        <ArrowRight className="h-4 w-4" /> العودة إلى الشركاء
      </button>

      <section className={`relative overflow-hidden rounded-[1.5rem] bg-gradient-to-l ${merchant.gradient} p-6 text-white sm:p-8`}>
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 25% 20%, #fff 0, transparent 40%)' }} />
        <div className="relative flex flex-wrap items-start justify-between gap-5">
          <div className="flex items-start gap-4">
            <span className="grid h-16 w-16 place-items-center rounded-2xl bg-white/15 text-4xl backdrop-blur">{merchant.emoji}</span>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                {merchant.featured && <Badge tone="gold" className="!border-white/20 !bg-white/90 !text-[#8A6515]"><Sparkles className="h-3 w-3" /> شريك مميز</Badge>}
                <Badge tone="teal" className="!border-white/20 !bg-white/15 !text-white"><BadgeCheck className="h-3 w-3" /> موثّق</Badge>
                {!merchant.active && <Badge tone="red" className="!bg-white/90">غير مفعّل حالياً</Badge>}
              </div>
              <h1 className="mt-2 text-2xl font-extrabold sm:text-3xl" style={{ fontFamily: 'Cairo, sans-serif' }}>{merchant.name}</h1>
              <p className="mt-1 flex flex-wrap items-center gap-3 text-[11px] text-white/75">
                <span className="flex items-center gap-1"><Star className="h-3.5 w-3.5 fill-[#F2D59B] text-[#F2D59B]" /> {merchant.rating} ({merchant.reviews} تقييم)</span>
                <span className="flex items-center gap-1"><Store className="h-3.5 w-3.5" /> {merchant.categoryLabel}</span>
                <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> {merchant.branches.length} فروع في حلب</span>
              </p>
            </div>
          </div>
          <div className="rounded-2xl border border-white/15 bg-white/10 px-5 py-4 backdrop-blur">
            <p className="text-[10px] text-white/60">خصم أعضاء حلب خصومات</p>
            <p className="mt-1 text-4xl font-extrabold" style={{ fontFamily: 'Cairo, sans-serif' }}>
              {active ? `${merchant.discount}%` : '؟'}
            </p>
            <p className="mt-1 text-[10px] text-white/60">{active ? 'على كامل الفاتورة' : 'يظهر بعد الاشتراك'}</p>
          </div>
        </div>
      </section>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1.5fr_0.8fr]">
        <div className="space-y-4">
          <Card className="p-5">
            <p className="text-sm leading-7 text-[#4A5A68]">{merchant.description}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Badge tone="ink"><Clock3 className="h-3 w-3" /> {merchant.branches[0]?.hours}</Badge>
              <Badge tone="outline"><Phone className="h-3 w-3" /> {merchant.branches[0]?.phone}</Badge>
              <Badge tone="outline"><Store className="h-3 w-3" /> {merchant.categoryLabel}</Badge>
            </div>
          </Card>

          <Card className="overflow-hidden">
            <div className="flex border-b border-[#EDE4D6]">
              {[
                { id: 'branches' as const, label: 'الفروع وساعات العمل', icon: <MapPin className="h-4 w-4" /> },
                { id: 'about' as const, label: 'عن الشريك', icon: <Info className="h-4 w-4" /> },
                { id: 'reviews' as const, label: 'التقييمات', icon: <Star className="h-4 w-4" /> },
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={`flex flex-1 items-center justify-center gap-1.5 px-3 py-3 text-[11px] font-bold transition ${tab === t.id ? 'border-b-2 border-[#0F766E] bg-[#F5FAF8] text-[#0F766E]' : 'text-[#7B8794] hover:bg-[#FCFAF6]'}`}
                >
                  {t.icon} {t.label}
                </button>
              ))}
            </div>
            <div className="p-4">
              {tab === 'branches' && (
                <div className="space-y-2.5">
                  {merchant.branches.map((b) => (
                    <button
                      key={b.id}
                      onClick={() => setBranchId(b.id)}
                      className={`w-full rounded-xl border p-3.5 text-right transition ${branchId === b.id ? 'border-[#0F766E] bg-[#F2FAF8]' : 'border-[#EDE4D6] hover:border-[#CFC5B4]'}`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="flex items-center gap-1.5 text-xs font-extrabold text-[#0E2233]"><MapPin className="h-3.5 w-3.5 text-[#0F766E]" /> {b.name}</p>
                          <p className="mt-1 text-[11px] text-[#6C7A87]">{b.address}</p>
                          <p className="mt-1 flex items-center gap-1 text-[10px] text-[#98A4AE]"><Clock3 className="h-3 w-3" /> {b.hours} · <Phone className="h-3 w-3" /> {b.phone}</p>
                        </div>
                        <span className={`mt-0.5 grid h-5 w-5 place-items-center rounded-full border ${branchId === b.id ? 'border-[#0F766E] bg-[#0F766E] text-white' : 'border-[#CFC5B4]'}`}>
                          {branchId === b.id && <Check className="h-3 w-3" />}
                        </span>
                      </div>
                    </button>
                  ))}
                  <div className="flex items-center justify-between rounded-xl bg-[#FBF7F0] p-3 text-[10px] text-[#7B8794]">
                    <span className="flex items-center gap-1"><Users className="h-3 w-3" /> اختر الفرع قبل توليد كود OTD</span>
                    <button onClick={() => notify('الموقع على الخريطة سيفتح في التطبيق الأصلي', 'info')} className="font-bold text-[#0F766E]">عرض الخريطة</button>
                  </div>
                </div>
              )}
              {tab === 'about' && (
                <div className="space-y-3">
                  <p className="text-xs leading-7 text-[#4A5A68]">{merchant.description} يقدّم الشريك خدماته وفق شروط العضوية، مع الالتزام الكامل بتطبيق نسبة الخصم المعلنة على كامل الفاتورة.</p>
                  <div className="grid gap-2 sm:grid-cols-2">
                    {['الخصم ساري طوال فترة الاشتراك', 'لا يشمل العروض الأخرى المتزامنة', 'يُطبق عبر كود OTD فقط', 'الدعم متاح عبر خدمة العملاء'].map((x) => (
                      <span key={x} className="flex items-start gap-1.5 rounded-lg bg-[#FCFAF6] p-2 text-[10px] text-[#5B6B79]"><Check className="mt-0.5 h-3 w-3 shrink-0 text-[#0F766E]" /> {x}</span>
                    ))}
                  </div>
                </div>
              )}
              {tab === 'reviews' && (
                <div className="space-y-3">
                  <div className="flex items-center gap-3 rounded-xl bg-[#FBF7F0] p-3">
                    <div className="text-center">
                      <p className="text-3xl font-extrabold text-[#0E2233]">{merchant.rating}</p>
                      <div className="flex gap-0.5">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className={`h-3 w-3 ${i < Math.round(merchant.rating) ? 'fill-[#E9B949] text-[#E9B949]' : 'text-[#DCD3C4]'}`} />)}</div>
                      <p className="mt-1 text-[9px] text-[#98A4AE]">{merchant.reviews} تقييم</p>
                    </div>
                    <p className="text-[11px] leading-6 text-[#6C7A87]">تقييم الشركاء يعتمد على تجارب الأعضاء الحقيقية بعد استخدام كود OTD، لضمان شفافية العروض.</p>
                  </div>
                  {REVIEW_SAMPLES.map((r) => (
                    <div key={r.name} className="rounded-xl border border-[#EDE4D6] p-3">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-bold text-[#0E2233]">{r.name}</p>
                        <div className="flex gap-0.5">{Array.from({ length: r.rate }).map((_, i) => <Star key={i} className="h-3 w-3 fill-[#E9B949] text-[#E9B949]" />)}</div>
                      </div>
                      <p className="mt-1 text-[11px] text-[#6C7A87]">{r.text}</p>
                      <p className="mt-1 text-[9px] text-[#A9B2BA]">قبل {r.days} أيام</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          {active ? (
            <Card className="overflow-hidden border-[#C7E7E1]">
              <div className="bg-gradient-to-l from-[#0F766E] to-[#115E59] p-4 text-white">
                <p className="flex items-center gap-1.5 text-[10px] text-white/70"><Gift className="h-3.5 w-3.5" /> ميزة العضوية النشطة</p>
                <p className="mt-1 text-3xl font-extrabold" style={{ fontFamily: 'Cairo, sans-serif' }}>خصم {merchant.discount}%</p>
                <p className="text-[11px] text-white/70">على كامل الفاتورة · بدون حد أقصى للاستخدام</p>
              </div>
              <div className="p-4">
                <div className="mb-3 rounded-xl bg-[#F2FAF8] p-2.5 text-[10px] text-[#0F5F59]">
                  <span className="flex items-center gap-1 font-bold"><ShieldCheck className="h-3.5 w-3.5" /> الفرع المحدد: {selectedBranch?.name}</span>
                </div>
                <Button full size="lg" icon={<QrCode className="h-5 w-5" />} onClick={startDiscount}>الحصول على الخصم</Button>
                <p className="mt-2 text-center text-[10px] text-[#98A4AE]">يولّد نظام OTD كوداً صالحاً 60 ثانية</p>
                <div className="mt-3 flex items-center justify-between rounded-lg border border-[#EDE4D6] p-2.5 text-[10px]">
                  <span className="flex items-center gap-1 text-[#7B8794]"><CalendarDays className="h-3.5 w-3.5" /> صالح حتى {formatDate(currentUser?.subscriptionEndDate)}</span>
                  <Badge tone="green">{subscriptionDaysLeft(currentUser)} يوم</Badge>
                </div>
              </div>
            </Card>
          ) : (
            <Card className="overflow-hidden border-[#F0E1BC]">
              <div className="bg-gradient-to-l from-[#FBF3DF] to-[#FCEAE6] p-4">
                <p className="flex items-center gap-1.5 text-[10px] font-bold text-[#8A6515]"><Lock className="h-3.5 w-3.5" /> الخصم محجوب في الوضع المجاني</p>
                <p className="mt-2 text-3xl font-extrabold text-[#5C4412]" style={{ fontFamily: 'Cairo, sans-serif' }}>خصم ؟</p>
                <p className="text-[11px] text-[#8A7433]">نسبة هذا الشريك تظهر بعد الاشتراك</p>
              </div>
              <div className="p-4">
                <ul className="mb-4 space-y-2">
                  {['خصم دائم بين 15% و30%', 'بطاقة عضوية رقمية مع QR', 'هدية ترحيبية فورية', 'كود OTD لمرة واحدة'].map((x) => (
                    <li key={x} className="flex items-center gap-2 text-[11px] text-[#4A5A68]"><Check className="h-3.5 w-3.5 text-[#0F766E]" /> {x}</li>
                  ))}
                </ul>
                <Button full size="lg" variant="gold" onClick={() => navigate(currentUser ? 'subscription' : 'register')} icon={<Sparkles className="h-4 w-4" />}>
                  اشترك الآن للاستفادة
                </Button>
                <button onClick={() => navigate('home')} className="mt-2 w-full text-center text-[10px] font-bold text-[#7B8794]">متابعة التصفح في الوضع المجاني</button>
              </div>
            </Card>
          )}

          <Card className="p-4">
            <p className="mb-2 flex items-center gap-1.5 text-xs font-extrabold text-[#0E2233]"><ShieldCheck className="h-4 w-4 text-[#0F766E]" /> كيف يعمل الخصم؟</p>
            <ol className="space-y-2.5">
              {['اضغط «الحصول على الخصم» بعد اختيار الفرع', 'أظهر كود OTD لأمين الصندوق قبل الدفع', 'يمسح الموظف الكود ويتحقق من العضوية', 'يُطبّق الخصم وتُسجّل العملية في حسابك'].map((s, i) => (
                <li key={s} className="flex items-start gap-2 text-[11px] text-[#5B6B79]">
                  <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[#E7F4F1] text-[10px] font-extrabold text-[#0F766E]">{i + 1}</span> {s}
                </li>
              ))}
            </ol>
          </Card>

          {!active && (
            <div className="rounded-2xl border border-[#E9E1D3] bg-white p-4 text-center">
              <p className="text-[10px] text-[#98A4AE]">أنت تتصفح كـ</p>
              <p className="mt-0.5 text-xs font-extrabold text-[#0E2233]">{currentUser ? currentUser.name : 'زائر غير مسجل'}</p>
              {!currentUser && <Button variant="outline" size="sm" className="mt-2" full onClick={() => navigate('register')}>إنشاء حساب مجاني</Button>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function OtdPage() {
  const { merchants, params, currentUser, navigate, notify } = useStore();
  const merchant = merchants.find((m) => m.id === params.merchantId) ?? merchants[0];
  const branch = merchant?.branches.find((b) => b.id === params.branchId) ?? merchant?.branches[0];
  const [now, setNow] = useState(Date.now());
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const active = isActiveSubscriber(currentUser);
  const remaining = remainingSeconds(now);
  const code = useMemo(
    () => (currentUser && merchant ? totpCode(currentUser.qrSecret, merchant.id, now) : '------'),
    [currentUser, merchant, now],
  );
  const progress = (remaining / 60) * 100;
  const danger = remaining <= 10;

  if (!active || !currentUser) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16">
        <EmptyState title="الخصم متاح للمشتركين" text="اشترك في حلب خصومات لتفعيل بطاقة العضوية الرقمية وأكواد OTD." icon={<Lock className="h-5 w-5" />} />
        <div className="mt-4 text-center"><Button onClick={() => navigate('subscription')}>عرض باقات الاشتراك</Button></div>
      </div>
    );
  }

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      notify('تم نسخ كود OTD');
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      notify('تعذر النسخ، استخدم QR مباشرة', 'error');
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-6 sm:px-6">
      <div className="mb-4 flex items-center justify-between">
        <button onClick={() => navigate('merchant', { merchantId: merchant.id })} className="flex items-center gap-1.5 text-xs font-bold text-[#6C7A87] hover:text-[#0E2233]">
          <ArrowRight className="h-4 w-4" /> العودة إلى {merchant.name}
        </button>
        <Badge tone="green"><ShieldCheck className="h-3 w-3" /> اتصال آمن · عضوية نشطة</Badge>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
        <Card className="overflow-hidden">
          <div className={`bg-gradient-to-l ${merchant.gradient} px-5 py-4 text-white`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] text-white/70">كود الخصم لمرة واحدة — OTD</p>
                <p className="mt-1 text-xl font-extrabold" style={{ fontFamily: 'Cairo, sans-serif' }}>{merchant.name}</p>
                <p className="mt-0.5 text-[11px] text-white/75">{branch?.name} · {branch?.address}</p>
              </div>
              <div className="rounded-xl bg-white/15 px-4 py-2 text-center backdrop-blur">
                <p className="text-[9px] text-white/70">الخصم</p>
                <p className="text-2xl font-extrabold">{merchant.discount}%</p>
              </div>
            </div>
          </div>

          <div className="p-5">
            <div className="mx-auto max-w-[280px] rounded-2xl border border-[#EDE4D6] bg-white p-4 shadow-sm">
              <div className="flex justify-center rounded-xl bg-white p-2">
                <QRCodeSVG
                  value={`halab-discounts://redeem/${code}?m=${merchant.id}&b=${branch?.id ?? ''}`}
                  size={210}
                  bgColor="#ffffff"
                  fgColor="#0E2233"
                  level="M"
                  marginSize={1}
                />
              </div>
              <div className="mt-3 text-center">
                <p className="text-[10px] text-[#98A4AE]">الكود الرقمي</p>
                <p className={`mt-1 font-mono text-3xl font-extrabold tracking-[0.25em] ${danger ? 'text-red-600' : 'text-[#0E2233]'}`} dir="ltr">{code}</p>
                <button onClick={copy} className="mt-2 inline-flex items-center gap-1.5 rounded-lg border border-[#E4DCCD] px-3 py-1.5 text-[10px] font-bold text-[#0F766E] hover:bg-[#F2FAF8]">
                  {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />} {copied ? 'تم النسخ' : 'نسخ الكود'}
                </button>
              </div>
            </div>

            <div className={`mt-5 rounded-2xl border p-4 ${danger ? 'border-red-200 bg-red-50' : 'border-[#C7E7E1] bg-[#F2FAF8]'}`}>
              <div className="flex items-center justify-between">
                <span className={`flex items-center gap-1.5 text-xs font-extrabold ${danger ? 'text-red-700' : 'text-[#0F5F59]'}`}>
                  <Timer className="h-4 w-4" /> {danger ? 'الكود على وشك الانتهاء' : 'صلاحية الكود'}
                </span>
                <span className={`font-mono text-2xl font-extrabold ${danger ? 'text-red-600' : 'text-[#0F766E]'}`}>{remaining}<span className="text-xs"> ثانية</span></span>
              </div>
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-white">
                <div className={`h-full rounded-full transition-all duration-1000 ${danger ? 'bg-red-500' : 'bg-gradient-to-l from-[#0F766E] to-[#34D399]'}`} style={{ width: `${progress}%` }} />
              </div>
              <p className={`mt-2 text-[10px] ${danger ? 'text-red-600' : 'text-[#4E7A75]'}`}>
                يتجدد الكود تلقائياً كل 60 ثانية. إذا انتهى قبل المسح، اطلب من الموظف إعادة المحاولة بالكود الجديد.
              </p>
            </div>

            <Button full size="lg" className="mt-3" onClick={() => navigate('profile')} icon={<UserCheck className="h-4 w-4" />}>تم استخدام الخصم؟ اعرض سجلك</Button>
          </div>
        </Card>

        <div className="space-y-4">
          <Card className="p-4">
            <p className="flex items-center gap-1.5 text-xs font-extrabold text-[#0E2233]"><ScanLine className="h-4 w-4 text-[#0F766E]" /> بطاقة العضوية الرقمية</p>
            <div className="mt-3 rounded-xl bg-[#0E2233] p-3.5 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[9px] text-white/50">الاسم</p>
                  <p className="text-sm font-extrabold">{currentUser.name}</p>
                </div>
                <div className="rounded-lg bg-white p-1"><QRCodeSVG value={currentUser.memberId} size={38} fgColor="#0E2233" /></div>
              </div>
              <div className="mt-2 flex items-center justify-between border-t border-white/10 pt-2">
                <span className="font-mono text-[10px] text-[#F2D59B]" dir="ltr">{currentUser.memberId}</span>
                <span className="text-[9px] text-white/50">{subscriptionDaysLeft(currentUser)} يوم متبقٍ</span>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <p className="flex items-center gap-1.5 text-xs font-extrabold text-[#0E2233]"><ShieldCheck className="h-4 w-4 text-[#0F766E]" /> حماية من التلاعب</p>
            <ul className="mt-2 space-y-2">
              {[
                'الكود صالح لمرة واحدة فقط لكل فرع.',
                'ينتهي تلقائياً بعد 60 ثانية من توليده.',
                'لا يعمل عبر لقطة شاشة قديمة — النظام يستخدم التوقيت الحالي.',
                'يتم أرشفة كل عملية في سجل المعاملات.',
              ].map((s) => (
                <li key={s} className="flex items-start gap-1.5 text-[10px] leading-5 text-[#6C7A87]"><Check className="mt-0.5 h-3 w-3 shrink-0 text-[#0F766E]" /> {s}</li>
              ))}
            </ul>
          </Card>

          <div className="rounded-xl border border-[#F0E1BC] bg-[#FBF3DF] p-3">
            <p className="flex items-center gap-1.5 text-[10px] font-extrabold text-[#8A6515]"><Info className="h-3.5 w-3.5" /> للتحقق من المسح</p>
            <p className="mt-1 text-[10px] leading-5 text-[#8A7433]">
              سجّل الخروج ثم ادخل بحساب التاجر <b dir="ltr" className="font-mono">merchant@halab.com</b> بكلمة <b dir="ltr" className="font-mono">merchant123</b>، وافتح شاشة المسح وأدخل الكود الظاهر هنا.
            </p>
          </div>

          <Button variant="outline" full onClick={() => navigate('home')} icon={<X className="h-4 w-4" />}>إنهاء والعودة للرئيسية</Button>
        </div>
      </div>
    </div>
  );
}
