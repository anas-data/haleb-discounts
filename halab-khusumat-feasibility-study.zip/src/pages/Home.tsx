import { useMemo, useState } from 'react';
import {
  ArrowLeft, BadgeCheck, Building2, CalendarDays, ChevronLeft, Clock3, Crown, Eye, Flame, Gift,
  Lock, MapPin, Megaphone, Percent, QrCode, Search, ShieldCheck, Sparkles, Star, Store, Ticket, TrendingUp, Users,
} from 'lucide-react';
import { CATEGORIES } from '../app/data';
import type { Merchant } from '../app/data';
import { useStore } from '../app/store';
import { formatNumber, isActiveSubscriber, subscriptionDaysLeft, visibleDiscount } from '../app/logic';
import { Badge, Button, Card, SectionTitle } from '../components/ui';

export function MerchantCard({ merchant }: { merchant: Merchant }) {
  const { currentUser, navigate } = useStore();
  const active = isActiveSubscriber(currentUser);
  return (
    <Card hover className="group overflow-hidden">
      <button onClick={() => navigate('merchant', { merchantId: merchant.id })} className="block w-full text-right">
        <div className={`relative h-24 bg-gradient-to-br ${merchant.gradient}`}>
          <div className="absolute inset-0 opacity-25" style={{ backgroundImage: 'radial-gradient(circle at 20% 30%, #fff 0, transparent 35%), radial-gradient(circle at 80% 70%, #fff 0, transparent 30%)' }} />
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-4xl drop-shadow">{merchant.emoji}</span>
          <div className="absolute left-3 top-3 flex gap-1.5">
            {merchant.featured && <Badge tone="gold" className="!bg-white/95 !text-[#8A6515]">مميز</Badge>}
            {!merchant.active && <Badge tone="red" className="!bg-white/95">موقوف</Badge>}
          </div>
          <div className="absolute bottom-2 right-4">
            <p className="text-sm font-extrabold text-white drop-shadow" style={{ fontFamily: 'Cairo, sans-serif' }}>{merchant.name}</p>
            <p className="text-[10px] text-white/80">{merchant.categoryLabel}</p>
          </div>
        </div>
        <div className="p-3.5">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1 text-[11px] text-[#7B8794]">
              <Star className="h-3.5 w-3.5 fill-[#E9B949] text-[#E9B949]" /> {merchant.rating}
              <span className="text-[#B4BEC6]">({merchant.reviews})</span>
            </span>
            {active ? (
              <Badge tone="teal"><Percent className="h-3 w-3" /> خصم {visibleDiscount(currentUser, merchant)}</Badge>
            ) : (
              <Badge tone="sand"><Lock className="h-3 w-3" /> خصم {visibleDiscount(currentUser, merchant)}</Badge>
            )}
          </div>
          <div className="mt-2.5 flex items-center justify-between border-t border-[#F3EEE4] pt-2.5">
            <span className="flex items-center gap-1 text-[10px] text-[#98A4AE]"><MapPin className="h-3 w-3" /> {merchant.branches.length} فرع · حلب</span>
            <span className="flex items-center gap-0.5 text-[11px] font-bold text-[#0F766E] transition group-hover:-translate-x-1">
              {active ? 'احصل على الخصم' : 'عرض التفاصيل'} <ChevronLeft className="h-3.5 w-3.5" />
            </span>
          </div>
        </div>
      </button>
    </Card>
  );
}

export function HomePage() {
  const { currentUser, merchants, transactions, navigate, role } = useStore();
  const active = isActiveSubscriber(currentUser);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('all');
  const [onlyActive] = useState(true);

  const displayed = useMemo(() => {
    return merchants
      .filter((m) => (!onlyActive ? true : m.active))
      .filter((m) => (category === 'all' ? true : m.category === category))
      .filter((m) => (query.trim() ? `${m.name} ${m.categoryLabel} ${m.branches.map((b) => b.address).join(' ')}`.includes(query.trim()) : true));
  }, [merchants, category, query, onlyActive]);

  const ads = merchants.filter((m) => m.ad && m.active).slice(0, 2);
  const featured = merchants.filter((m) => m.featured && m.active).slice(0, 3);
  const myTxns = transactions.filter((t) => t.userId === currentUser?.uid);
  const nearby = merchants.find((m) => m.id === 'm1');

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      {!active && (
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#F0E1BC] bg-gradient-to-l from-[#FBF3DF] to-[#FDF9EF] px-4 py-3">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-white text-[#A57C1B] shadow-sm"><Eye className="h-4 w-4" /></span>
            <div>
              <p className="text-xs font-extrabold text-[#5C4412]">أنت الآن في الوضع المجاني</p>
              <p className="text-[10px] text-[#8A7433]">أسماء المحلات ظاهرة، لكن نسب الخصم وأكواد OTD متاحة للمشتركين فقط.</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="ghost" onClick={() => navigate(currentUser ? 'home' : 'welcome')}>{currentUser ? 'متابعة التصفح' : 'تسجيل الدخول'}</Button>
            <Button size="sm" variant="gold" onClick={() => navigate('subscription')}>اشترك الآن</Button>
          </div>
        </div>
      )}

      <section className="relative overflow-hidden rounded-[1.75rem] bg-[#0E2233] p-6 text-white sm:p-8">
        <div className="absolute inset-0 opacity-25" style={{ backgroundImage: 'radial-gradient(circle at 85% 15%, #D4A24C 0, transparent 40%), radial-gradient(circle at 10% 90%, #0F766E 0, transparent 45%)' }} />
        <div className="absolute -left-20 -top-24 h-72 w-72 rounded-full border border-white/10" />
        <div className="absolute -left-8 -top-12 h-48 w-48 rounded-full border border-white/10" />
        <div className="relative grid gap-6 lg:grid-cols-[1.35fr_0.65fr] lg:items-center">
          <div>
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <Badge tone="gold" className="!border-white/10 !bg-white/10 !text-[#F2D59B]">
                <Crown className="h-3 w-3" /> {active ? 'عضوية نشطة' : currentUser ? 'حساب مجاني' : 'زائر'}
              </Badge>
              <Badge tone="teal" className="!border-white/10 !bg-white/10 !text-[#8FE3D8]"><MapPin className="h-3 w-3" /> حلب · المرحلة الأولى</Badge>
            </div>
            <h1 className="text-2xl font-extrabold leading-snug sm:text-3xl" style={{ fontFamily: 'Cairo, sans-serif' }}>
              {active ? (
                <>مرحباً {currentUser?.name.split(' ')[0]} 👋<br /><span className="text-[#E9B949]">وفّر أكثر</span> في كل زيارة اليوم</>
              ) : (
                <>أهلاً بك في <span className="text-[#E9B949]">حلب خصومات</span><br />اكتشف أفضل المحلات في مدينتك</>
              )}
            </h1>
            <p className="mt-2 max-w-lg text-xs leading-6 text-white/60 sm:text-sm">
              {active
                ? 'بطاقتك الرقمية جاهزة، وأكواد OTD تتجدد كل 60 ثانية. تفضّل بزيارة أحد شركائنا واستمتع بخصمك.'
                : 'اشترك في نادي الادخار واحصل على خصومات دائمة بين 15% و30%، مع بطاقة عضوية رقمية وهدية ترحيبية.'}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {active ? (
                <>
                  <Button variant="gold" size="md" icon={<QrCode className="h-4 w-4" />} onClick={() => navigate('otd', { merchantId: 'm1', branchId: 'm1-b1' })}>استخدم خصمك الآن</Button>
                  <Button variant="ghost" className="!text-white/80 hover:!bg-white/10" size="md" onClick={() => navigate('profile')}>بطاقة العضوية</Button>
                </>
              ) : (
                <>
                  <Button variant="gold" size="md" icon={<Sparkles className="h-4 w-4" />} onClick={() => navigate('subscription')}>اشترك من 10$ سنوياً</Button>
                  <Button variant="ghost" className="!text-white/80 hover:!bg-white/10" size="md" onClick={() => navigate('merchant', { merchantId: 'm1' })}>تصفح الشركاء</Button>
                </>
              )}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            {active ? (
              <>
                <div className="col-span-2 rounded-2xl border border-white/10 bg-white/[0.07] p-4">
                  <p className="text-[10px] text-white/50">إجمالي ما وفّرته</p>
                  <p className="mt-1 text-2xl font-extrabold text-[#F2D59B]" style={{ fontFamily: 'Cairo, sans-serif' }}>
                    {formatNumber(currentUser?.savings ?? 0)} <span className="text-xs font-bold text-white/50">ل.س</span>
                  </p>
                  <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-gradient-to-l from-[#E9B949] to-[#E76F51]" style={{ width: `${Math.min(100, ((currentUser?.savings ?? 0) / 50000) * 100)}%` }} />
                  </div>
                  <p className="mt-1.5 text-[9px] text-white/35">هدف التوفير السنوي: 50,000 ل.س</p>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.05] p-3">
                  <CalendarDays className="h-4 w-4 text-[#8FE3D8]" />
                  <p className="mt-2 text-lg font-extrabold">{subscriptionDaysLeft(currentUser)}</p>
                  <p className="text-[10px] text-white/45">يوم متبقٍ</p>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.05] p-3">
                  <TrendingUp className="h-4 w-4 text-[#F2D59B]" />
                  <p className="mt-2 text-lg font-extrabold">{myTxns.length}</p>
                  <p className="text-[10px] text-white/45">عملية خصم</p>
                </div>
              </>
            ) : (
              <>
                <div className="rounded-2xl border border-white/10 bg-white/[0.06] p-3">
                  <Percent className="h-4 w-4 text-[#F2D59B]" />
                  <p className="mt-2 text-lg font-extrabold">15–30%</p>
                  <p className="text-[10px] text-white/45">خصم دائم</p>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.06] p-3">
                  <Store className="h-4 w-4 text-[#8FE3D8]" />
                  <p className="mt-2 text-lg font-extrabold">{merchants.filter((m) => m.active).length}+</p>
                  <p className="text-[10px] text-white/45">شريك في حلب</p>
                </div>
                <div className="col-span-2 rounded-2xl border border-white/10 bg-white/[0.06] p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[10px] text-white/50">عرض الإطلاق</p>
                      <p className="text-lg font-extrabold text-[#F2D59B]">$10 <span className="text-[10px] font-normal text-white/40 line-through">$20</span> / سنة</p>
                    </div>
                    <Badge tone="gold" className="!bg-[#E9B949] !text-[#2A1D08]"><Flame className="h-3 w-3" /> خصم 50%</Badge>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </section>

      {active && !currentUser?.welcomeGiftClaimed && (
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#E9E1D3] bg-gradient-to-l from-[#FCEAE6] to-[#FBF3DF] p-4">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white text-[#E76F51] shadow-sm"><Gift className="h-5 w-5" /></span>
            <div>
              <p className="text-sm font-extrabold text-[#0E2233]">هديتك الترحيبية بانتظارك 🎁</p>
              <p className="text-[11px] text-[#7B6A55]">اختر واحدة من 3 هدايا حصرية — لن تظهر الخيارات الأخرى بعد الاختيار.</p>
            </div>
          </div>
          <Button size="sm" onClick={() => navigate('gifts')} icon={<Gift className="h-4 w-4" />}>اختر هديتك</Button>
        </div>
      )}

      {ads.length > 0 && (
        <section className="mt-8">
          <SectionTitle
            eyebrow="ممول · إعلانات الشركاء"
            title="عروض مميزة هذا الأسبوع"
            action={<Badge tone="outline"><Megaphone className="h-3 w-3" /> مساحات إعلانية</Badge>}
          />
          <div className="grid gap-3 sm:grid-cols-2">
            {ads.map((m) => (
              <button key={m.id} onClick={() => navigate('merchant', { merchantId: m.id })} className="group overflow-hidden rounded-2xl border border-[#E9E1D3] bg-white text-right transition hover:shadow-lg">
                <div className={`flex items-center justify-between bg-gradient-to-l ${m.gradient} px-4 py-3`}>
                  <div>
                    <Badge tone="gold" className="!bg-white/90 !text-[#8A6515]"><Megaphone className="h-3 w-3" /> {m.ad?.badge}</Badge>
                    <p className="mt-2 text-sm font-extrabold text-white">{m.ad?.title}</p>
                  </div>
                  <span className="text-3xl">{m.emoji}</span>
                </div>
                <div className="flex items-center justify-between px-4 py-3">
                  <p className="text-[11px] text-[#6C7A87]">{m.ad?.text}</p>
                  <span className="flex items-center gap-0.5 text-[11px] font-bold text-[#0F766E]">زيارة <ChevronLeft className="h-3.5 w-3.5" /></span>
                </div>
              </button>
            ))}
          </div>
        </section>
      )}

      {active && nearby && (
        <div className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#C7E7E1] bg-[#F1FAF8] p-4">
          <div className="flex items-center gap-3">
            <span className="relative grid h-10 w-10 place-items-center rounded-full bg-[#0F766E] text-white">
              <MapPin className="h-4 w-4" />
              <span className="absolute inset-0 animate-ping rounded-full bg-[#0F766E]/30" />
            </span>
            <div>
              <p className="text-xs font-extrabold text-[#0F5F59]">أنت على بُعد 150 متراً من {nearby.name}</p>
              <p className="text-[10px] text-[#4E7A75]">إشعار جغرافي ذكي · خصمك {nearby.discount}% جاهز للاستخدام</p>
            </div>
          </div>
          <Button size="sm" onClick={() => navigate('otd', { merchantId: nearby.id, branchId: nearby.branches[0].id })} icon={<QrCode className="h-4 w-4" />}>فتح الكود</Button>
        </div>
      )}

      <section className="mt-8">
        <SectionTitle eyebrow="دليل الشركاء" title="اختر التصنيف" subtitle="كل ما تحتاجه يومياً في مدينة حلب، ضمن عضوية واحدة." />
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin">
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setCategory(c.id)}
              className={`flex shrink-0 items-center gap-2 rounded-xl border px-3.5 py-2.5 text-xs font-bold transition ${
                category === c.id ? 'border-[#0F766E] bg-[#0F766E] text-white shadow-md' : 'border-[#E9E1D3] bg-white text-[#4A5A68] hover:border-[#0F766E]'
              }`}
            >
              <span className="text-base">{c.emoji}</span> {c.label}
            </button>
          ))}
        </div>
      </section>

      <section className="mt-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>
              {category === 'all' ? 'كل الشركاء' : CATEGORIES.find((c) => c.id === category)?.label}
            </h2>
            <Badge tone="ink">{displayed.length} محل</Badge>
          </div>
          <div className="relative w-full max-w-xs">
            <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#9AA7B1]" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث عن محل أو حي..."
              className="w-full rounded-xl border border-[#E4DCCD] bg-white py-2.5 pr-9 pl-3 text-xs outline-none focus:border-[#0F766E] focus:ring-4 focus:ring-[#0F766E]/10"
            />
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {displayed.map((m) => <MerchantCard key={m.id} merchant={m} />)}
        </div>
        {displayed.length === 0 && (
          <div className="rounded-2xl border border-dashed border-[#DCD3C4] bg-[#FBF7F0] p-10 text-center">
            <Search className="mx-auto h-6 w-6 text-[#B08968]" />
            <p className="mt-2 text-sm font-bold text-[#0E2233]">لا توجد نتائج مطابقة</p>
            <p className="mt-1 text-xs text-[#7B8794]">جرّب كلمة بحث أخرى أو اختر تصنيفاً مختلفاً.</p>
          </div>
        )}
      </section>

      {featured.length > 0 && (
        <section className="mt-9 rounded-2xl border border-[#E9E1D3] bg-white p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-lg font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>
              <Flame className="h-5 w-5 text-[#E76F51]" /> الأكثر طلباً في حلب
            </h2>
            <Badge tone="outline"><Clock3 className="h-3 w-3" /> يُحدّث أسبوعياً</Badge>
          </div>
          <div className="space-y-2">
            {featured.map((m, i) => (
              <button key={m.id} onClick={() => navigate('merchant', { merchantId: m.id })} className="flex w-full items-center gap-3 rounded-xl border border-transparent p-2 text-right transition hover:border-[#EDE4D6] hover:bg-[#FCFAF6]">
                <span className="w-5 text-center text-xs font-extrabold text-[#B08968]">{i + 1}</span>
                <span className={`grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br text-lg ${m.gradient}`}>{m.emoji}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-bold text-[#0E2233]">{m.name}</p>
                  <p className="text-[10px] text-[#98A4AE]">{m.categoryLabel} · {m.reviews} تقييم</p>
                </div>
                <Badge tone={active ? 'teal' : 'sand'}>{active ? `${m.discount}%` : <Lock className="h-3 w-3" />}</Badge>
                <ChevronLeft className="h-4 w-4 text-[#C0C9D1]" />
              </button>
            ))}
          </div>
        </section>
      )}

      {!active && (
        <section className="mt-9 overflow-hidden rounded-2xl border border-[#E9E1D3] bg-gradient-to-l from-[#0E2233] to-[#173245] p-6 text-white">
          <div className="grid gap-5 sm:grid-cols-[1.4fr_0.6fr] sm:items-center">
            <div>
              <Badge tone="gold" className="!border-white/10 !bg-white/10 !text-[#F2D59B]"><Ticket className="h-3 w-3" /> عضوية حلب خصومات</Badge>
              <h2 className="mt-2 text-xl font-extrabold" style={{ fontFamily: 'Cairo, sans-serif' }}>استثمار $20 يوفّر آلاف الليرات</h2>
              <p className="mt-1 text-xs leading-6 text-white/60">أول زيارتين لمطعم أو متجر تكفيان لاستعادة قيمة الاشتراك. أضف إلى ذلك هدية ترحيبية فورية.</p>
              <div className="mt-4 grid grid-cols-2 gap-2 text-[11px] text-white/70 sm:grid-cols-4">
                {['خصومات دائمة', 'كود OTD آمن', 'هدية ترحيبية', '3,000 مشترك مستهدف'].map((x) => (
                  <span key={x} className="flex items-center gap-1"><BadgeCheck className="h-3.5 w-3.5 text-[#8FE3D8]" /> {x}</span>
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <Button variant="gold" full onClick={() => navigate('subscription')}>اشترك الآن</Button>
              <Button variant="outline" full className="!border-white/15 !bg-white/5 !text-white hover:!bg-white/10" onClick={() => navigate('register')}>إنشاء حساب</Button>
            </div>
          </div>
        </section>
      )}

      <section className="mt-9 grid gap-3 sm:grid-cols-3">
        {[
          { icon: <Percent className="h-4 w-4" />, title: 'خصم دائم', text: 'خصمك يتكرر في كل زيارة، وليس مرة واحدة فقط.' },
          { icon: <ShieldCheck className="h-4 w-4" />, title: 'نظام OTD', text: 'كود لمرة واحدة صالح 60 ثانية، يمنع الصور وإعادة الاستخدام.' },
          { icon: <Gift className="h-4 w-4" />, title: 'هدية ترحيبية', text: '3 خيارات، تختار واحدة وتحتفظ بها في حسابك.' },
        ].map((f) => (
          <div key={f.title} className="rounded-2xl border border-[#E9E1D3] bg-white p-4">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#E7F4F1] text-[#0F766E]">{f.icon}</span>
            <p className="mt-2 text-sm font-extrabold text-[#0E2233]">{f.title}</p>
            <p className="mt-0.5 text-[11px] leading-5 text-[#7B8794]">{f.text}</p>
          </div>
        ))}
      </section>

      <div className="mt-8 rounded-2xl border border-[#EDE4D6] bg-white/60 p-4 text-center">
        <p className="flex flex-wrap items-center justify-center gap-2 text-[10px] text-[#98A4AE]">
          <Users className="h-3.5 w-3.5" /> {role === 'anonymous' ? 'تتصفح كزائر' : role === 'admin' ? 'عرض إداري للكتالوج' : 'عضوية نشطة'} · حلب، سوريا
          <span className="mx-1 h-1 w-1 rounded-full bg-[#DCD3C4]" />
          <Building2 className="h-3.5 w-3.5" /> شركاء موثّقون
          <span className="mx-1 h-1 w-1 rounded-full bg-[#DCD3C4]" />
          <ArrowLeft className="h-3.5 w-3.5" /> جميع الأسعار بالدولار الأمريكي
        </p>
        {!currentUser && <p className="mt-2 text-[10px] font-semibold text-[#B08968]">وضع الزائر — نسب الخصم محجوبة حتى تنشئ حساباً وتشترك.</p>}
      </div>
    </div>
  );
}
