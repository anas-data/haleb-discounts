import { useEffect, useMemo, useState } from 'react';
import {
  BadgeCheck, CalendarDays, Camera, Check, CheckCircle2, ChevronLeft, Clock3, Download,
  Info, Keyboard, Lock, MapPin, Percent, QrCode, ReceiptText, ScanLine, Search, ShieldCheck,
  Sparkles, TrendingUp, X,
} from 'lucide-react';
import { useStore } from '../app/store';
import { downloadCsv, formatDateTime, formatNumber, isActiveSubscriber, totpCode } from '../app/logic';
import type { AppUser } from '../app/data';
import type { RedeemResult, VerifyOtdResult } from '../app/store';
import { Avatar, Badge, Button, Card, EmptyState, Stat } from '../components/ui';

export function MerchantAppPage() {
  const { currentUser, users, merchants, transactions, verifyCode, redeemCode, notify, logout } = useStore();
  const [tab, setTab] = useState<'scanner' | 'history'>('scanner');
  const defaultMerchant = currentUser?.merchantId ?? merchants[0]?.id ?? 'm1';
  const [merchantId, setMerchantId] = useState(defaultMerchant);
  const merchant = merchants.find((m) => m.id === merchantId) ?? merchants[0];
  const [branchId, setBranchId] = useState(merchant?.branches[0]?.id ?? '');
  const [code, setCode] = useState('');
  const [verification, setVerification] = useState<VerifyOtdResult | null>(null);
  const [error, setError] = useState('');
  const [amount, setAmount] = useState('12000');
  const [receipt, setReceipt] = useState<RedeemResult | null>(null);
  const [query, setQuery] = useState('');

  useEffect(() => {
    if (merchant && !merchant.branches.some((b) => b.id === branchId)) setBranchId(merchant.branches[0]?.id ?? '');
  }, [merchant, branchId]);

  const branch = merchant?.branches.find((b) => b.id === branchId) ?? merchant?.branches[0];
  const myTxns = useMemo(
    () => transactions.filter((t) => t.merchantId === merchantId).filter((t) => (query ? `${t.userName} ${t.code}`.includes(query) : true)),
    [transactions, merchantId, query],
  );
  const totalDiscounts = transactions.filter((t) => t.merchantId === merchantId).reduce((s, t) => s + t.discountAmount, 0);
  const totalSales = transactions.filter((t) => t.merchantId === merchantId).reduce((s, t) => s + t.amount, 0);

  const pasteDemoCode = () => {
    const target: AppUser | undefined = users.find((u) => isActiveSubscriber(u) && u.role === 'subscriber');
    if (!target) {
      notify('لا يوجد مشترك نشط في النسخة الحالية لسحب كوده', 'info');
      return;
    }
    const generated = totpCode(target.qrSecret, merchantId);
    setCode(generated);
    setVerification(null);
    setReceipt(null);
    setError('');
    notify(`تم إدخال كود OTD الحالي للعضوية ${target.memberId}`, 'info');
  };

  const verify = () => {
    setError('');
    setReceipt(null);
    const res = verifyCode(code, merchantId, branchId);
    setVerification(res);
    if (!res.ok) {
      setError(res.reason ?? 'تعذر التحقق');
      return;
    }
    notify(`تم التحقق من العضوية: ${res.user?.name}`);
  };

  const confirm = () => {
    if (!verification?.ok) return;
    const value = Number(amount);
    if (!Number.isFinite(value) || value <= 0) {
      setError('أدخل قيمة فاتورة صحيحة');
      return;
    }
    const res = redeemCode(code, merchantId, branchId, value);
    if (!res.ok) {
      setError(res.reason ?? 'تعذر تسجيل العملية');
      setVerification(null);
      return;
    }
    setReceipt(res);
    setVerification(null);
    setCode('');
    notify(`تم تسجيل العملية ومنح خصم ${res.discountAmount} ل.س`);
  };

  const exportReport = () => {
    downloadCsv(
      `haleb-${merchantId}-transactions.csv`,
      ['رقم العملية', 'المشترك', 'الكود', 'الفرع', 'قيمة الفاتورة', 'قيمة الخصم', 'التاريخ'],
      myTxns.map((t) => [t.id, t.userName, t.code, t.branchName, t.amount, t.discountAmount, new Date(t.createdAt).toISOString()]),
    );
    notify('تم تصدير تقرير المعاملات بصيغة CSV');
  };

  if (!merchant) return <EmptyState title="لا يوجد تاجر مرتبط بالحساب" text="تواصل مع إدارة المنصة لربط حسابك بمحل تجاري." />;

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      <section className="relative overflow-hidden rounded-[1.5rem] bg-[#0E2233] p-5 text-white sm:p-6">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 90% 20%, #0F766E 0, transparent 45%), radial-gradient(circle at 15% 90%, #D4A24C 0, transparent 45%)' }} />
        <div className="relative flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className={`grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br text-2xl ${merchant.gradient}`}>{merchant.emoji}</span>
            <div>
              <div className="flex items-center gap-2">
                <Badge tone="gold" className="!border-white/10 !bg-white/10 !text-[#F2D59B]"><ScanLine className="h-3 w-3" /> تطبيق التاجر</Badge>
                <Badge tone="teal" className="!border-white/10 !bg-white/10 !text-[#8FE3D8]"><BadgeCheck className="h-3 w-3" /> موثّق</Badge>
              </div>
              <h1 className="mt-1 text-xl font-extrabold" style={{ fontFamily: 'Cairo, sans-serif' }}>{merchant.name}</h1>
              <p className="mt-0.5 flex items-center gap-2 text-[10px] text-white/55"><MapPin className="h-3 w-3" /> {branch?.name} · {merchant.categoryLabel}</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {currentUser?.role === 'admin' && (
              <select value={merchantId} onChange={(e) => setMerchantId(e.target.value)} className="rounded-xl border border-white/20 bg-white/10 px-3 py-2 text-[11px] font-bold text-white outline-none">
                {merchants.map((m) => <option key={m.id} value={m.id} className="text-[#0E2233]">{m.name}</option>)}
              </select>
            )}
            <Button variant="ghost" size="sm" className="!text-white/75 hover:!bg-white/10" onClick={logout} icon={<X className="h-4 w-4" />}>خروج</Button>
          </div>
        </div>
        <div className="relative mt-4 grid grid-cols-3 gap-2">
          <div className="rounded-xl border border-white/10 bg-white/[0.06] p-3"><p className="text-[9px] text-white/50">معاملات الشهر</p><p className="mt-1 text-lg font-extrabold">{transactions.filter((t) => t.merchantId === merchantId).length}</p></div>
          <div className="rounded-xl border border-white/10 bg-white/[0.06] p-3"><p className="text-[9px] text-white/50">إجمالي الخصومات</p><p className="mt-1 text-lg font-extrabold text-[#F2D59B]">{formatNumber(totalDiscounts)} <span className="text-[9px] font-normal">ل.س</span></p></div>
          <div className="rounded-xl border border-white/10 bg-white/[0.06] p-3"><p className="text-[9px] text-white/50">مبيعات عبر المنصة</p><p className="mt-1 text-lg font-extrabold">{formatNumber(totalSales)} <span className="text-[9px] font-normal">ل.س</span></p></div>
        </div>
      </section>

      <div className="mt-4 flex gap-2">
        {[
          { id: 'scanner' as const, label: 'الماسح والتحقق', icon: <QrCode className="h-4 w-4" /> },
          { id: 'history' as const, label: 'سجل المعاملات والتقارير', icon: <ReceiptText className="h-4 w-4" /> },
        ].map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`flex items-center gap-1.5 rounded-xl px-4 py-2.5 text-xs font-bold transition ${tab === t.id ? 'bg-[#0F766E] text-white shadow-md' : 'border border-[#E9E1D3] bg-white text-[#5B6B79]'}`}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {tab === 'scanner' && (
        <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_1fr]">
          <Card className="overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#EDE4D6] p-4">
              <p className="flex items-center gap-1.5 text-sm font-extrabold text-[#0E2233]"><Camera className="h-4 w-4 text-[#0F766E]" /> مسح كود المشترك</p>
              <Badge tone="green"><ShieldCheck className="h-3 w-3" /> اتصال آمن</Badge>
            </div>
            <div className="p-4">
              <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-[#E4DCCD] bg-[#0E2233]">
                <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'linear-gradient(#ffffff22 1px, transparent 1px), linear-gradient(90deg, #ffffff22 1px, transparent 1px)', backgroundSize: '28px 28px' }} />
                <div className="absolute inset-8 rounded-xl border-2 border-dashed border-white/25" />
                {['right-6 top-6 border-r-2 border-t-2 rounded-tr-lg', 'left-6 top-6 border-l-2 border-t-2 rounded-tl-lg', 'right-6 bottom-6 border-r-2 border-b-2 rounded-br-lg', 'left-6 bottom-6 border-l-2 border-b-2 rounded-bl-lg'].map((c) => (
                  <span key={c} className={`absolute h-8 w-8 border-[#E9B949] ${c}`} />
                ))}
                <span className="scan-line absolute inset-x-8 top-8 h-0.5 bg-gradient-to-l from-transparent via-[#E9B949] to-transparent shadow-[0_0_18px_#E9B949]" />
                <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                  <QrCode className="h-14 w-14 opacity-80" />
                  <p className="mt-2 text-[11px] text-white/70">وجّه كاميرا التاجر نحو QR المشترك</p>
                  <p className="mt-1 rounded-full bg-white/10 px-2 py-0.5 text-[9px] text-white/50">وضع المحاكاة — لا يلزم إذن كاميرا</p>
                </div>
                <div className="absolute inset-x-0 bottom-0 bg-black/35 p-2 text-center text-[9px] text-white/60">
                  {currentUser?.role === 'admin' ? 'عرض إداري: اختبر مسحاً لأي شريك' : `المحل: ${merchant.name} · ${branch?.name}`}
                </div>
              </div>

              <div className="mt-3 space-y-2.5">
                <label className="block">
                  <span className="mb-1 flex items-center justify-between text-[10px] font-bold text-[#5B6B79]">
                    الفرع
                    <span className="text-[9px] font-normal text-[#98A4AE]">يُسجّل مع المعاملة</span>
                  </span>
                  <select value={branchId} onChange={(e) => setBranchId(e.target.value)} className="w-full rounded-xl border border-[#E4DCCD] bg-[#FCFAF6] px-3 py-2.5 text-xs font-bold text-[#0E2233] outline-none focus:border-[#0F766E]">
                    {merchant.branches.map((b) => <option key={b.id} value={b.id}>{b.name} — {b.address}</option>)}
                  </select>
                </label>
                <label className="block">
                  <span className="mb-1 block text-[10px] font-bold text-[#5B6B79]">كود OTD الممسوح (6 أرقام)</span>
                  <div className="flex gap-1.5">
                    <input
                      value={code}
                      onChange={(e) => { setCode(e.target.value.replace(/\D/g, '').slice(0, 6)); setError(''); setVerification(null); setReceipt(null); }}
                      placeholder="000000"
                      inputMode="numeric"
                      dir="ltr"
                      className="w-full rounded-xl border border-[#E4DCCD] bg-white px-3 py-2.5 text-center font-mono text-lg font-extrabold tracking-[0.35em] outline-none focus:border-[#0F766E] focus:ring-4 focus:ring-[#0F766E]/10"
                    />
                    <button onClick={pasteDemoCode} title="جلب كود عضوية تجريبية" className="grid h-auto w-12 place-items-center rounded-xl border border-[#E4DCCD] bg-[#F3EEE4] text-[#7A6242] hover:bg-[#EDE4D6]">
                      <Keyboard className="h-4 w-4" />
                    </button>
                  </div>
                </label>
                <Button full size="lg" onClick={verify} disabled={code.length !== 6} icon={<ScanLine className="h-4 w-4" />}>التحقق من العضوية</Button>
                <p className="flex items-start gap-1 text-[9px] leading-4 text-[#98A4AE]"><Info className="mt-0.5 h-3 w-3 shrink-0" /> زر لوحة المفاتيح أداة اختبار تجلب كود OTD الحالي لعضوية نشطة. في النسخة الفعلية تُقرأ البيانات من الكاميرا فقط.</p>
              </div>

              {error && <div className="mt-3 rounded-xl border border-red-200 bg-red-50 p-3 text-[11px] font-bold text-red-700"><X className="ml-1 inline h-3.5 w-3.5" /> {error}</div>}
            </div>
          </Card>

          <div className="space-y-4">
            {receipt?.ok && receipt.user ? (
              <Card className="overflow-hidden border-[#C7E7E1]">
                <div className="bg-gradient-to-l from-[#0F766E] to-[#115E59] p-5 text-center text-white">
                  <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-white/15"><CheckCircle2 className="h-8 w-8" /></span>
                  <p className="mt-2 text-lg font-extrabold">تم منح الخصم بنجاح</p>
                  <p className="text-[10px] text-white/70">تمت أرشفة العملية في سجل الشركة وسجل المشترك</p>
                </div>
                <div className="p-4">
                  <div className="flex items-center gap-3">
                    <Avatar name={receipt.user.name} size={44} />
                    <div className="flex-1">
                      <p className="text-sm font-extrabold text-[#0E2233]">{receipt.user.name}</p>
                      <p className="font-mono text-[10px] text-[#98A4AE]" dir="ltr">{receipt.user.memberId}</p>
                    </div>
                    <Badge tone="green"><Percent className="h-3 w-3" /> {receipt.merchant?.discount}%</Badge>
                  </div>
                  <div className="mt-4 rounded-xl bg-[#FBF7F0] p-3 text-[11px]">
                    <div className="flex justify-between py-0.5"><span className="text-[#7B8794]">قيمة الفاتورة</span><span className="font-bold">{formatNumber(receipt.transaction?.amount ?? 0)} ل.س</span></div>
                    <div className="flex justify-between py-0.5"><span className="text-[#7B8794]">قيمة الخصم</span><span className="font-bold text-[#0F766E]">−{formatNumber(receipt.discountAmount ?? 0)} ل.س</span></div>
                    <div className="mt-1 flex justify-between border-t border-[#E9E1D3] pt-1 text-sm"><span className="font-bold">المبلغ المستحق</span><span className="font-extrabold text-[#0E2233]">{formatNumber((receipt.transaction?.amount ?? 0) - (receipt.discountAmount ?? 0))} ل.س</span></div>
                  </div>
                  <p className="mt-2 flex items-center gap-1 text-[9px] text-[#98A4AE]"><Clock3 className="h-3 w-3" /> {receipt.transaction && formatDateTime(receipt.transaction.createdAt)} · {branch?.name}</p>
                  <Button full className="mt-3" variant="outline" onClick={() => setReceipt(null)}>عملية جديدة</Button>
                </div>
              </Card>
            ) : verification?.ok && verification.user ? (
              <Card className="overflow-hidden">
                <div className="flex items-center justify-between border-b border-[#EDE4D6] p-4">
                  <p className="text-sm font-extrabold text-[#0E2233]">بيانات المشترك</p>
                  <Badge tone="green"><Check className="h-3 w-3" /> كود OTD صالح</Badge>
                </div>
                <div className="p-4">
                  <div className="flex items-center gap-3 rounded-xl border border-[#C7E7E1] bg-[#F2FAF8] p-3">
                    <Avatar name={verification.user.name} size={48} />
                    <div className="flex-1">
                      <p className="text-sm font-extrabold text-[#0E2233]">{verification.user.name}</p>
                      <p className="font-mono text-[10px] text-[#4E7A75]" dir="ltr">{verification.user.memberId}</p>
                      <p className="mt-0.5 flex items-center gap-1 text-[9px] text-[#7B8794]"><CalendarDays className="h-2.5 w-2.5" /> عضو نشط · ينتهي {new Date(verification.user.subscriptionEndDate ?? '').toLocaleDateString('ar-SY')}</p>
                    </div>
                    <Badge tone="green"><BadgeCheck className="h-3 w-3" /> نشط</Badge>
                  </div>
                  <div className="mt-3 rounded-xl border border-[#E9E1D3] p-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] font-bold text-[#31485B]">الخصم المتفق عليه</p>
                      <span className="text-2xl font-extrabold text-[#0F766E]">{verification.merchant?.discount}%</span>
                    </div>
                    <div className="mt-2 flex justify-between text-[10px] text-[#7B8794]"><span>الفرع</span><span className="font-bold text-[#0E2233]">{verification.branch?.name}</span></div>
                    <div className="mt-1 flex justify-between text-[10px] text-[#7B8794]"><span>المحل</span><span className="font-bold text-[#0E2233]">{verification.merchant?.name}</span></div>
                  </div>
                  <label className="mt-3 block">
                    <span className="mb-1 block text-[10px] font-bold text-[#5B6B79]">قيمة الفاتورة قبل الخصم (ل.س)</span>
                    <input value={amount} inputMode="numeric" onChange={(e) => setAmount(e.target.value.replace(/[^0-9]/g, ''))} className="w-full rounded-xl border border-[#E4DCCD] bg-white px-3 py-2.5 text-sm font-bold outline-none focus:border-[#0F766E]" dir="ltr" />
                  </label>
                  <div className="mt-2 flex items-center justify-between rounded-xl bg-[#FBF7F0] p-3 text-[11px]">
                    <span className="text-[#7B8794]">الخصم المحتسب</span>
                    <span className="font-extrabold text-[#0F766E]">{formatNumber(Math.round((Number(amount) || 0) * ((verification.merchant?.discount ?? 0) / 100)))} ل.س</span>
                  </div>
                  <Button full size="lg" className="mt-3" onClick={confirm} icon={<Check className="h-4 w-4" />}>تأكيد منح الخصم وتسجيل العملية</Button>
                  <button onClick={() => setVerification(null)} className="mt-2 w-full text-center text-[10px] font-bold text-[#98A4AE]">إلغاء</button>
                </div>
              </Card>
            ) : (
              <Card className="p-5">
                <p className="flex items-center gap-1.5 text-sm font-extrabold text-[#0E2233]"><ShieldCheck className="h-4 w-4 text-[#0F766E]" /> كيف يعمل التحقق؟</p>
                <ol className="mt-3 space-y-2.5">
                  {[
                    'يطلب المشترك كود OTD من تطبيقه (صالح 60 ثانية).',
                    'يمسح الموظف كود QR أو يدخل الأرقام الستة.',
                    'يتحقق النظام من العضوية والنافذة الزمنية الحالية.',
                    'تظهر بيانات المشترك ونسبة الخصم للتأكيد.',
                    'بعد التأكيد تُسجّل العملية في التقارير الشهرية.',
                  ].map((s, i) => (
                    <li key={s} className="flex items-start gap-2 text-[11px] leading-5 text-[#5B6B79]">
                      <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[#E7F4F1] text-[10px] font-extrabold text-[#0F766E]">{i + 1}</span> {s}
                    </li>
                  ))}
                </ol>
                <div className="mt-4 rounded-xl border border-[#F0E1BC] bg-[#FBF3DF] p-3 text-[10px] leading-5 text-[#8A7433]">
                  <b>كود منتهي أو مستخدم؟</b> ارفض العملية واطلب من العميل توليد كود جديد. النظام يرفض أي كود خارج نافذة الدقيقة أو سبق استخدامه.
                </div>
              </Card>
            )}

            <Card className="p-4">
              <p className="flex items-center gap-1.5 text-xs font-extrabold text-[#0E2233]"><Sparkles className="h-4 w-4 text-[#D4A24C]" /> ملخص سريع</p>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <div className="rounded-xl border border-[#EDE4D6] p-2.5"><p className="text-[9px] text-[#98A4AE]">شركاء المنصة</p><p className="text-base font-extrabold text-[#0E2233]">{merchants.filter((m) => m.active).length}</p></div>
                <div className="rounded-xl border border-[#EDE4D6] p-2.5"><p className="text-[9px] text-[#98A4AE]">مشتركون نشطون</p><p className="text-base font-extrabold text-[#0E2233]">{transactions.length > 0 ? '2' : '0'}</p></div>
              </div>
              <button onClick={() => setTab('history')} className="mt-3 flex w-full items-center justify-between rounded-xl bg-[#F5FAF8] p-2.5 text-[10px] font-bold text-[#0F766E]">عرض سجل المعاملات <ChevronLeft className="h-3.5 w-3.5" /></button>
            </Card>
          </div>
        </div>
      )}

      {tab === 'history' && (
        <div className="mt-4 space-y-4">
          <div className="grid gap-3 sm:grid-cols-3">
            <Stat icon={<ReceiptText className="h-4 w-4" />} label="عدد المعاملات" value={String(transactions.filter((t) => t.merchantId === merchantId).length)} hint="هذا الشهر" />
            <Stat icon={<Percent className="h-4 w-4" />} label="إجمالي الخصومات" value={`${formatNumber(totalDiscounts)} ل.س`} hint="ممنوحة للأعضاء" tone="gold" />
            <Stat icon={<TrendingUp className="h-4 w-4" />} label="إجمالي المبيعات" value={`${formatNumber(totalSales)} ل.س`} hint="عبر المنصة" tone="ink" />
          </div>
          <Card className="overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#EDE4D6] p-4">
              <p className="flex items-center gap-1.5 text-sm font-extrabold text-[#0E2233]"><ReceiptText className="h-4 w-4 text-[#0F766E]" /> سجل المعاملات — {merchant.name}</p>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[#9AA7B1]" />
                  <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="بحث بالاسم أو الكود" className="w-40 rounded-lg border border-[#E4DCCD] bg-white py-1.5 pr-8 pl-2 text-[10px] outline-none focus:border-[#0F766E]" />
                </div>
                <Button size="sm" variant="outline" onClick={exportReport} icon={<Download className="h-3.5 w-3.5" />}>تصدير CSV</Button>
              </div>
            </div>
            {myTxns.length === 0 ? (
              <div className="p-6"><EmptyState title="لا توجد معاملات لهذا التاجر" text="ابدأ بمسح كود OTD من زاوية الماسح." icon={<ReceiptText className="h-5 w-5" />} /></div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-[11px]">
                  <thead className="bg-[#FBF7F0] text-[10px] text-[#7B8794]">
                    <tr>
                      <th className="p-3 font-bold">المشترك</th>
                      <th className="p-3 font-bold">الكود</th>
                      <th className="p-3 font-bold">الفرع</th>
                      <th className="p-3 font-bold">الفاتورة</th>
                      <th className="p-3 font-bold">الخصم</th>
                      <th className="p-3 font-bold">التاريخ</th>
                      <th className="p-3 font-bold">الحالة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F3EEE4]">
                    {myTxns.map((t) => (
                      <tr key={t.id} className="hover:bg-[#FCFAF6]">
                        <td className="p-3"><div className="flex items-center gap-2"><Avatar name={t.userName} size={26} /><span className="font-bold text-[#0E2233]">{t.userName}</span></div></td>
                        <td className="p-3 font-mono text-[#6C7A87]" dir="ltr">{t.code}</td>
                        <td className="p-3 text-[#6C7A87]">{t.branchName}</td>
                        <td className="p-3 font-bold">{formatNumber(t.amount)}</td>
                        <td className="p-3 font-bold text-[#0F766E]">−{formatNumber(t.discountAmount)}</td>
                        <td className="p-3 text-[10px] text-[#98A4AE]">{formatDateTime(t.createdAt)}</td>
                        <td className="p-3"><Badge tone={t.status === 'completed' ? 'green' : 'red'}>{t.status === 'completed' ? 'مكتملة' : 'معلّمة'}</Badge></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <div className="flex items-center justify-between border-t border-[#EDE4D6] p-3 text-[10px] text-[#98A4AE]">
              <span className="flex items-center gap-1"><Clock3 className="h-3 w-3" /> تُحدّث البيانات فورياً لكل عملية</span>
              <span className="flex items-center gap-1"><Lock className="h-3 w-3" /> تظهر معاملات محلك فقط وفق قواعد الصلاحيات</span>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}


