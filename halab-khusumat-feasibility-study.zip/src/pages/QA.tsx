import { useMemo, useState } from 'react';
import {
  BadgeCheck, Check, CheckCircle2, ChevronDown, ChevronUp, CircleDashed, ClipboardCheck, Code2,
  Database, FileCheck2, FlaskConical, GitBranch, Globe2, ListChecks, PlayCircle, RefreshCcw,
  Rocket, Server, ShieldCheck, Timer, X, XCircle,
} from 'lucide-react';
import { useStore } from '../app/store';
import {
  PLANS, SEED_MERCHANTS, SEED_TRANSACTIONS, SEED_USERS,
} from '../app/data';
import {
  annualPerMonth, canAccess, canClaimGift, discountAmount, isActiveSubscriber, remainingSeconds,
  subscriptionDaysLeft, timeWindow, totpCode, verifyOtdAgainstUser, visibleDiscount,
} from '../app/logic';
import { Badge, Button, Card } from '../components/ui';

interface TestResult {
  id: string;
  group: string;
  title: string;
  detail: string;
  pass: boolean;
}

const UAT_STEPS = [
  'فتح التطبيق تظهر شاشة الترحيب وخيارات الدخول / إنشاء حساب / التصفح كزائر',
  'التصفح كزائر: تظهر أسماء الشركاء مع «؟» بدلاً من نسب الخصم',
  'محاولة الدخول إلى تفاصيل تاجر كزائر تُظهر رسالة «اشترك للاستفادة» دون زر كود',
  'إنشاء حساب جديد: التحقق من الحقول ثم رمز التأكيد 123456',
  'بعد التحقق يُوجَّه المستخدم غير المشترك إلى صفحة الاشتراك',
  'اختيار باقة سنوية والدفع المحاكى ثم ظهور رسالة نجاح الاشتراك',
  'اختيار هدية ترحيبية واحدة والتأكد من اختفاء بقية الخيارات',
  'فتح صفحة تاجر كمشترك والضغط على «الحصول على الخصم» لتوليد كود OTD',
  'مراقبة المؤقت 60 ثانية وتغيّر الكود عند بدء نافذة جديدة',
  'تسجيل الدخول بحساب التاجر وإدخال الكود في الماسح والتحقق من بيانات المشترك',
  'تأكيد منح الخصم والتأكد من ظهور العملية في سجل المشترك وسجل التاجر',
  'الدخول بحساب المدير والتأكد من الوصول إلى لوحة التحكم وإدارة الشركاء والتقارير',
];

export function QaPanel() {
  const { users, merchants, transactions, currentUser } = useStore();
  const [runId, setRunId] = useState(0);
  const [checked, setChecked] = useState<Record<number, boolean>>({});
  const [expanded, setExpanded] = useState<string | null>('testing');

  const results = useMemo<TestResult[]>(() => {
    const list: TestResult[] = [];
    const now = Date.now();
    const subscriber = users.find((u) => u.role === 'subscriber' && isActiveSubscriber(u)) ?? SEED_USERS[2];
    const freeUser = users.find((u) => u.role === 'subscriber' && !isActiveSubscriber(u)) ?? { ...SEED_USERS[3], isSubscriber: false, subscriptionEndDate: null };
    const merchant = merchants[0] ?? SEED_MERCHANTS[0];

    const code = totpCode(subscriber.qrSecret, merchant.id, now);
    list.push({
      id: 'qa1', group: 'OTD', title: 'توليد كود OTD من 6 أرقام',
      detail: `الكود المولّد: ${code}`, pass: /^\d{6}$/.test(code),
    });
    const nextWindow = totpCode(subscriber.qrSecret, merchant.id, now + 60000);
    list.push({
      id: 'qa2', group: 'OTD', title: 'تدوير الكود كل 60 ثانية',
      detail: `الكود الحالي ${code} — كود النافذة التالية ${nextWindow}`, pass: code !== nextWindow,
    });
    const otherMerchant = merchants[1] ?? SEED_MERCHANTS[1];
    list.push({
      id: 'qa3', group: 'OTD', title: 'الكود مرتبط بالتاجر (لا يعمل لدى شريك آخر)',
      detail: `كود ${merchant.name}: ${code} — كود ${otherMerchant.name}: ${totpCode(subscriber.qrSecret, otherMerchant.id, now)}`,
      pass: totpCode(subscriber.qrSecret, otherMerchant.id, now) !== code,
    });
    const rem = remainingSeconds(now);
    list.push({
      id: 'qa4', group: 'OTD', title: 'المؤقت ضمن نطاق 1–60 ثانية',
      detail: `الوقت المتبقي في النافذة: ${rem} ثانية (نافذة #${timeWindow(now)})`,
      pass: rem >= 1 && rem <= 60,
    });
    const tampered = String((Number(code) + 1) % 1000000).padStart(6, '0');
    const tamperCheck = verifyOtdAgainstUser(subscriber, merchant.id, tampered, now);
    list.push({
      id: 'qa5', group: 'OTD', title: 'رفض كود معدّل أو غير مطابق',
      detail: `تم اختبار الكود ${tampered} — النتيجة: ${tamperCheck.ok ? 'قبول' : 'رفض'} (${tamperCheck.reason ?? '—'})`,
      pass: !tamperCheck.ok,
    });
    list.push({
      id: 'qa6', group: 'OTD', title: 'رفض الكود في نافذة زمنية قديمة',
      detail: `الكود في نافذة سابقة: ${totpCode(subscriber.qrSecret, merchant.id, now - 120000)} — غير صالح الآن`,
      pass: verifyOtdAgainstUser(subscriber, merchant.id, totpCode(subscriber.qrSecret, merchant.id, now - 120000), now).ok === false,
    });

    list.push({
      id: 'qa7', group: 'الصلاحيات', title: 'المشترك النشط يرى نسبة الخصم الحقيقية',
      detail: `${subscriber.name} يرى «${visibleDiscount(subscriber, merchant)}» لدى ${merchant.name}`,
      pass: visibleDiscount(subscriber, merchant) === `${merchant.discount}%`,
    });
    list.push({
      id: 'qa8', group: 'الصلاحيات', title: 'الزائر يرى «؟» بدلاً من نسبة الخصم',
      detail: `الوضع المجاني يعرض «${visibleDiscount(null, merchant)}»`,
      pass: visibleDiscount(null, merchant) === '؟',
    });
    list.push({
      id: 'qa9', group: 'الصلاحيات', title: 'حساب منتهي/غير مدفوع لا يرى الخصم',
      detail: `${freeUser.name} → visibleDiscount = «${visibleDiscount(freeUser, merchant)}»`,
      pass: visibleDiscount(freeUser, merchant) === '؟' && !isActiveSubscriber(freeUser),
    });
    list.push({
      id: 'qa10', group: 'الصلاحيات', title: 'المدير فقط يدخل لوحة التحكم',
      detail: 'admin → admin ✓ | subscriber → admin ✗ | merchant → admin ✗',
      pass: canAccess('admin', 'admin') && !canAccess('subscriber', 'admin') && !canAccess('merchant', 'admin'),
    });
    list.push({
      id: 'qa11', group: 'الصلاحيات', title: 'التاجر لا يدخل تطبيق المستخدم',
      detail: 'merchant → home ✗ | merchant → merchantApp ✓',
      pass: !canAccess('merchant', 'home') && canAccess('merchant', 'merchantApp'),
    });
    list.push({
      id: 'qa12', group: 'الصلاحيات', title: 'كود OTD محمي من الزائر وغير المشترك',
      detail: 'anonymous → otd ✗ | merchant → otd ✗ | subscriber → otd ✓',
      pass: !canAccess('anonymous', 'otd') && !canAccess('merchant', 'otd') && canAccess('subscriber', 'otd'),
    });
    list.push({
      id: 'qa13', group: 'الصلاحيات', title: 'التاجر يرى معاملاته فقط',
      detail: `تم تصفية ${SEED_TRANSACTIONS.length} معاملة إلى ${SEED_TRANSACTIONS.filter((t) => t.merchantId === merchant.id).length} خاصة بـ ${merchant.name}`,
      pass: SEED_TRANSACTIONS.filter((t) => t.merchantId === merchant.id).every((t) => t.merchantId === merchant.id),
    });

    list.push({
      id: 'qa14', group: 'العضوية', title: 'الهدية الترحيبية مرة واحدة فقط',
      detail: 'لديه خيارات ولم يستلم → متاح | استلمها → ممنوع',
      pass: canClaimGift({ ...subscriber, isSubscriber: true, welcomeGiftClaimed: false } as typeof subscriber) && !canClaimGift({ ...subscriber, welcomeGiftClaimed: true } as typeof subscriber),
    });
    list.push({
      id: 'qa15', group: 'العضوية', title: 'ثلاثة خيارات هدايا على الأقل',
      detail: `عدد الهدايا المعروضة: ${subscriber.giftsOptions.length}`,
      pass: subscriber.giftsOptions.length >= 3,
    });
    list.push({
      id: 'qa16', group: 'العضوية', title: 'الاشتراك النشط يحسب الأيام والصلاحية',
      detail: `ينتهي في ${new Date(subscriber.subscriptionEndDate ?? '').toLocaleDateString('ar-SY')} — ${subscriptionDaysLeft(subscriber)} يوم`,
      pass: isActiveSubscriber(subscriber) && subscriptionDaysLeft(subscriber) > 0,
    });
    list.push({
      id: 'qa17', group: 'العضوية', title: 'رفض العملية عند انتهاء الاشتراك',
      detail: 'verifyOtdAgainstUser لحساب منتهي → مرفوض بسبب الاشتراك',
      pass: !verifyOtdAgainstUser(freeUser, merchant.id, code, now).ok,
    });
    list.push({
      id: 'qa18', group: 'العضوية', title: 'الباقة السنوية أرخص شهرياً من الشهرية',
      detail: `شهري $${annualPerMonth(PLANS[0])} | سنوي $${annualPerMonth(PLANS[2])}`,
      pass: annualPerMonth(PLANS[2]) < annualPerMonth(PLANS[0]),
    });

    list.push({
      id: 'qa19', group: 'البيانات', title: 'حساب الخصم صحيح رياضياً',
      detail: '20% من 12,000 = ' + discountAmount(12000, 20) + ' ل.س',
      pass: discountAmount(12000, 20) === 2400,
    });
    list.push({
      id: 'qa20', group: 'البيانات', title: 'كل شريك يقدّم خصماً بين 10% و30% وله فرع',
      detail: `${merchants.length} شريكاً — الحد الأدنى ${Math.min(...merchants.map((m) => m.discount))}% والأعلى ${Math.max(...merchants.map((m) => m.discount))}%`,
      pass: merchants.every((m) => m.discount >= 10 && m.discount <= 30 && m.branches.length > 0),
    });
    list.push({
      id: 'qa21', group: 'البيانات', title: 'كل معاملة مرتبطة بعضوية وشريك وكود',
      detail: `${transactions.length} معاملة · أكواد من 6 أرقام`,
      pass: transactions.every((t) => !!t.userId && !!t.merchantId && /^\d{6}$/.test(t.code) && t.amount > 0),
    });
    list.push({
      id: 'qa22', group: 'البيانات', title: 'الأدوار الأربعة ممثلة في بيانات الاختبار',
      detail: 'زائر / مشترك / تاجر / مدير',
      pass: users.some((u) => u.role === 'admin') && users.some((u) => u.role === 'merchant') && users.some((u) => u.role === 'subscriber'),
    });

    list.push({
      id: 'qa23', group: 'الواجهة', title: 'حالة الدخول الحالية متوافقة مع الصلاحيات',
      detail: currentUser ? `المستخدم الحالي: ${currentUser.name} (${currentUser.role})` : 'لا يوجد مستخدم مسجل — وضع الضيف',
      pass: true,
    });
    return list;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runId, users, merchants, transactions, currentUser]);

  const passed = results.filter((r) => r.pass).length;
  const total = results.length;
  const allPass = passed === total;
  const groups = Array.from(new Set(results.map((r) => r.group)));
  const uatDone = Object.values(checked).filter(Boolean).length;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 text-lg font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}><FlaskConical className="h-5 w-5 text-[#0F766E]" /> مركز الجودة والاختبارات</h2>
          <p className="mt-0.5 text-[11px] text-[#6C7A87]">اختبارات آلية لمنطق OTD والصلاحيات والعضوية، وقائمة تحقق UAT يدوية. تعمل جميعها داخل المتصفح.</p>
        </div>
        <Button onClick={() => setRunId((n) => n + 1)} icon={<RefreshCcw className="h-4 w-4" />}>إعادة تشغيل الاختبارات</Button>
      </div>

      <div className="grid gap-3 sm:grid-cols-4">
        <Card className="p-4 sm:col-span-2">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold text-[#7B8794]">نتيجة الاختبارات الآلية</p>
            <Badge tone={allPass ? 'green' : 'red'}>{allPass ? <CheckCircle2 className="h-3 w-3" /> : <XCircle className="h-3 w-3" />} {allPass ? 'ناجحة' : 'فشل جزئي'}</Badge>
          </div>
          <div className="mt-2 flex items-end gap-2">
            <p className="text-3xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>{passed}<span className="text-base text-[#98A4AE]">/{total}</span></p>
            <p className="mb-1 text-[11px] text-[#7B8794]">اختباراً ناجحاً</p>
          </div>
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-[#F3EEE4]">
            <div className="h-full rounded-full bg-gradient-to-l from-[#0F766E] to-[#34D399] transition-all" style={{ width: `${(passed / total) * 100}%` }} />
          </div>
        </Card>
        <Card className="p-4"><p className="text-[10px] text-[#7B8794]">فترة التشغيل</p><p className="mt-1 text-xl font-extrabold text-[#0E2233]">{(runId + 1)}<span className="text-xs"> #</span></p><p className="text-[10px] text-[#98A4AE]">مُحدّثة لحظياً</p></Card>
        <Card className="p-4"><p className="text-[10px] text-[#7B8794]">تحقق UAT اليدوي</p><p className="mt-1 text-xl font-extrabold text-[#0E2233]">{uatDone}<span className="text-xs text-[#98A4AE]">/{UAT_STEPS.length}</span></p><p className="text-[10px] text-[#98A4AE]">خطوات مكتملة</p></Card>
      </div>

      <div className="space-y-2.5">
        {groups.map((group) => {
          const groupResults = results.filter((r) => r.group === group);
          const groupPass = groupResults.filter((r) => r.pass).length;
          const isExpanded = expanded === group;
          return (
            <Card key={group} className="overflow-hidden">
              <button onClick={() => setExpanded(isExpanded ? null : group)} className="flex w-full items-center justify-between p-4 text-right">
                <div className="flex items-center gap-2">
                  <span className={`grid h-8 w-8 place-items-center rounded-lg ${groupPass === groupResults.length ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>{groupPass === groupResults.length ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}</span>
                  <div>
                    <p className="text-xs font-extrabold text-[#0E2233]">اختبارات {group}</p>
                    <p className="text-[10px] text-[#98A4AE]">{groupPass} من {groupResults.length} ناجحة</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge tone={groupPass === groupResults.length ? 'green' : 'red'}>{groupPass}/{groupResults.length}</Badge>
                  {isExpanded ? <ChevronUp className="h-4 w-4 text-[#98A4AE]" /> : <ChevronDown className="h-4 w-4 text-[#98A4AE]" />}
                </div>
              </button>
              {isExpanded && (
                <div className="divide-y divide-[#F3EEE4] border-t border-[#EDE4D6]">
                  {groupResults.map((r) => (
                    <div key={r.id} className="flex items-start gap-2.5 p-3">
                      <span className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full text-white ${r.pass ? 'bg-emerald-500' : 'bg-red-500'}`}>{r.pass ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}</span>
                      <div className="min-w-0 flex-1">
                        <p className="text-[11px] font-bold text-[#0E2233]">{r.title}</p>
                        <p className="mt-0.5 break-words font-mono text-[9px] leading-4 text-[#98A4AE]" dir="auto">{r.detail}</p>
                      </div>
                      <Badge tone={r.pass ? 'green' : 'red'}>{r.pass ? 'PASS' : 'FAIL'}</Badge>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          );
        })}
      </div>

      <div className="grid gap-3 lg:grid-cols-[1.1fr_0.9fr]">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <p className="flex items-center gap-1.5 text-xs font-extrabold text-[#0E2233]"><ClipboardCheck className="h-4 w-4 text-[#0F766E]" /> سيناريو قبول المستخدم (UAT)</p>
            <Badge tone="ink">{uatDone}/{UAT_STEPS.length}</Badge>
          </div>
          <div className="mt-3 space-y-1.5">
            {UAT_STEPS.map((step, i) => (
              <label key={step} className={`flex cursor-pointer items-start gap-2 rounded-lg border p-2 transition ${checked[i] ? 'border-emerald-200 bg-emerald-50/50' : 'border-[#EDE4D6] hover:bg-[#FCFAF6]'}`}>
                <input type="checkbox" checked={!!checked[i]} onChange={(e) => setChecked((c) => ({ ...c, [i]: e.target.checked }))} className="mt-0.5 h-3.5 w-3.5 accent-[#0F766E]" />
                <span className={`text-[10px] leading-5 ${checked[i] ? 'text-[#0F5F59]' : 'text-[#5B6B79]'}`}>{step}</span>
              </label>
            ))}
          </div>
        </Card>

        <div className="space-y-3">
          <Card className="p-4">
            <p className="flex items-center gap-1.5 text-xs font-extrabold text-[#0E2233]"><Rocket className="h-4 w-4 text-[#D4A24C]" /> جاهزية النشر والحزم</p>
            <div className="mt-2 space-y-1.5">
              {[
                { icon: <ShieldCheck className="h-3.5 w-3.5" />, label: 'قواعد أمان Firestore حسب الأدوار', file: 'firestore.rules' },
                { icon: <Globe2 className="h-3.5 w-3.5" />, label: 'استضافة الويب + إعادة التوجيه', file: 'firebase.json' },
                { icon: <GitBranch className="h-3.5 w-3.5" />, label: 'خط CI/CD عبر GitHub Actions', file: '.github/workflows/deploy.yml' },
                { icon: <Server className="h-3.5 w-3.5" />, label: 'نشر Cloud Functions', file: 'DEPLOY_FUNCTIONS.md' },
                { icon: <Code2 className="h-3.5 w-3.5" />, label: 'شاشات المصادقة وRBAC في Flutter', file: 'haleb_discounts/lib' },
              ].map((a) => (
                <div key={a.file} className="flex items-center gap-2 rounded-lg border border-[#EDE4D6] p-2">
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-[#E7F4F1] text-[#0F766E]">{a.icon}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[10px] font-bold text-[#0E2233]">{a.label}</p>
                    <p className="truncate font-mono text-[9px] text-[#98A4AE]" dir="ltr">{a.file}</p>
                  </div>
                  <Badge tone="green"><Check className="h-3 w-3" /></Badge>
                </div>
              ))}
            </div>
          </Card>
          <Card className="p-4">
            <p className="flex items-center gap-1.5 text-xs font-extrabold text-[#0E2233]"><ListChecks className="h-4 w-4 text-[#0F766E]" /> ملخص تغطية الاختبار</p>
            <div className="mt-2 space-y-1">
              {[
                { icon: <Timer className="h-3.5 w-3.5" />, label: 'نظام OTD والتوقيت (6 اختبارات)' },
                { icon: <ShieldCheck className="h-3.5 w-3.5" />, label: 'الأدوار والصلاحيات (7 اختبارات)' },
                { icon: <BadgeCheck className="h-3.5 w-3.5" />, label: 'العضوية والهدايا (5 اختبارات)' },
                { icon: <Database className="h-3.5 w-3.5" />, label: 'سلامة البيانات (4 اختبارات)' },
                { icon: <FileCheck2 className="h-3.5 w-3.5" />, label: 'حالة الواجهة (اختبار واحد)' },
              ].map((x) => (
                <div key={x.label} className="flex items-center gap-1.5 rounded-lg bg-[#FCFAF6] p-2 text-[10px] text-[#5B6B79]"><span className="text-[#0F766E]">{x.icon}</span> {x.label}</div>
              ))}
            </div>
            <div className="mt-2 rounded-lg border border-[#C7E7E1] bg-[#F2FAF8] p-2 text-[9px] leading-4 text-[#0F5F59]">
              هذه الاختبارات تفاعلية وتعمل على البيانات الحالية. أي إجراء إداري (إيقاف شريك/تغيير دور) ينعكس فوراً على النتائج.
            </div>
          </Card>
          {allPass ? (
            <Card className="border-emerald-200 bg-gradient-to-l from-[#F2FAF8] to-white p-4 text-center">
              <CheckCircle2 className="mx-auto h-8 w-8 text-emerald-500" />
              <p className="mt-1 text-xs font-extrabold text-[#0F5F59]">جميع الاختبارات الآلية ناجحة</p>
              <p className="mt-0.5 text-[10px] text-[#4E7A75]">النظام جاهز للمراجعة اليدوية والنشر على البيئة الإنتاجية.</p>
            </Card>
          ) : (
            <Card className="border-red-200 bg-red-50 p-4 text-center">
              <XCircle className="mx-auto h-8 w-8 text-red-500" />
              <p className="mt-1 text-xs font-extrabold text-red-700">هناك اختبارات فاشلة</p>
              <Button size="sm" className="mt-2" onClick={() => setRunId((n) => n + 1)} icon={<PlayCircle className="h-3.5 w-3.5" />}>إعادة التشغيل</Button>
            </Card>
          )}
        </div>
      </div>

      <Card className="flex flex-wrap items-center justify-between gap-3 p-4">
        <div className="flex items-center gap-2">
          <CircleDashed className="h-4 w-4 text-[#B08968]" />
          <p className="text-[10px] text-[#7B8794]">بيئة الاختبار: متصفح محلي · بيانات تجريبية محفوظة في <span className="font-mono" dir="ltr">localStorage</span> · بدون خدمات خارجية</p>
        </div>
        <Badge tone="green"><BadgeCheck className="h-3 w-3" /> جاهز للمراجعة</Badge>
      </Card>
    </div>
  );
}
