import { QRCodeSVG } from 'qrcode.react';
import {
  ArrowRight, BadgeCheck, CalendarDays, Check, ChevronLeft, Clock3, Copy, Crown, Gift, History,
  LayoutDashboard, LogOut, Lock, Mail, MapPin, Percent, Phone, QrCode, ReceiptText, ScanLine, ShieldCheck,
  Sparkles, Store, TrendingUp, User, Wallet,
} from 'lucide-react';
import { useStore } from '../app/store';
import { formatDate, formatDateTime, formatNumber, isActiveSubscriber, subscriptionDaysLeft } from '../app/logic';
import { Badge, Button, Card, EmptyState, RoleBadge, Stat } from '../components/ui';
import { useState } from 'react';

export function ProfilePage() {
  const { currentUser, transactions, navigate, logout, gifts, notify } = useStore();
  const [copied, setCopied] = useState(false);
  if (!currentUser) return <div className="mx-auto max-w-lg px-4 py-20"><EmptyState title="سجّل الدخول" text="سجّل دخولك للوصول إلى بطاقة العضوية وسجل التوفير." icon={<User className="h-5 w-5" />} /><div className="mt-4 text-center"><Button onClick={() => navigate('login')}>تسجيل الدخول</Button></div></div>;

  const active = isActiveSubscriber(currentUser);
  const myTxns = transactions.filter((t) => t.userId === currentUser.uid);
  const gift = gifts.find((g) => g.id === currentUser.selectedGiftId);

  const copyId = async () => {
    try {
      await navigator.clipboard.writeText(currentUser.memberId);
      setCopied(true);
      notify('تم نسخ رقم العضوية');
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      notify('تعذر النسخ', 'error');
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="text-2xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>حسابي</h1>
          <p className="text-xs text-[#6C7A87]">بطاقة العضوية، حالة الاشتراك، وسجل التوفير الشخصي.</p>
        </div>
        <div className="flex items-center gap-2">
          <RoleBadge role={currentUser.role} />
          <Badge tone={active ? 'green' : 'red'}>{active ? 'عضوية نشطة' : 'غير مشترك'}</Badge>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_1.25fr]">
        <div className="space-y-4">
          <div className="relative overflow-hidden rounded-3xl bg-[#0E2233] p-5 text-white shadow-xl">
            <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-[#0F766E]/40 blur-2xl" />
            <div className="absolute -bottom-14 -right-10 h-44 w-44 rounded-full bg-[#E76F51]/30 blur-2xl" />
            <div className="relative flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-[#E76F51] to-[#D4A24C] text-sm font-black">%</span>
                <div>
                  <p className="text-xs font-extrabold">حلب خصومات</p>
                  <p className="text-[9px] text-white/45">بطاقة العضوية الرقمية</p>
                </div>
              </div>
              <Badge tone={active ? 'gold' : 'red'} className={active ? '!border-white/10 !bg-white/10 !text-[#F2D59B]' : '!bg-white/90'}>{active ? <BadgeCheck className="h-3 w-3" /> : <Lock className="h-3 w-3" />} {active ? 'نشطة' : 'غير مفعّلة'}</Badge>
            </div>
            <div className="relative mt-6 flex items-start justify-between gap-3">
              <div>
                <p className="text-[9px] text-white/45">الاسم</p>
                <p className="text-lg font-extrabold">{currentUser.name}</p>
                <p className="mt-2 font-mono text-xs tracking-wider text-[#F2D59B]" dir="ltr">{currentUser.memberId}</p>
                <p className="mt-3 text-[10px] text-white/50">صالحة حتى</p>
                <p className="text-xs font-bold">{active ? formatDate(currentUser.subscriptionEndDate) : 'بانتظار الاشتراك'}</p>
              </div>
              <div className="rounded-xl bg-white p-2">
                <QRCodeSVG value={`${currentUser.memberId}|${currentUser.email}`} size={78} fgColor="#0E2233" level="M" />
              </div>
            </div>
            <div className="relative mt-4 flex items-center justify-between border-t border-white/10 pt-3 text-[10px]">
              <span className="flex items-center gap-1 text-white/60"><QrCode className="h-3.5 w-3.5" /> OTD · 60 ثانية</span>
              <button onClick={copyId} className="flex items-center gap-1 rounded-lg bg-white/10 px-2 py-1 font-bold">
                {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />} {copied ? 'تم النسخ' : 'نسخ الرقم'}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <Stat icon={<Wallet className="h-4 w-4" />} label="التوفير" value={`${formatNumber(currentUser.savings)}`} hint="ل.س" />
            <Stat icon={<TrendingUp className="h-4 w-4" />} label="العمليات" value={String(currentUser.visits)} hint="استخدام" tone="gold" />
            <Stat icon={<CalendarDays className="h-4 w-4" />} label="متبقٍ" value={active ? String(subscriptionDaysLeft(currentUser)) : '—'} hint={active ? 'يوم' : 'غير مشترك'} tone="ink" />
          </div>

          <Card className="p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm font-extrabold text-[#0E2233]">تفاصيل الاشتراك</p>
              <Badge tone={active ? 'teal' : 'sand'}>{active ? 'نشط' : 'غير نشط'}</Badge>
            </div>
            <div className="mt-3 space-y-2 text-[11px]">
              {[
                { label: 'الباقة الحالية', value: currentUser.plan ? { monthly: 'شهري', semi: 'نصف سنوي', annual: 'سنوي' }[currentUser.plan] ?? currentUser.plan : 'لا يوجد' },
                { label: 'حالة الدفع', value: active ? 'مدفوع' : 'لم يتم الدفع' },
                { label: 'تاريخ التجديد', value: active ? formatDate(currentUser.subscriptionEndDate) : '—' },
                { label: 'الهدية الترحيبية', value: currentUser.welcomeGiftClaimed ? 'تم استلامها' : 'غير مستلمة' },
              ].map((r) => (
                <div key={r.label} className="flex items-center justify-between border-b border-dashed border-[#F0E9DD] pb-1.5">
                  <span className="text-[#7B8794]">{r.label}</span>
                  <span className="font-bold text-[#0E2233]">{r.value}</span>
                </div>
              ))}
            </div>
            <div className="mt-3 flex gap-2">
              <Button size="sm" full variant={active ? 'outline' : 'primary'} onClick={() => navigate('subscription')} icon={<Crown className="h-4 w-4" />}>{active ? 'تجديد الاشتراك' : 'اشترك الآن'}</Button>
              <Button size="sm" full variant="ghost" onClick={() => navigate('gifts')} icon={<Gift className="h-4 w-4" />}>الهدية</Button>
            </div>
          </Card>

          {gift && currentUser.giftCode && (
            <Card className="overflow-hidden">
              <div className={`bg-gradient-to-l ${gift.tone} p-3 text-white`}>
                <p className="flex items-center gap-1.5 text-[10px] text-white/80"><Gift className="h-3.5 w-3.5" /> هديتي الترحيبية</p>
                <p className="mt-1 text-sm font-extrabold">{gift.title}</p>
                <p className="text-[10px] text-white/75">{gift.merchant}</p>
              </div>
              <div className="flex items-center justify-between p-3">
                <span className="font-mono text-[11px] font-extrabold tracking-wider text-[#0E2233]" dir="ltr">{currentUser.giftCode}</span>
                <Badge tone="green">{gift.value}</Badge>
              </div>
            </Card>
          )}
        </div>

        <div className="space-y-4">
          <Card className="p-5">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-sm font-extrabold text-[#0E2233]"><User className="h-4 w-4 text-[#0F766E]" /> البيانات الشخصية</h2>
              <Badge tone="outline"><ShieldCheck className="h-3 w-3" /> محمية</Badge>
            </div>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {[
                { icon: <User className="h-3.5 w-3.5" />, label: 'الاسم', value: currentUser.name },
                { icon: <Phone className="h-3.5 w-3.5" />, label: 'الهاتف', value: currentUser.phone },
                { icon: <Mail className="h-3.5 w-3.5" />, label: 'البريد', value: currentUser.email },
                { icon: <Clock3 className="h-3.5 w-3.5" />, label: 'عضو منذ', value: formatDate(currentUser.createdAt) },
              ].map((r) => (
                <div key={r.label} className="rounded-lg border border-[#EDE4D6] bg-[#FCFAF6] p-2.5">
                  <p className="flex items-center gap-1 text-[9px] text-[#98A4AE]">{r.icon} {r.label}</p>
                  <p className="mt-0.5 truncate text-[11px] font-bold text-[#0E2233]" dir={r.label === 'البريد' || r.label === 'الهاتف' ? 'ltr' : 'rtl'}>{r.value}</p>
                </div>
              ))}
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {currentUser.role === 'admin' && <Button size="sm" variant="dark" onClick={() => navigate('admin')} icon={<LayoutDashboard className="h-4 w-4" />}>لوحة التحكم</Button>}
              {currentUser.role === 'merchant' && <Button size="sm" variant="dark" onClick={() => navigate('merchantApp')} icon={<ScanLine className="h-4 w-4" />}>تطبيق التاجر</Button>}
              <Button size="sm" variant="outline" onClick={() => navigate('home')} icon={<Store className="h-4 w-4" />}>تصفح الشركاء</Button>
              <Button size="sm" variant="ghost" onClick={logout} icon={<LogOut className="h-4 w-4" />}>تسجيل الخروج</Button>
            </div>
          </Card>

          <Card className="overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#EDE4D6] p-4">
              <div>
                <h2 className="flex items-center gap-2 text-sm font-extrabold text-[#0E2233]"><History className="h-4 w-4 text-[#0F766E]" /> سجل العمليات</h2>
                <p className="mt-0.5 text-[10px] text-[#98A4AE]">كل استخدام لكود OTD يُسجّل هنا تلقائياً.</p>
              </div>
              <Badge tone="ink">{myTxns.length} عملية</Badge>
            </div>
            {myTxns.length === 0 ? (
              <div className="p-6"><EmptyState title="لا توجد عمليات بعد" text="استخدم خصمك الأول من صفحة أي شريك في حلب." icon={<ReceiptText className="h-5 w-5" />} /></div>
            ) : (
              <div className="divide-y divide-[#F3EEE4]">
                {myTxns.slice(0, 8).map((t) => (
                  <div key={t.id} className="flex items-center gap-3 p-3">
                    <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#E7F4F1] text-[#0F766E]"><Percent className="h-4 w-4" /></span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-bold text-[#0E2233]">{t.merchantName}</p>
                      <p className="flex items-center gap-1 text-[9px] text-[#98A4AE]"><MapPin className="h-2.5 w-2.5" /> {t.branchName} · {formatDateTime(t.createdAt)}</p>
                    </div>
                    <div className="text-left">
                      <p className="text-[11px] font-extrabold text-[#0F766E]">−{formatNumber(t.discountAmount)} ل.س</p>
                      <p className="text-[9px] text-[#98A4AE]">{t.discountPct}% من {formatNumber(t.amount)}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card className="p-4">
            <p className="flex items-center gap-1.5 text-xs font-extrabold text-[#0E2233]"><Sparkles className="h-4 w-4 text-[#D4A24C]" /> صلاحيات حسابك</p>
            <div className="mt-2 grid gap-1.5 sm:grid-cols-2">
              {[
                { label: 'تصفح أسماء الشركاء', allowed: true },
                { label: 'رؤية نسب الخصم', allowed: active },
                { label: 'توليد كود OTD', allowed: active },
                { label: 'الهدية الترحيبية', allowed: active && !currentUser.welcomeGiftClaimed },
                { label: 'سجل التوفير', allowed: true },
                { label: 'إدارة المنصة', allowed: currentUser.role === 'admin' },
              ].map((p) => (
                <span key={p.label} className={`flex items-center gap-1.5 rounded-lg p-2 text-[10px] ${p.allowed ? 'bg-[#F2FAF8] text-[#0F5F59]' : 'bg-[#F3EEE4] text-[#8A7C68]'}`}>
                  {p.allowed ? <Check className="h-3 w-3" /> : <Lock className="h-3 w-3" />} {p.label}
                </span>
              ))}
            </div>
          </Card>

          {currentUser.role === 'admin' && (
            <div className="rounded-xl border border-[#E9E1D3] bg-white p-3 text-center">
              <button onClick={() => navigate('admin')} className="flex w-full items-center justify-center gap-1.5 text-xs font-bold text-[#0F766E]">الانتقال إلى لوحة التحكم الإدارية <ChevronLeft className="h-3.5 w-3.5" /></button>
            </div>
          )}
          <div className="text-center">
            <button onClick={() => navigate('home')} className="text-[10px] font-bold text-[#98A4AE]"><ArrowRight className="ml-1 inline h-3 w-3" /> العودة للرئيسية</button>
          </div>
        </div>
      </div>
    </div>
  );
}
