import { useEffect, useState } from 'react';
import type { FormEvent, ReactNode } from 'react';
import {
  ArrowLeft, BadgeCheck, Check, CheckCircle2, ChevronLeft, Clock3, Copy, Eye, Gift, KeyRound,
  Lock, Mail, MapPin, Percent, Phone, QrCode, ShieldCheck, ShoppingBag, Smartphone, Sparkles,
  Store, User, UserPlus, Users, Wallet,
} from 'lucide-react';
import { useStore } from '../app/store';
import { DEMO_ACCOUNTS } from '../app/data';
import { Badge, Button, Card, Field, Logo, RoleBadge } from '../components/ui';

function AuthShell({ children, mode }: { children: ReactNode; mode: string }) {
  const { navigate } = useStore();
  return (
    <div className="flex min-h-screen bg-[#FBF7F0]">
      <aside className="relative hidden w-[44%] flex-col justify-between overflow-hidden bg-[#0E2233] p-10 lg:flex">
        <div className="absolute inset-0 opacity-[0.16]" style={{ backgroundImage: 'radial-gradient(circle at 20% 20%, #D4A24C 0, transparent 45%), radial-gradient(circle at 85% 70%, #0F766E 0, transparent 50%)' }} />
        <div className="absolute -left-16 top-1/3 h-64 w-64 rounded-full border border-white/10" />
        <div className="absolute -left-6 top-1/2 h-40 w-40 rounded-full border border-[#D4A24C]/30" />
        <div className="relative">
          <Logo light />
        </div>
        <div className="relative">
          <Badge tone="gold" className="!bg-white/10 !text-[#F2D59B] !border-white/10">نادي الادخار الذكي في حلب · الإصدار 2.0</Badge>
          <h1 className="mt-5 text-4xl font-extrabold leading-[1.3] text-white" style={{ fontFamily: 'Cairo, sans-serif' }}>
            اشتراك واحد يوفّر عليك
            <span className="text-[#E9B949]"> كل زيارة</span>
          </h1>
          <p className="mt-4 max-w-md text-sm leading-7 text-white/65">
            خصومات دائمة بين 15% و30% لدى أفضل المطاعم والكافيهات والمتاجر في مدينة حلب. بطاقة عضوية رقمية، نظام OTD آمن، وهدية ترحيبية.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-3 text-white">
            {[
              { icon: <Store className="h-4 w-4" />, value: '20+', label: 'شريك' },
              { icon: <Percent className="h-4 w-4" />, value: '30%', label: 'خصم دائم' },
              { icon: <ShieldCheck className="h-4 w-4" />, value: '60ث', label: 'كود متغيّر' },
            ].map((s) => (
              <div key={s.label} className="rounded-2xl border border-white/10 bg-white/[0.06] p-3">
                <span className="text-[#E9B949]">{s.icon}</span>
                <p className="mt-2 text-lg font-extrabold">{s.value}</p>
                <p className="text-[10px] text-white/50">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="relative rounded-2xl border border-white/10 bg-white/[0.04] p-4">
          <div className="flex items-center justify-between text-[11px] text-white/50">
            <span>لديك حساب؟</span>
            <button onClick={() => navigate('login')} className="font-bold text-[#F2D59B]">تسجيل الدخول</button>
          </div>
        </div>
      </aside>
      <main className="flex w-full flex-col lg:w-[56%]">
        <div className="flex items-center justify-between border-b border-[#EDE4D6] px-5 py-4 lg:hidden">
          <Logo />
          <div className="flex items-center gap-2">
            {mode !== 'login' && <Button size="sm" variant="ghost" onClick={() => navigate('login')}>دخول</Button>}
            {mode !== 'register' && <Button size="sm" variant="outline" onClick={() => navigate('register')}>حساب جديد</Button>}
          </div>
        </div>
        <div className="flex flex-1 items-center justify-center px-5 py-10 sm:px-10">
          <div className="w-full max-w-md">{children}</div>
        </div>
        <p className="px-6 pb-6 text-center text-[10px] text-[#9AA5AE]">© 2026 حلب خصومات — جميع الحقوق محفوظة · نسخة عرض تفاعلية</p>
      </main>
    </div>
  );
}

export function WelcomePage() {
  const { navigate, continueAsGuest, login } = useStore();
  return (
    <div className="min-h-screen bg-[#FBF7F0]">
      <header className="border-b border-[#EDE4D6] bg-[#FBF7F0]/90">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <Logo />
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => navigate('login')}>تسجيل الدخول</Button>
            <Button size="sm" icon={<UserPlus className="h-4 w-4" />} onClick={() => navigate('register')}>إنشاء حساب</Button>
          </div>
        </div>
      </header>

      <section className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-12 lg:grid-cols-[1.1fr_0.9fr] lg:py-16">
        <div>
          <Badge tone="teal" className="mb-4"><Sparkles className="h-3 w-3" /> الإصدار 2.0 · انطلق في حلب</Badge>
          <h1 className="text-4xl font-extrabold leading-[1.25] text-[#0E2233] sm:text-5xl" style={{ fontFamily: 'Cairo, sans-serif' }}>
            خصوماتك <span className="relative inline-block"><span className="relative z-10 text-[#E76F51]">الدائمة</span><span className="absolute inset-x-0 bottom-1 z-0 h-3 rounded bg-[#F6D9A8]" /></span><br />في كل مكان بحلب
          </h1>
          <p className="mt-5 max-w-lg text-base leading-8 text-[#5B6B79]">
            اشترك في <b className="text-[#0E2233]">حلب خصومات</b> واحصل على خصومات بين 15% و30% طوال العام في المطاعم والكافيهات والمتاجر والصالونات — ليست كوبونات مؤقتة، بل عضوية كاملة مع هدية ترحيبية.
          </p>
          <div className="mt-7 flex flex-wrap items-center gap-3">
            <Button size="lg" icon={<UserPlus className="h-5 w-5" />} onClick={() => navigate('register')}>أنشئ حسابك مجاناً</Button>
            <Button size="lg" variant="outline" icon={<Eye className="h-5 w-5" />} onClick={continueAsGuest}>تصفح التطبيق كزائر</Button>
          </div>
          <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-[#7B8794]">
            <span className="flex items-center gap-1.5"><Check className="h-4 w-4 text-[#0F766E]" /> بدون رسوم حتى تختار الاشتراك</span>
            <span className="flex items-center gap-1.5"><Check className="h-4 w-4 text-[#0F766E]" /> الهدية الترحيبية فور الاشتراك</span>
          </div>

          <div className="mt-9 grid grid-cols-3 gap-3">
            {[
              { value: '20+', label: 'شريك في حلب', icon: <Store className="h-4 w-4" /> },
              { value: '15–30%', label: 'خصم دائم', icon: <Percent className="h-4 w-4" /> },
              { value: '3,000', label: 'مشترك مستهدف', icon: <Users className="h-4 w-4" /> },
            ].map((s) => (
              <div key={s.label} className="rounded-2xl border border-[#E9E1D3] bg-white p-4">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#E7F4F1] text-[#0F766E]">{s.icon}</span>
                <p className="mt-3 text-xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>{s.value}</p>
                <p className="text-[11px] text-[#7B8794]">{s.label}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-sm">
          <div className="absolute -inset-6 rounded-[2.5rem] bg-gradient-to-br from-[#E76F51]/15 via-[#D4A24C]/10 to-[#0F766E]/15 blur-2xl" />
          <div className="relative overflow-hidden rounded-[2rem] border border-white/60 bg-[#0E2233] p-6 text-white shadow-2xl">
            <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-[#0F766E]/40 blur-2xl" />
            <div className="absolute -bottom-14 -right-10 h-44 w-44 rounded-full bg-[#E76F51]/30 blur-2xl" />
            <div className="relative flex items-start justify-between">
              <Logo light />
              <Badge tone="gold" className="!border-white/10 !bg-white/10 !text-[#F2D59B]"><BadgeCheck className="h-3 w-3" /> عضوية نشطة</Badge>
            </div>
            <div className="relative mt-10">
              <p className="text-[10px] tracking-[0.25em] text-white/40">بطاقة العضوية الرقمية</p>
              <p className="mt-2 text-2xl font-extrabold" style={{ fontFamily: 'Cairo, sans-serif' }}>سارة الحلبي</p>
              <p className="mt-1 font-mono text-xs tracking-wider text-[#F2D59B]" dir="ltr">ALD-2026-00041</p>
            </div>
            <div className="relative mt-6 flex items-end justify-between">
              <div className="grid grid-cols-3 gap-1.5 rounded-xl bg-white p-2">
                {Array.from({ length: 42 }).map((_, i) => (
                  <span key={i} className={`h-1.5 w-1.5 rounded-[1px] ${[0, 1, 2, 5, 6, 7, 10, 13, 14, 17, 21, 22, 25, 28, 30, 33, 36, 39, 41].includes(i) ? 'bg-[#0E2233]' : 'bg-transparent'}`} />
                ))}
              </div>
              <div className="text-left">
                <p className="text-[9px] text-white/40">صالحة حتى</p>
                <p className="text-xs font-bold">مايو 2027</p>
              </div>
            </div>
            <div className="relative mt-5 flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.06] p-3 text-[11px] text-white/70">
              <QrCode className="h-4 w-4 text-[#E9B949]" />
              نظام OTD · كود استخدام لمرة واحدة يتغيّر كل 60 ثانية
            </div>
          </div>

          <div className="absolute -bottom-5 -right-3 rounded-2xl border border-[#E9E1D3] bg-white p-3 shadow-xl">
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#FBF3DF] text-[#A57C1B]"><Gift className="h-4 w-4" /></span>
              <div>
                <p className="text-[10px] text-[#7B8794]">هدية ترحيبية</p>
                <p className="text-xs font-extrabold text-[#0E2233]">وجبة مجانية 🎁</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="border-y border-[#EDE4D6] bg-white/60">
        <div className="mx-auto grid max-w-6xl gap-4 px-5 py-10 sm:grid-cols-3">
          {[
            { icon: <Store className="h-5 w-5" />, title: '١. اختر محلك', text: 'تصفح أكثر من 20 شريكاً في حلب حسب الفئة والموقع.' },
            { icon: <QrCode className="h-5 w-5" />, title: '٢. أظهر كود OTD', text: 'كود لمرة واحدة صالح 60 ثانية، لا يمكن تصويره أو إعادة استخدامه.' },
            { icon: <Wallet className="h-5 w-5" />, title: '٣. وفّر فوراً', text: 'خصمك يُطبّق مباشرة على الفاتورة، وتتابع توفيرك في حسابك.' },
          ].map((s) => (
            <div key={s.title} className="rounded-2xl border border-[#E9E1D3] bg-[#FCFAF6] p-5">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#0F766E] text-white">{s.icon}</span>
              <p className="mt-3 font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>{s.title}</p>
              <p className="mt-1 text-xs leading-6 text-[#6C7A87]">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-12">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>شركاؤنا الأوائل في حلب</h2>
          <Badge tone="outline"><MapPin className="h-3 w-3" /> المرحلة الأولى: حلب</Badge>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {[
            { name: 'مطعم الأمير', emoji: '🍽️', pct: '20%' },
            { name: 'كافيه المدينة', emoji: '☕', pct: '25%' },
            { name: 'بوتيك النور', emoji: '👗', pct: '30%' },
            { name: 'حلويات الشام', emoji: '🧁', pct: '20%' },
          ].map((m) => (
            <Card key={m.name} className="flex items-center gap-3 p-3.5">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-[#F3EEE4] text-xl">{m.emoji}</span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold text-[#0E2233]">{m.name}</p>
                <p className="text-[10px] text-[#7B8794]">خصم حتى {m.pct}</p>
              </div>
            </Card>
          ))}
        </div>

        <div className="mt-10 overflow-hidden rounded-3xl border border-[#E9E1D3] bg-[#0E2233] p-6 text-white sm:p-8">
          <div className="flex flex-wrap items-center justify-between gap-5">
            <div>
              <Badge tone="gold" className="!border-white/10 !bg-white/10 !text-[#F2D59B]"><Clock3 className="h-3 w-3" /> تجربة سريعة للمراجعين</Badge>
              <h3 className="mt-3 text-2xl font-extrabold" style={{ fontFamily: 'Cairo, sans-serif' }}>حسابات تجريبية جاهزة للاختبار</h3>
              <p className="mt-1 text-xs text-white/60">اختر الدور، أو أنشئ حسابك الجديد لاختبار رحلة الاشتراك والهدية الترحيبية.</p>
            </div>
            <Button variant="gold" onClick={() => navigate('login')} icon={<ArrowLeft className="h-4 w-4" />}>الدخول بحساب تجريبي</Button>
          </div>
          <div className="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            {DEMO_ACCOUNTS.map((d) => (
              <button
                key={d.email}
                onClick={() => login(d.email, d.password)}
                className="group rounded-xl border border-white/10 bg-white/[0.05] p-3 text-right transition hover:border-[#E9B949]/50 hover:bg-white/[0.09]"
              >
                <div className="flex items-center gap-2">
                  <span className={`h-2 w-2 rounded-full ${d.color}`} />
                  <p className="text-xs font-bold text-white">{d.label}</p>
                </div>
                <p className="mt-1 truncate font-mono text-[10px] text-white/45" dir="ltr">{d.email}</p>
                <p className="mt-0.5 font-mono text-[10px] text-white/30" dir="ltr">{d.password}</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-[#EDE4D6] py-6 text-center text-[11px] text-[#9AA5AE]">
        حلب خصومات · دراسة جدوى متكاملة 2.0 · مايو 2026 — الواجهة التفاعلية لنظام العضوية والصلاحيات
      </footer>
    </div>
  );
}

export function LoginPage() {
  const { login, navigate, pendingUid } = useStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email.trim() || !password) {
      setError('يرجى إدخال البريد الإلكتروني وكلمة المرور');
      return;
    }
    setLoading(true);
    window.setTimeout(() => {
      const result = login(email, password);
      setLoading(false);
      if (!result.ok) {
        setError(result.error ?? 'تعذر تسجيل الدخول');
        if ((result.error ?? '').includes('غير مُفعّل')) navigate('register');
      }
    }, 450);
  };

  return (
    <AuthShell mode="login">
      <div className="mb-7">
        <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#E7F4F1] text-[#0F766E]"><KeyRound className="h-6 w-6" /></span>
        <h1 className="mt-4 text-2xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>تسجيل الدخول</h1>
        <p className="mt-1 text-sm text-[#6C7A87]">أهلاً بعودتك. سجّل دخولك للوصول إلى بطاقة العضوية الرقمية وخصوماتك.</p>
      </div>

      {pendingUid && (
        <div className="mb-4 rounded-xl border border-[#F0E1BC] bg-[#FBF3DF] p-3 text-xs font-semibold text-[#8A6515]">
          لديك حساب قيد التحقق. أكمل رمز التأكيد من صفحة إنشاء الحساب.
        </div>
      )}

      <form onSubmit={submit} className="space-y-4">
        <Field
          label="البريد الإلكتروني"
          type="email"
          placeholder="name@example.com"
          icon={<Mail className="h-4 w-4" />}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          autoComplete="email"
        />
        <Field
          label="كلمة المرور"
          type="password"
          placeholder="••••••••"
          icon={<Lock className="h-4 w-4" />}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          autoComplete="current-password"
        />
        {error && <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-xs font-bold text-red-700">{error}</div>}
        <div className="flex items-center justify-between">
          <button type="button" onClick={() => navigate('forgot')} className="text-xs font-bold text-[#0F766E] hover:underline">نسيت كلمة المرور؟</button>
          <span className="flex items-center gap-1 text-[10px] text-[#98A4AE]"><ShieldCheck className="h-3.5 w-3.5" /> جلسة مؤمّنة</span>
        </div>
        <Button type="submit" full size="lg" loading={loading} icon={<KeyRound className="h-4 w-4" />}>دخول إلى حسابي</Button>
      </form>

      <div className="my-6 flex items-center gap-3 text-[10px] text-[#A9B2BA]"><span className="h-px flex-1 bg-[#E9E1D3]" />أو<button className="h-px flex-1 bg-[#E9E1D3]" onClick={() => navigate('register')} /></div>

      <Button variant="outline" full onClick={() => navigate('register')} icon={<UserPlus className="h-4 w-4" />}>إنشاء حساب جديد</Button>
      <button onClick={() => navigate('welcome')} className="mt-4 flex w-full items-center justify-center gap-1 text-xs font-semibold text-[#7B8794] hover:text-[#0E2233]">
        <ChevronLeft className="h-3.5 w-3.5" /> العودة إلى صفحة الترحيب
      </button>

      <div className="mt-7 rounded-2xl border border-[#E9E1D3] bg-white p-4">
        <p className="mb-2 flex items-center gap-1.5 text-[11px] font-bold text-[#31485B]"><Sparkles className="h-3.5 w-3.5 text-[#D4A24C]" /> حسابات تجريبية — اضغط للتعبئة</p>
        <div className="grid grid-cols-2 gap-2">
          {DEMO_ACCOUNTS.map((d) => (
            <button
              key={d.email}
              type="button"
              onClick={() => { setEmail(d.email); setPassword(d.password); setError(''); }}
              className="rounded-lg border border-[#EDE4D6] bg-[#FCFAF6] px-2.5 py-2 text-right transition hover:border-[#0F766E]"
            >
              <p className="text-[10px] font-bold text-[#0E2233]">{d.label}</p>
              <p className="truncate font-mono text-[9px] text-[#98A4AE]" dir="ltr">{d.email}</p>
            </button>
          ))}
        </div>
      </div>
    </AuthShell>
  );
}

export function RegisterPage() {
  const { signup, verifyAccount, pendingUid, resendVerification, navigate, notify, currentUser, role } = useStore();
  const [form, setForm] = useState({ name: '', phone: '', email: '', password: '', confirm: '', terms: false });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [codeError, setCodeError] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (role === 'merchant') navigate('merchantApp');
  }, [role, navigate]);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (form.name.trim().length < 3) errs.name = 'أدخل الاسم الكامل (3 أحرف على الأقل)';
    if (!/^[0-9+\s-]{8,}$/.test(form.phone.trim())) errs.phone = 'أدخل رقم هاتف صالحاً';
    if (!/^\S+@\S+\.\S+$/.test(form.email.trim())) errs.email = 'أدخل بريداً إلكترونياً صالحاً';
    if (form.password.length < 6) errs.password = 'كلمة المرور 6 أحرف على الأقل';
    if (form.password !== form.confirm) errs.confirm = 'كلمتا المرور غير متطابقتين';
    if (!form.terms) errs.terms = 'يجب الموافقة على الشروط وسياسة الخصوصية';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setLoading(true);
    window.setTimeout(() => {
      const res = signup({ name: form.name, email: form.email, phone: form.phone, password: form.password });
      setLoading(false);
      if (!res.ok) {
        setErrors({ email: res.error ?? 'تعذر إنشاء الحساب' });
        return;
      }
      notify('تم إنشاء الحساب. أدخل رمز التحقق لإكمال التسجيل');
    }, 550);
  };

  const verify = (e: FormEvent) => {
    e.preventDefault();
    setCodeError('');
    const res = verifyAccount(code);
    if (!res.ok) setCodeError(res.error ?? 'رمز غير صحيح');
  };

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText('123456');
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      notify('تعذر النسخ، الرمز هو 123456', 'info');
    }
  };

  if (pendingUid) {
    return (
      <AuthShell mode="register">
        <div className="rounded-3xl border border-[#E9E1D3] bg-white p-6">
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#E7F4F1] text-[#0F766E]"><Smartphone className="h-6 w-6" /></span>
          <h1 className="mt-4 text-2xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>تحقّق من بريدك</h1>
          <p className="mt-1 text-sm text-[#6C7A87]">أرسلنا رمزاً من 6 أرقام إلى بريدك الإلكتروني لإكمال إنشاء الحساب.</p>

          <div className="mt-5 flex items-center justify-between rounded-2xl border border-dashed border-[#0F766E]/40 bg-[#F2FAF8] p-4">
            <div>
              <p className="text-[10px] font-bold text-[#0F766E]">رمز العرض التجريبي</p>
              <p className="font-mono text-2xl font-extrabold tracking-[0.3em] text-[#0E2233]" dir="ltr">123456</p>
            </div>
            <button onClick={copyCode} className="flex items-center gap-1.5 rounded-lg bg-white px-3 py-2 text-[11px] font-bold text-[#0F766E] shadow-sm">
              {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />} {copied ? 'تم النسخ' : 'نسخ'}
            </button>
          </div>

          <form onSubmit={verify} className="mt-5 space-y-4">
            <Field
              label="رمز التحقق"
              inputMode="numeric"
              placeholder="— — — — — —"
              value={code}
              maxLength={6}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
              icon={<KeyRound className="h-4 w-4" />}
              error={codeError}
              hint="رمز صالح لمدة 10 دقائق. لم يصلك؟ أعد الإرسال."
              className="!text-center !tracking-[0.5em] !text-lg !font-bold"
            />
            <Button type="submit" full size="lg" icon={<CheckCircle2 className="h-4 w-4" />}>تأكيد الحساب والمتابعة</Button>
          </form>
          <div className="mt-4 flex items-center justify-between text-[11px]">
            <button onClick={resendVerification} className="font-bold text-[#0F766E] hover:underline">إعادة إرسال الرمز</button>
            <button onClick={() => navigate('welcome')} className="font-semibold text-[#7B8794]">لاحقاً</button>
          </div>
        </div>
      </AuthShell>
    );
  }

  if (currentUser) {
    return (
      <AuthShell mode="register">
        <Card className="p-6 text-center">
          <BadgeCheck className="mx-auto h-12 w-12 text-[#0F766E]" />
          <h1 className="mt-3 text-xl font-extrabold text-[#0E2233]">أنت مسجّل الدخول بالفعل</h1>
          <p className="mt-1 text-sm text-[#6C7A87]">{currentUser.name} — <RoleBadge role={currentUser.role} /></p>
          <Button className="mt-5" full onClick={() => navigate(currentUser.role === 'admin' ? 'admin' : currentUser.role === 'merchant' ? 'merchantApp' : 'home')}>المتابعة إلى حسابي</Button>
        </Card>
      </AuthShell>
    );
  }

  return (
    <AuthShell mode="register">
      <div className="mb-6">
        <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#FCEAE6] text-[#E76F51]"><UserPlus className="h-6 w-6" /></span>
        <h1 className="mt-4 text-2xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>إنشاء حساب جديد</h1>
        <p className="mt-1 text-sm text-[#6C7A87]">حساب مجاني للتصفح. الاشتراك المدفوع اختياري ويُفعّل الخصومات والهدية الترحيبية.</p>
      </div>

      <form onSubmit={submit} className="space-y-3.5">
        <Field label="الاسم الكامل" placeholder="مثال: سارة الحلبي" icon={<User className="h-4 w-4" />} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} error={errors.name} required />
        <div className="grid gap-3.5 sm:grid-cols-2">
          <Field label="رقم الهاتف" type="tel" placeholder="+963 9XX XXX XXX" icon={<Phone className="h-4 w-4" />} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} error={errors.phone} required />
          <Field label="البريد الإلكتروني" type="email" placeholder="name@example.com" icon={<Mail className="h-4 w-4" />} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} error={errors.email} required />
        </div>
        <div className="grid gap-3.5 sm:grid-cols-2">
          <Field label="كلمة المرور" type="password" placeholder="6 أحرف على الأقل" icon={<Lock className="h-4 w-4" />} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} error={errors.password} required />
          <Field label="تأكيد كلمة المرور" type="password" placeholder="أعد كتابة كلمة المرور" icon={<ShieldCheck className="h-4 w-4" />} value={form.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value })} error={errors.confirm} required />
        </div>

        <label className="flex items-start gap-2 rounded-xl border border-[#EDE4D6] bg-[#FCFAF6] p-3 text-[11px] leading-5 text-[#5B6B79]">
          <input type="checkbox" checked={form.terms} onChange={(e) => setForm({ ...form, terms: e.target.checked })} className="mt-0.5 h-4 w-4 accent-[#0F766E]" />
          <span>أوافق على <b className="text-[#0E2233]">شروط الاستخدام</b> وسياسة الخصوصية، وعلى استخدام بياناتي لإدارة العضوية والخصومات.</span>
        </label>
        {errors.terms && <p className="text-[11px] font-bold text-red-600">{errors.terms}</p>}

        <Button type="submit" full size="lg" loading={loading} icon={<UserPlus className="h-4 w-4" />}>إنشاء الحساب</Button>
      </form>

      <div className="mt-5 flex items-center justify-between text-xs text-[#7B8794]">
        <span>لديك حساب؟</span>
        <button onClick={() => navigate('login')} className="font-bold text-[#0F766E] hover:underline">تسجيل الدخول</button>
      </div>
      <button onClick={() => navigate('welcome')} className="mt-4 flex w-full items-center justify-center gap-1 text-xs font-semibold text-[#7B8794] hover:text-[#0E2233]">
        <ChevronLeft className="h-3.5 w-3.5" /> العودة إلى صفحة الترحيب
      </button>
    </AuthShell>
  );
}

export function ForgotPasswordPage() {
  const { notify } = useStore();
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setError('أدخل بريداً إلكترونياً صالحاً');
      return;
    }
    setError('');
    setLoading(true);
    window.setTimeout(() => {
      setLoading(false);
      setSent(true);
      notify('تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك', 'success');
    }, 700);
  };

  return (
    <AuthShell mode="forgot">
      <div className="mb-6">
        <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#FBF3DF] text-[#A57C1B]"><KeyRound className="h-6 w-6" /></span>
        <h1 className="mt-4 text-2xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>نسيت كلمة المرور؟</h1>
        <p className="mt-1 text-sm text-[#6C7A87]">أدخل بريدك الإلكتروني وسنرسل لك رابطاً آمناً لإعادة تعيين كلمة المرور.</p>
      </div>

      {sent ? (
        <Card className="p-6 text-center">
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-emerald-50 text-emerald-600"><Mail className="h-7 w-7" /></span>
          <h2 className="mt-4 text-lg font-extrabold text-[#0E2233]">تفقّد بريدك الإلكتروني</h2>
          <p className="mt-1 text-sm leading-6 text-[#6C7A87]">
            أرسلنا رابط إعادة التعيين إلى <b className="text-[#0E2233]" dir="ltr">{email}</b>. الرابط صالح لمدة 30 دقيقة.
          </p>
          <Button className="mt-5" full variant="outline" onClick={() => setSent(false)}>إرسال إلى بريد آخر</Button>
        </Card>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <Field label="البريد الإلكتروني المسجل" type="email" placeholder="name@example.com" icon={<Mail className="h-4 w-4" />} value={email} onChange={(e) => setEmail(e.target.value)} error={error} required />
          <Button type="submit" full size="lg" loading={loading} icon={<Mail className="h-4 w-4" />}>إرسال رابط الاستعادة</Button>
        </form>
      )}
      <div className="mt-5 rounded-xl border border-[#E9E1D3] bg-white p-3 text-[11px] leading-6 text-[#6C7A87]">
        <b className="text-[#0E2233]">ملاحظة:</b> لأسباب أمنية لا نكشف ما إذا كان البريد مسجلاً أم لا. في هذه النسخة التجريبية يُحاكى إرسال الرابط فقط.
      </div>
      <a href="#login" onClick={(e) => { e.preventDefault(); window.history.back(); }} className="mt-5 flex items-center justify-center gap-1 text-xs font-bold text-[#0F766E]">
        <ChevronLeft className="h-3.5 w-3.5" /> العودة لتسجيل الدخول
      </a>
      <div className="mt-4 flex items-center justify-center gap-2 text-[10px] text-[#98A4AE]"><ShoppingBag className="h-3.5 w-3.5" /> بياناتك محمية وفق سياسة الخصوصية</div>
    </AuthShell>
  );
}
