import { useMemo, useState } from 'react';
import {
  Activity, BarChart3, ChevronLeft, Download, Eye, Filter, FlaskConical, LayoutDashboard,
  Megaphone, Pencil, Percent, Plus, ReceiptText, RefreshCcw, Search, ShieldCheck, Sparkles,
  Store, ToggleLeft, ToggleRight, TrendingUp, UserCog, Users, X,
} from 'lucide-react';
import { useStore } from '../app/store';
import { CATEGORIES, PLANS } from '../app/data';
import type { Role } from '../app/data';
import {
  downloadCsv, formatDate, formatDateTime, formatNumber, isActiveSubscriber, subscriptionDaysLeft,
} from '../app/logic';
import { Avatar, Badge, Button, Card, EmptyState, Field, Modal, RoleBadge, SectionTitle, Stat } from '../components/ui';
import { QaPanel } from './QA';

type Tab = 'dashboard' | 'merchants' | 'transactions' | 'users' | 'ads' | 'qa';

const TABS: { id: Tab; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'نظرة عامة', icon: <LayoutDashboard className="h-4 w-4" /> },
  { id: 'merchants', label: 'الشركاء', icon: <Store className="h-4 w-4" /> },
  { id: 'transactions', label: 'المعاملات', icon: <ReceiptText className="h-4 w-4" /> },
  { id: 'users', label: 'المستخدمون', icon: <UserCog className="h-4 w-4" /> },
  { id: 'ads', label: 'الإعلانات', icon: <Megaphone className="h-4 w-4" /> },
  { id: 'qa', label: 'مركز الجودة', icon: <FlaskConical className="h-4 w-4" /> },
];

export function AdminPage() {
  const { users, merchants, transactions, navigate, toggleMerchantActive, toggleFeatured, toggleAd, addMerchant, updateUserRole, adsEnabled, resetDemoData, notify, logout, currentUser } = useStore();
  const [tab, setTab] = useState<Tab>('dashboard');
  const [merchantQuery, setMerchantQuery] = useState('');
  const [txnQuery, setTxnQuery] = useState('');
  const [userQuery, setUserQuery] = useState('');
  const [addOpen, setAddOpen] = useState(false);
  const [newMerchant, setNewMerchant] = useState({ name: '', category: 'restaurant', discount: '20', description: '', address: '' });

  const subscribers = users.filter((u) => u.role === 'subscriber');
  const activeSubs = subscribers.filter((u) => isActiveSubscriber(u));
  const revenue = activeSubs.reduce((sum, u) => sum + (PLANS.find((p) => p.id === u.plan)?.price ?? 20), 0);
  const merchantRevenue = merchants.filter((m) => m.active).length * 150;
  const totalDiscounts = transactions.reduce((s, t) => s + t.discountAmount, 0);
  const flagged = transactions.filter((t) => t.status === 'flagged');
  const expired = subscribers.filter((u) => !isActiveSubscriber(u));

  const monthLabels = useMemo(() => Array.from({ length: 5 }).map((_, i) => {
    const d = new Date();
    d.setMonth(d.getMonth() - (4 - i));
    return new Intl.DateTimeFormat('ar-SY', { month: 'short' }).format(d);
  }), []);

  const monthly = useMemo(() => monthLabels.map((label, idx) => {
    const target = new Date();
    target.setMonth(target.getMonth() - (4 - idx));
    const start = new Date(target.getFullYear(), target.getMonth(), 1).getTime();
    const end = new Date(target.getFullYear(), target.getMonth() + 1, 1).getTime();
    const monthTxns = transactions.filter((t) => {
      const at = new Date(t.createdAt).getTime();
      return at >= start && at < end;
    });
    return { label, count: monthTxns.length, value: monthTxns.reduce((s, t) => s + t.discountAmount, 0) };
  }), [monthLabels, transactions]);

  const topMerchants = useMemo(() => [...merchants]
    .map((m) => ({ m, count: transactions.filter((t) => t.merchantId === m.id).length, value: transactions.filter((t) => t.merchantId === m.id).reduce((s, t) => s + t.discountAmount, 0) }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 5), [merchants, transactions]);

  const filteredMerchants = merchants.filter((m) => `${m.name} ${m.categoryLabel}`.includes(merchantQuery.trim()));
  const filteredTxns = transactions.filter((t) => `${t.userName} ${t.merchantName} ${t.code} ${t.branchName}`.includes(txnQuery.trim()));
  const filteredUsers = users.filter((u) => `${u.name} ${u.email} ${u.memberId}`.includes(userQuery.trim()));

  const exportTxns = () => {
    downloadCsv('haleb-admin-transactions.csv', ['رقم العملية', 'المشترك', 'الشريك', 'الفرع', 'الكود', 'نسبة الخصم', 'الفاتورة', 'الخصم', 'التاريخ', 'الحالة'], transactions.map((t) => [t.id, t.userName, t.merchantName, t.branchName, t.code, `${t.discountPct}%`, t.amount, t.discountAmount, t.createdAt, t.status === 'completed' ? 'مكتملة' : 'معلّمة']));
    notify('تم تصدير تقرير المعاملات الكامل');
  };

  const exportMerchants = () => {
    downloadCsv('haleb-merchants.csv', ['الشريك', 'التصنيف', 'الخصم', 'الفروع', 'الحالة', 'الخصم المميز'], merchants.map((m) => [m.name, m.categoryLabel, `${m.discount}%`, m.branches.length, m.active ? 'مفعّل' : 'موقوف', m.featured ? 'نعم' : 'لا']));
    notify('تم تصدير قائمة الشركاء');
  };

  const submitMerchant = () => {
    if (newMerchant.name.trim().length < 2 || !newMerchant.address.trim() || !newMerchant.description.trim()) {
      notify('أدخل اسم الشريك والوصف والعنوان', 'error');
      return;
    }
    const discount = Number(newMerchant.discount);
    if (!Number.isFinite(discount) || discount < 10 || discount > 30) {
      notify('نسبة الخصم يجب أن تكون بين 10% و30% وفق شروط العضوية', 'error');
      return;
    }
    const cat = CATEGORIES.find((c) => c.id === newMerchant.category);
    addMerchant({ name: newMerchant.name.trim(), category: newMerchant.category, categoryLabel: cat?.label ?? 'أخرى', discount, description: newMerchant.description.trim(), address: newMerchant.address.trim() });
    setAddOpen(false);
    setNewMerchant({ name: '', category: 'restaurant', discount: '20', description: '', address: '' });
    notify('تمت إضافة الشريك وتفعيله في الكتالوج');
  };

  const statusOfRole = (r: Role) => r;

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#0E2233] text-white"><LayoutDashboard className="h-4 w-4" /></span>
            <div>
              <h1 className="text-xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>لوحة تحكم حلب خصومات</h1>
              <p className="text-[10px] text-[#7B8794]">إدارة المنصة · صلاحيات المدير الكاملة · {formatDate(new Date().toISOString())}</p>
            </div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button size="sm" variant="outline" onClick={() => navigate('home')} icon={<Eye className="h-4 w-4" />}>عرض التطبيق</Button>
          <Button size="sm" variant="ghost" onClick={() => navigate('profile')} icon={<Avatar name={currentUser?.name ?? 'مدير'} size={22} />}>حسابي</Button>
          <Button size="sm" variant="danger" onClick={logout} icon={<X className="h-4 w-4" />}>خروج</Button>
        </div>
      </div>

      <div className="mb-4 flex gap-1.5 overflow-x-auto rounded-2xl border border-[#E9E1D3] bg-white p-1.5">
        {TABS.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`flex shrink-0 items-center gap-1.5 rounded-xl px-3.5 py-2.5 text-[11px] font-bold transition ${tab === t.id ? 'bg-[#0E2233] text-white shadow-md' : 'text-[#5B6B79] hover:bg-[#F5F0E7]'}`}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {tab === 'dashboard' && (
        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Stat icon={<Users className="h-4 w-4" />} label="المشتركون النشطون" value={String(activeSubs.length)} hint={`${subscribers.length} إجمالي المسجلين`} />
            <Stat icon={<Store className="h-4 w-4" />} label="الشركاء المفعّلون" value={String(merchants.filter((m) => m.active).length)} hint={`${merchants.length} شريكاً في الكتالوج`} tone="gold" />
            <Stat icon={<ReceiptText className="h-4 w-4" />} label="المعاملات المسجلة" value={String(transactions.length)} hint={`${flagged.length} بحاجة لمراجعة`} tone="ink" />
            <Stat icon={<Percent className="h-4 w-4" />} label="إجمالي الخصومات" value={`${formatNumber(totalDiscounts)}`} hint="ليرة سورية ممنوحة" tone="rose" />
          </div>

          <div className="grid gap-3 lg:grid-cols-3">
            <Card className="p-4 lg:col-span-2">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-extrabold text-[#0E2233]">نشاط الخصومات عبر الأشهر</p>
                  <p className="text-[10px] text-[#98A4AE]">قيمة الخصومات الممنوحة (ل.س) وعدد المعاملات</p>
                </div>
                <Badge tone="outline"><BarChart3 className="h-3 w-3" /> آخر 5 أشهر</Badge>
              </div>
              <div className="mt-5 flex h-44 items-end gap-3">
                {monthly.map((m) => {
                  const max = Math.max(...monthly.map((x) => x.value), 1);
                  return (
                    <div key={m.label} className="flex flex-1 flex-col items-center gap-1.5">
                      <span className="text-[9px] font-bold text-[#7B8794]">{formatNumber(m.value)}</span>
                      <div className="flex w-full flex-1 items-end">
                        <div className="w-full rounded-t-lg bg-gradient-to-t from-[#0F766E] to-[#5EEAD4] transition-all" style={{ height: `${Math.max(8, (m.value / max) * 100)}%` }} />
                      </div>
                      <span className="text-[10px] font-bold text-[#4A5A68]">{m.label}</span>
                      <span className="text-[9px] text-[#B4BEC6]">{m.count} عملية</span>
                    </div>
                  );
                })}
              </div>
            </Card>
            <Card className="p-4">
              <p className="text-xs font-extrabold text-[#0E2233]">الإيرادات المتعاقد عليها</p>
              <p className="mt-1 text-2xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>${formatNumber(revenue + merchantRevenue)}</p>
              <p className="text-[10px] text-[#98A4AE]">اشتراكات أعضاء + رسوم شركاء سنوية</p>
              <div className="mt-3 space-y-2">
                <div>
                  <div className="flex justify-between text-[10px]"><span className="text-[#7B8794]">اشتراكات الأعضاء</span><span className="font-bold">${formatNumber(revenue)}</span></div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-[#F3EEE4]"><div className="h-full rounded-full bg-[#0F766E]" style={{ width: `${Math.min(100, (revenue / Math.max(revenue + merchantRevenue, 1)) * 100)}%` }} /></div>
                </div>
                <div>
                  <div className="flex justify-between text-[10px]"><span className="text-[#7B8794]">رسوم الشركاء</span><span className="font-bold">${formatNumber(merchantRevenue)}</span></div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-[#F3EEE4]"><div className="h-full rounded-full bg-[#D4A24C]" style={{ width: `${Math.min(100, (merchantRevenue / Math.max(revenue + merchantRevenue, 1)) * 100)}%` }} /></div>
                </div>
              </div>
              <div className="mt-3 rounded-xl bg-[#F2FAF8] p-2.5 text-[10px] text-[#0F5F59]">
                <p className="flex items-center gap-1 font-bold"><TrendingUp className="h-3.5 w-3.5" /> افتراضات دراسة الجدوى</p>
                <p className="mt-0.5 text-[#4E7A75]">$20/عضو سنوياً · $150/شريك سنوياً · مستهدف السنة الأولى: 3,000 عضو و80 شريكاً</p>
              </div>
            </Card>
          </div>

          <div className="grid gap-3 lg:grid-cols-[1.4fr_1fr]">
            <Card className="overflow-hidden">
              <div className="flex items-center justify-between border-b border-[#EDE4D6] p-4">
                <p className="flex items-center gap-1.5 text-xs font-extrabold text-[#0E2233]"><Activity className="h-4 w-4 text-[#0F766E]" /> أحدث المعاملات</p>
                <button onClick={() => setTab('transactions')} className="flex items-center gap-1 text-[10px] font-bold text-[#0F766E]">عرض الكل <ChevronLeft className="h-3 w-3" /></button>
              </div>
              <div className="divide-y divide-[#F3EEE4]">
                {transactions.slice(0, 5).map((t) => (
                  <div key={t.id} className="flex items-center gap-3 p-3">
                    <Avatar name={t.userName} size={32} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[11px] font-bold text-[#0E2233]">{t.userName}</p>
                      <p className="truncate text-[9px] text-[#98A4AE]">{t.merchantName} · {t.branchName} · {formatDateTime(t.createdAt)}</p>
                    </div>
                    <div className="text-left">
                      <p className="text-[11px] font-extrabold text-[#0F766E]">−{formatNumber(t.discountAmount)} ل.س</p>
                      <Badge tone={t.status === 'completed' ? 'green' : 'red'}>{t.status === 'completed' ? 'مكتملة' : 'معلّمة'}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
            <div className="space-y-3">
              <Card className="p-4">
                <p className="flex items-center gap-1.5 text-xs font-extrabold text-[#0E2233]"><ShieldCheck className="h-4 w-4 text-[#0F766E]" /> تنبيهات تحتاج إجراءً</p>
                <div className="mt-2 space-y-1.5">
                  <button onClick={() => setTab('users')} className="flex w-full items-center justify-between rounded-lg border border-[#F0E1BC] bg-[#FBF3DF] p-2.5 text-right">
                    <span className="text-[10px] font-bold text-[#8A6515]">{expired.length} عضوية غير نشطة / منتهية</span>
                    <ChevronLeft className="h-3.5 w-3.5 text-[#A57C1B]" />
                  </button>
                  <button onClick={() => setTab('merchants')} className="flex w-full items-center justify-between rounded-lg border border-[#EDE4D6] bg-[#FCFAF6] p-2.5 text-right">
                    <span className="text-[10px] font-bold text-[#5B6B79]">{merchants.filter((m) => !m.active).length} شريك موقوف عن العرض</span>
                    <ChevronLeft className="h-3.5 w-3.5 text-[#98A4AE]" />
                  </button>
                  <button onClick={() => setTab('transactions')} className="flex w-full items-center justify-between rounded-lg border border-red-100 bg-red-50 p-2.5 text-right">
                    <span className="text-[10px] font-bold text-red-700">{flagged.length} معاملة معلّمة للتدقيق (منع التلاعب)</span>
                    <ChevronLeft className="h-3.5 w-3.5 text-red-500" />
                  </button>
                </div>
              </Card>
              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <p className="flex items-center gap-1.5 text-xs font-extrabold text-[#0E2233]"><Sparkles className="h-4 w-4 text-[#D4A24C]" /> أعلى الشركاء</p>
                  <Badge tone="outline">حسب الخصومات</Badge>
                </div>
                <div className="mt-2 space-y-1.5">
                  {topMerchants.map(({ m, value, count }, i) => (
                    <div key={m.id} className="flex items-center gap-2">
                      <span className="w-3 text-[10px] font-extrabold text-[#B08968]">{i + 1}</span>
                      <span className="text-sm">{m.emoji}</span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[10px] font-bold text-[#0E2233]">{m.name}</p>
                        <div className="mt-0.5 h-1 overflow-hidden rounded-full bg-[#F3EEE4]"><div className="h-full rounded-full bg-[#E76F51]" style={{ width: `${Math.min(100, (value / (topMerchants[0]?.value || 1)) * 100)}%` }} /></div>
                      </div>
                      <span className="text-[9px] font-bold text-[#0F766E]">{count} عملية</span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>

          <Card className="flex flex-wrap items-center justify-between gap-3 p-4">
            <div>
              <p className="text-[11px] font-extrabold text-[#0E2233]">أدوات العرض التجريبي</p>
              <p className="text-[10px] text-[#98A4AE]">إعادة تعيين جميع البيانات التجريبية إلى حالتها الأصلية (المستخدمون، الشركاء، المعاملات).</p>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={exportMerchants} icon={<Download className="h-3.5 w-3.5" />}>تصدير الشركاء</Button>
              <Button size="sm" variant="danger" onClick={resetDemoData} icon={<RefreshCcw className="h-3.5 w-3.5" />}>إعادة تعيين البيانات</Button>
            </div>
          </Card>
        </div>
      )}

      {tab === 'merchants' && (
        <Card className="overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#EDE4D6] p-4">
            <SectionTitle title="إدارة الشركاء" subtitle="إضافة، تفعيل، وإيقاف الشركاء وإدارة ظهورهم المميز." />
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[#9AA7B1]" />
                <input value={merchantQuery} onChange={(e) => setMerchantQuery(e.target.value)} placeholder="بحث عن شريك..." className="w-40 rounded-lg border border-[#E4DCCD] bg-white py-2 pr-8 pl-2 text-[10px] outline-none focus:border-[#0F766E]" />
              </div>
              <Button size="sm" variant="outline" onClick={exportMerchants} icon={<Download className="h-3.5 w-3.5" />}>تصدير</Button>
              <Button size="sm" onClick={() => setAddOpen(true)} icon={<Plus className="h-3.5 w-3.5" />}>شريك جديد</Button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-right text-[11px]">
              <thead className="bg-[#FBF7F0] text-[10px] text-[#7B8794]">
                <tr>
                  <th className="p-3 font-bold">الشريك</th>
                  <th className="p-3 font-bold">التصنيف</th>
                  <th className="p-3 font-bold">الخصم</th>
                  <th className="p-3 font-bold">الفروع</th>
                  <th className="p-3 font-bold">المعاملات</th>
                  <th className="p-3 font-bold">مميز</th>
                  <th className="p-3 font-bold">الحالة</th>
                  <th className="p-3 font-bold">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F3EEE4]">
                {filteredMerchants.map((m) => (
                  <tr key={m.id} className="hover:bg-[#FCFAF6]">
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <span className={`grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br text-sm ${m.gradient}`}>{m.emoji}</span>
                        <div><p className="font-bold text-[#0E2233]">{m.name}</p><p className="text-[9px] text-[#98A4AE]">{m.rating} ★ · {m.reviews} تقييم</p></div>
                      </div>
                    </td>
                    <td className="p-3 text-[#6C7A87]">{m.categoryLabel}</td>
                    <td className="p-3"><Badge tone="teal">{m.discount}%</Badge></td>
                    <td className="p-3 text-[#6C7A87]">{m.branches.length}</td>
                    <td className="p-3 font-bold">{transactions.filter((t) => t.merchantId === m.id).length}</td>
                    <td className="p-3"><button onClick={() => { toggleFeatured(m.id); notify(`${m.name}: ${m.featured ? 'إزالة' : 'إضافة'} الظهور المميز`); }} className={`rounded-full px-2 py-1 text-[9px] font-bold ${m.featured ? 'bg-[#FBF3DF] text-[#A57C1B]' : 'bg-[#F3EEE4] text-[#8A7C68]'}`}>{m.featured ? 'مميز' : 'عادي'}</button></td>
                    <td className="p-3"><Badge tone={m.active ? 'green' : 'red'}>{m.active ? 'مفعّل' : 'موقوف'}</Badge></td>
                    <td className="p-3">
                      <div className="flex items-center gap-1">
                        <button onClick={() => { toggleMerchantActive(m.id); notify(`تم ${m.active ? 'إيقاف' : 'تفعيل'} ${m.name}`); }} title="تفعيل/إيقاف" className={`rounded-lg p-1.5 ${m.active ? 'bg-[#F2FAF8] text-[#0F766E]' : 'bg-[#F3EEE4] text-[#8A7C68]'}`}>{m.active ? <ToggleRight className="h-4 w-4" /> : <ToggleLeft className="h-4 w-4" />}</button>
                        <button onClick={() => navigate('merchant', { merchantId: m.id })} title="عرض" className="rounded-lg bg-[#EAF0F3] p-1.5 text-[#31485B]"><Eye className="h-4 w-4" /></button>
                        <button onClick={() => notify('تعديل تفاصيل الشريك متاح في تطبيق الإدارة الكامل', 'info')} title="تعديل" className="rounded-lg bg-[#F3EEE4] p-1.5 text-[#7A6242]"><Pencil className="h-4 w-4" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filteredMerchants.length === 0 && <div className="p-6"><EmptyState title="لا يوجد شركاء مطابقون" text="جرّب كلمة بحث أخرى." icon={<Store className="h-5 w-5" />} /></div>}
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-[#EDE4D6] p-3 text-[10px] text-[#98A4AE]">
            <span>{filteredMerchants.length} شريكاً معروضاً · الصلاحية: مدير المنصة فقط</span>
            <span className="flex items-center gap-1"><ShieldCheck className="h-3 w-3" /> كل تغيير ينعكس فوراً في التطبيق</span>
          </div>
        </Card>
      )}

      {tab === 'transactions' && (
        <Card className="overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#EDE4D6] p-4">
            <SectionTitle title="تقارير المعاملات" subtitle="سجل كامل لكل أكواد OTD المستخدمة وتسوية الخصومات." />
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[#9AA7B1]" />
                <input value={txnQuery} onChange={(e) => setTxnQuery(e.target.value)} placeholder="بحث بالاسم أو الكود..." className="w-44 rounded-lg border border-[#E4DCCD] bg-white py-2 pr-8 pl-2 text-[10px] outline-none focus:border-[#0F766E]" />
              </div>
              <Button size="sm" variant="outline" onClick={exportTxns} icon={<Download className="h-3.5 w-3.5" />}>تصدير CSV</Button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-right text-[11px]">
              <thead className="bg-[#FBF7F0] text-[10px] text-[#7B8794]">
                <tr>
                  <th className="p-3 font-bold">العملية</th>
                  <th className="p-3 font-bold">المشترك</th>
                  <th className="p-3 font-bold">الشريك</th>
                  <th className="p-3 font-bold">الفرع</th>
                  <th className="p-3 font-bold">كود OTD</th>
                  <th className="p-3 font-bold">الفاتورة</th>
                  <th className="p-3 font-bold">الخصم</th>
                  <th className="p-3 font-bold">التاريخ</th>
                  <th className="p-3 font-bold">الحالة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F3EEE4]">
                {filteredTxns.map((t) => (
                  <tr key={t.id} className="hover:bg-[#FCFAF6]">
                    <td className="p-3 font-mono text-[9px] text-[#98A4AE]" dir="ltr">{t.id}</td>
                    <td className="p-3"><div className="flex items-center gap-1.5"><Avatar name={t.userName} size={24} /><span className="font-bold text-[#0E2233]">{t.userName}</span></div></td>
                    <td className="p-3 text-[#5B6B79]">{t.merchantName}</td>
                    <td className="p-3 text-[10px] text-[#7B8794]">{t.branchName}</td>
                    <td className="p-3 font-mono text-[#6C7A87]" dir="ltr">{t.code}</td>
                    <td className="p-3 font-bold">{formatNumber(t.amount)}</td>
                    <td className="p-3 font-bold text-[#0F766E]">−{formatNumber(t.discountAmount)}</td>
                    <td className="p-3 text-[10px] text-[#98A4AE]">{formatDateTime(t.createdAt)}</td>
                    <td className="p-3"><Badge tone={t.status === 'completed' ? 'green' : 'red'}>{t.status === 'completed' ? 'مكتملة' : 'معلّمة'}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filteredTxns.length === 0 && <div className="p-6"><EmptyState title="لا توجد معاملات مطابقة" text="جرّب تعديل البحث." icon={<ReceiptText className="h-5 w-5" />} /></div>}
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-[#EDE4D6] p-3 text-[10px] text-[#98A4AE]">
            <span>{filteredTxns.length} معاملة · إجمالي الخصومات {formatNumber(filteredTxns.reduce((s, t) => s + t.discountAmount, 0))} ل.س</span>
            <span className="flex items-center gap-1"><Filter className="h-3 w-3" /> التصدير يشمل كل المعاملات وليس المفلترة فقط</span>
          </div>
        </Card>
      )}

      {tab === 'users' && (
        <Card className="overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#EDE4D6] p-4">
            <SectionTitle title="المستخدمون والصلاحيات" subtitle="إدارة الأدوار: مشترك / تاجر / مدير المنصة. الدور يحدد الوصول في التطبيقات الثلاثة." />
            <div className="relative">
              <Search className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[#9AA7B1]" />
              <input value={userQuery} onChange={(e) => setUserQuery(e.target.value)} placeholder="بحث بالاسم أو البريد..." className="w-48 rounded-lg border border-[#E4DCCD] bg-white py-2 pr-8 pl-2 text-[10px] outline-none focus:border-[#0F766E]" />
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-right text-[11px]">
              <thead className="bg-[#FBF7F0] text-[10px] text-[#7B8794]">
                <tr>
                  <th className="p-3 font-bold">المستخدم</th>
                  <th className="p-3 font-bold">رقم العضوية</th>
                  <th className="p-3 font-bold">الدور الحالي</th>
                  <th className="p-3 font-bold">الاشتراك</th>
                  <th className="p-3 font-bold">التوفير</th>
                  <th className="p-3 font-bold">مسجل منذ</th>
                  <th className="p-3 font-bold">تغيير الدور</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F3EEE4]">
                {filteredUsers.map((u) => (
                  <tr key={u.uid} className="hover:bg-[#FCFAF6]">
                    <td className="p-3"><div className="flex items-center gap-2"><Avatar name={u.name} size={28} tone={u.role === 'admin' ? 'ink' : u.role === 'merchant' ? 'gold' : 'teal'} /><div><p className="font-bold text-[#0E2233]">{u.name}</p><p className="text-[9px] text-[#98A4AE]" dir="ltr">{u.email}</p></div></div></td>
                    <td className="p-3 font-mono text-[9px] text-[#6C7A87]" dir="ltr">{u.memberId}</td>
                    <td className="p-3"><RoleBadge role={u.role} /></td>
                    <td className="p-3">{u.role === 'subscriber' ? (isActiveSubscriber(u) ? <div><Badge tone="green">نشط</Badge><p className="mt-0.5 text-[9px] text-[#98A4AE]">متبقٍ {subscriptionDaysLeft(u)} يوم</p></div> : <Badge tone="red">غير مشترك</Badge>) : <span className="text-[10px] text-[#98A4AE]">لا ينطبق</span>}</td>
                    <td className="p-3 font-bold text-[#0F766E]">{formatNumber(u.savings)} ل.س</td>
                    <td className="p-3 text-[10px] text-[#98A4AE]">{formatDate(u.createdAt)}</td>
                    <td className="p-3">
                      <select value={statusOfRole(u.role)} onChange={(e) => { updateUserRole(u.uid, e.target.value as Role); notify(`تم تحديث دور ${u.name} إلى ${e.target.value}`); }} className="rounded-lg border border-[#E4DCCD] bg-white px-2 py-1 text-[10px] font-bold text-[#0E2233] outline-none focus:border-[#0F766E]">
                        <option value="subscriber">مشترك</option>
                        <option value="merchant">تاجر</option>
                        <option value="admin">مدير</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="border-t border-[#EDE4D6] p-3 text-[10px] text-[#98A4AE]">
            <span className="flex items-center gap-1"><ShieldCheck className="h-3 w-3" /> في Firestore تُدار الأدوار عبر Custom Claims، ولا يستطيع المستخدم تعديل دوره بنفسه.</span>
          </div>
        </Card>
      )}

      {tab === 'ads' && (
        <div className="space-y-4">
          <Card className="flex flex-wrap items-center justify-between gap-2 p-4">
            <SectionTitle title="الإعلانات المميزة" subtitle="مساحات الشركاء في الصفحة الرئيسية والإشعارات المدفوعة." />
            <Badge tone="gold"><Megaphone className="h-3 w-3" /> إيراد إضافي $50/شهر</Badge>
          </Card>
          <div className="grid gap-3 sm:grid-cols-2">
            {merchants.filter((m) => m.ad).map((m) => {
              const enabled = adsEnabled[m.id] !== false;
              return (
                <Card key={m.id} className="overflow-hidden">
                  <div className={`bg-gradient-to-l ${m.gradient} p-4 text-white`}>
                    <div className="flex items-center justify-between">
                      <Badge tone="gold" className="!border-white/20 !bg-white/90 !text-[#8A6515]">{m.ad?.badge}</Badge>
                      <span className="text-2xl">{m.emoji}</span>
                    </div>
                    <p className="mt-2 text-sm font-extrabold">{m.ad?.title}</p>
                    <p className="text-[10px] text-white/75">{m.ad?.text}</p>
                  </div>
                  <div className="p-4">
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="rounded-lg bg-[#FCFAF6] p-2"><p className="text-[9px] text-[#98A4AE]">ظهور</p><p className="text-xs font-extrabold text-[#0E2233]">{formatNumber(m.reviews * 240)}</p></div>
                      <div className="rounded-lg bg-[#FCFAF6] p-2"><p className="text-[9px] text-[#98A4AE]">نقرات</p><p className="text-xs font-extrabold text-[#0E2233]">{formatNumber(m.reviews * 31)}</p></div>
                      <div className="rounded-lg bg-[#FCFAF6] p-2"><p className="text-[9px] text-[#98A4AE]">CTR</p><p className="text-xs font-extrabold text-[#0F766E]">12.9%</p></div>
                    </div>
                    <div className="mt-3 flex items-center justify-between">
                      <Badge tone={enabled ? 'green' : 'red'}>{enabled ? 'نشط في الرئيسية' : 'موقوف'}</Badge>
                      <Button size="sm" variant={enabled ? 'outline' : 'primary'} onClick={() => { toggleAd(m.id); notify(`تم ${enabled ? 'إيقاف' : 'تفعيل'} إعلان ${m.name}`); }} icon={enabled ? <ToggleRight className="h-4 w-4" /> : <ToggleLeft className="h-4 w-4" />}>{enabled ? 'إيقاف' : 'تفعيل'}</Button>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
          <Card className="p-4">
            <p className="text-xs font-extrabold text-[#0E2233]">حزم الإعلانات المتاحة</p>
            <div className="mt-2 grid gap-2 sm:grid-cols-3">
              {[
                { name: 'بانر الرئيسية', price: '$50/شهر', desc: 'ظهور في أعلى قائمة الشركاء' },
                { name: 'إشعار مدفوع', price: '$40/حملة', desc: 'إرسال إشعار للمشتركين النشطين' },
                { name: 'رعاية فعالية', price: '$150/فعالية', desc: 'يوم خصومات مفتوح برعاية الشريك' },
              ].map((p) => (
                <div key={p.name} className="rounded-xl border border-[#EDE4D6] p-3">
                  <p className="text-[11px] font-extrabold text-[#0E2233]">{p.name}</p>
                  <p className="text-base font-extrabold text-[#0F766E]">{p.price}</p>
                  <p className="text-[9px] text-[#98A4AE]">{p.desc}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {tab === 'qa' && <QaPanel />}

      <Modal open={addOpen} onClose={() => setAddOpen(false)} title="إضافة شريك جديد" wide>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="اسم الشريك" placeholder="مثال: مطعم الياسمين" value={newMerchant.name} onChange={(e) => setNewMerchant({ ...newMerchant, name: e.target.value })} required />
          <label className="block">
            <span className="mb-1.5 block text-xs font-bold text-[#31485B]">التصنيف</span>
            <select value={newMerchant.category} onChange={(e) => setNewMerchant({ ...newMerchant, category: e.target.value })} className="w-full rounded-xl border border-[#E4DCCD] bg-[#FCFAF6] px-3 py-2.5 text-sm outline-none focus:border-[#0F766E]">
              {CATEGORIES.filter((c) => c.id !== 'all').map((c) => <option key={c.id} value={c.id}>{c.emoji} {c.label}</option>)}
            </select>
          </label>
          <Field label="نسبة الخصم (%)" type="number" min={10} max={30} value={newMerchant.discount} onChange={(e) => setNewMerchant({ ...newMerchant, discount: e.target.value })} hint="وفق العضوية: بين 10% و30%" required />
          <Field label="عنوان الفرع الرئيسي" placeholder="الحي، الشارع" value={newMerchant.address} onChange={(e) => setNewMerchant({ ...newMerchant, address: e.target.value })} required />
          <label className="block sm:col-span-2">
            <span className="mb-1.5 block text-xs font-bold text-[#31485B]">وصف مختصر</span>
            <textarea value={newMerchant.description} onChange={(e) => setNewMerchant({ ...newMerchant, description: e.target.value })} rows={3} className="w-full rounded-xl border border-[#E4DCCD] bg-[#FCFAF6] px-3 py-2.5 text-sm outline-none focus:border-[#0F766E]" placeholder="وصف الخدمة وما يميز الشريك..." />
          </label>
        </div>
        <div className="mt-4 flex items-center justify-between rounded-xl bg-[#FBF3DF] p-3 text-[10px] text-[#8A7433]">
          <span>سيُضاف الشريك كشريك مفعّل ويظهر للمشتركين مباشرة.</span>
          <Badge tone="gold"><Store className="h-3 w-3" /> نسبة الخصم قابلة للتعديل لاحقاً</Badge>
        </div>
        <div className="mt-4 flex gap-2">
          <Button full variant="ghost" onClick={() => setAddOpen(false)} icon={<X className="h-4 w-4" />}>إلغاء</Button>
          <Button full onClick={submitMerchant} icon={<Plus className="h-4 w-4" />}>إضافة الشريك</Button>
        </div>
      </Modal>
    </div>
  );
}
