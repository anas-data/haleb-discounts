import { useMemo, useState } from 'react';
import {
  ArrowRight, BadgeCheck, Banknote, CalendarDays, Check, CheckCircle2, ChevronLeft, Coffee, CreditCard,
  Crown, Gift, Lock, PartyPopper, Percent, ShieldCheck, Smartphone, Sparkles, Store, Ticket,
  Timer, Utensils, Wallet, X,
} from 'lucide-react';
import { useStore } from '../app/store';
import { PLANS } from '../app/data';
import type { Gift as GiftType, Plan } from '../app/data';
import { formatDate, isActiveSubscriber, subscriptionDaysLeft } from '../app/logic';
import { Badge, Button, Card, EmptyState, Modal } from '../components/ui';

const PAYMENT_METHODS = [
  { id: 'card', label: 'بطاقة مصرفية', hint: 'فيزا / ماستركارد / مدينة', icon: <CreditCard className="h-5 w-5" /> },
  { id: 'wallet', label: 'محفظة إلكترونية', hint: 'سيرياتيل كاش / MTN كاش', icon: <Smartphone className="h-5 w-5" /> },
  { id: 'voucher', label: 'قسيمة اشتراك', hint: 'أدخل رمز القسيمة', icon: <Ticket className="h-5 w-5" /> },
];

export function SubscriptionPage() {
  const { currentUser, navigate, subscribe, notify, gifts } = useStore();
  const active = isActiveSubscriber(currentUser);
  const [planId, setPlanId] = useState<string>('annual');
  const [method, setMethod] = useState('card');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState<Plan | null>(null);
  const plan = PLANS.find((p) => p.id === planId) ?? PLANS[2];
  const launch = !active;
  const total = launch ? Number((plan.price * 0.5).toFixed(2)) : plan.price;

  if (!currentUser) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20">
        <EmptyState title="تحتاج حساباً لمتابعة الاشتراك" text="أنشئ حساباً مجانياً أولاً، ثم اختر الباقة المناسبة." icon={<Lock className="h-5 w-5" />} />
        <div className="mt-4 flex justify-center gap-2">
          <Button onClick={() => navigate('register')}>إنشاء حساب</Button>
          <Button variant="outline" onClick={() => navigate('login')}>تسجيل الدخول</Button>
        </div>
      </div>
    );
  }

  const pay = () => {
    setLoading(true);
    window.setTimeout(() => {
      const res = subscribe(plan.id);
      setLoading(false);
      if (!res.ok) {
        notify(res.error ?? 'تعذر إتمام الاشتراك', 'error');
        return;
      }
      setSuccess(res.plan ?? plan);
      notify('تم تفعيل اشتراكك بنجاح — بطاقة العضوية جاهزة');
    }, 1100);
  };

  if (success) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-10">
        <Card className="overflow-hidden">
          <div className="relative bg-gradient-to-l from-[#0F766E] to-[#115E59] p-7 text-center text-white">
            <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at 30% 20%, #fff 0, transparent 40%)' }} />
            <span className="relative mx-auto grid h-16 w-16 place-items-center rounded-full bg-white/15"><CheckCircle2 className="h-9 w-9" /></span>
            <h1 className="relative mt-4 text-2xl font-extrabold" style={{ fontFamily: 'Cairo, sans-serif' }}>تم تفعيل الاشتراك بنجاح!</h1>
            <p className="relative mt-1 text-xs text-white/75">مرحباً بك في نادي حلب خصومات · باقة {success.name}</p>
          </div>
          <div className="p-6">
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-[#E9E1D3] p-3">
                <p className="text-[10px] text-[#98A4AE]">رقم العضوية</p>
                <p className="mt-1 font-mono text-sm font-extrabold tracking-wider text-[#0E2233]" dir="ltr">{currentUser.memberId}</p>
              </div>
              <div className="rounded-xl border border-[#E9E1D3] p-3">
                <p className="text-[10px] text-[#98A4AE]">تاريخ الانتهاء</p>
                <p className="mt-1 text-sm font-extrabold text-[#0E2233]">{formatDate(currentUser.subscriptionEndDate)}</p>
              </div>
            </div>
            <div className="mt-3 rounded-xl border border-[#C7E7E1] bg-[#F2FAF8] p-3">
              <p className="flex items-center gap-1.5 text-[11px] font-extrabold text-[#0F5F59]"><Gift className="h-4 w-4" /> الخطوة التالية: هديتك الترحيبية</p>
              <p className="mt-1 text-[10px] leading-5 text-[#4E7A75]">لديك {gifts.length} خيارات، اختر واحدة فقط. تظهر الهدايا داخل حسابك للاستخدام لاحقاً.</p>
            </div>
            <div className="mt-5 flex flex-col gap-2 sm:flex-row">
              <Button full onClick={() => navigate('gifts')} icon={<Gift className="h-4 w-4" />}>اختر هديتك الترحيبية</Button>
              <Button full variant="outline" onClick={() => navigate('home')} icon={<Store className="h-4 w-4" />}>ابدأ التصفح الآن</Button>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <button onClick={() => navigate('home')} className="flex items-center gap-1.5 text-xs font-bold text-[#6C7A87] hover:text-[#0E2233]"><ArrowRight className="h-4 w-4" /> العودة للرئيسية</button>
        <Badge tone="teal"><ShieldCheck className="h-3 w-3" /> دفع آمن · بيانات محمية</Badge>
      </div>

      {active ? (
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#C7E7E1] bg-[#F2FAF8] p-4">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#0F766E] text-white"><Crown className="h-5 w-5" /></span>
            <div>
              <p className="text-sm font-extrabold text-[#0E2233]">اشتراكك نشط — {subscriptionDaysLeft(currentUser)} يوماً متبقياً</p>
              <p className="text-[11px] text-[#4E7A75]">ينتهي في {formatDate(currentUser.subscriptionEndDate)} · يمكنك التجديد مبكراً دون فقدان الأيام المتبقية.</p>
            </div>
          </div>
          <Button size="sm" variant="outline" onClick={() => navigate('profile')}>إدارة العضوية</Button>
        </div>
      ) : (
        <div className="mb-6 rounded-2xl border border-[#F0E1BC] bg-gradient-to-l from-[#FBF3DF] to-[#FDF9EF] p-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-white text-[#A57C1B] shadow-sm"><Sparkles className="h-4 w-4" /></span>
              <div>
                <p className="text-xs font-extrabold text-[#5C4412]">عرض الإطلاق — خصم 50% لأول اشتراك</p>
                <p className="text-[10px] text-[#8A7433]">سعر المسجلين الأوائل · يبقى سعرك ثابتاً عند التجديد لهذه السنة.</p>
              </div>
            </div>
            <Badge tone="gold"><Percent className="h-3 w-3" /> يبدأ من $1.67 شهرياً</Badge>
          </div>
        </div>
      )}

      <div className="mb-5 text-center">
        <h1 className="text-2xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>اختر باقتك واستمتع بالخصومات</h1>
        <p className="mt-1 text-xs text-[#6C7A87]">عضوية حلب خصومات تمنحك خصوماً دائمة بين 15% و30%، بدون حدود استخدام معقولة.</p>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        {PLANS.map((p) => {
          const selected = p.id === planId;
          return (
            <button
              key={p.id}
              onClick={() => setPlanId(p.id)}
              className={`relative rounded-2xl border p-5 text-right transition ${selected ? 'border-[#0F766E] bg-[#F5FAF8] shadow-lg shadow-[#0F766E]/10' : 'border-[#E9E1D3] bg-white hover:border-[#B4CBC6]'}`}
            >
              {p.badge && <span className="absolute -top-2.5 right-4 rounded-full bg-[#D4A24C] px-2.5 py-1 text-[9px] font-extrabold text-[#2A1D08]">{p.badge}</span>}
              <div className="flex items-center justify-between">
                <p className="text-sm font-extrabold text-[#0E2233]">{p.name}</p>
                <span className={`grid h-5 w-5 place-items-center rounded-full border ${selected ? 'border-[#0F766E] bg-[#0F766E] text-white' : 'border-[#CFC5B4]'}`}>{selected && <Check className="h-3 w-3" />}</span>
              </div>
              <p className="mt-3 text-3xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>
                ${p.price}
                <span className="text-xs font-bold text-[#98A4AE]"> / {p.months === 1 ? 'شهر' : p.months === 6 ? '6 أشهر' : 'سنة'}</span>
              </p>
              <p className="text-[11px] text-[#7B8794]">${p.perMonth.toFixed(2)} شهرياً</p>
              {p.save && <Badge tone="green" className="mt-2"><Percent className="h-3 w-3" /> {p.save} مقارنةً بالشهري</Badge>}
            </button>
          );
        })}
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-[1.2fr_0.8fr]">
        <Card className="p-5">
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-sm font-extrabold text-[#0E2233]"><Wallet className="h-4 w-4 text-[#0F766E]" /> طريقة الدفع</h2>
            <Badge tone="outline">نسخة تجريبية</Badge>
          </div>
          <div className="mt-3 space-y-2">
            {PAYMENT_METHODS.map((m) => (
              <button
                key={m.id}
                onClick={() => setMethod(m.id)}
                className={`flex w-full items-center gap-3 rounded-xl border p-3 text-right transition ${method === m.id ? 'border-[#0F766E] bg-[#F5FAF8]' : 'border-[#E9E1D3] hover:border-[#CFC5B4]'}`}
              >
                <span className={`grid h-9 w-9 place-items-center rounded-lg ${method === m.id ? 'bg-[#0F766E] text-white' : 'bg-[#F3EEE4] text-[#7A6242]'}`}>{m.icon}</span>
                <div className="flex-1">
                  <p className="text-xs font-extrabold text-[#0E2233]">{m.label}</p>
                  <p className="text-[10px] text-[#98A4AE]">{m.hint}</p>
                </div>
                <span className={`grid h-4 w-4 place-items-center rounded-full border ${method === m.id ? 'border-[#0F766E] bg-[#0F766E] text-white' : 'border-[#CFC5B4]'}`}>{method === m.id && <Check className="h-2.5 w-2.5" />}</span>
              </button>
            ))}
          </div>

          {method === 'card' && (
            <div className="mt-3 grid gap-2 rounded-xl border border-[#EDE4D6] bg-[#FCFAF6] p-3 sm:grid-cols-2">
              <label className="sm:col-span-2">
                <span className="text-[10px] font-bold text-[#5B6B79]">رقم البطاقة</span>
                <input placeholder="4242 4242 4242 4242" dir="ltr" className="mt-1 w-full rounded-lg border border-[#E4DCCD] bg-white px-3 py-2 font-mono text-xs outline-none focus:border-[#0F766E]" />
              </label>
              <label>
                <span className="text-[10px] font-bold text-[#5B6B79]">تاريخ الانتهاء</span>
                <input placeholder="MM/YY" dir="ltr" className="mt-1 w-full rounded-lg border border-[#E4DCCD] bg-white px-3 py-2 font-mono text-xs outline-none focus:border-[#0F766E]" />
              </label>
              <label>
                <span className="text-[10px] font-bold text-[#5B6B79]">CVV</span>
                <input placeholder="123" dir="ltr" className="mt-1 w-full rounded-lg border border-[#E4DCCD] bg-white px-3 py-2 font-mono text-xs outline-none focus:border-[#0F766E]" />
              </label>
              <p className="sm:col-span-2 text-[9px] text-[#98A4AE]">لن تُخصم أي مبالغ حقيقية. هذه محاكاة لتدفق الدفع تمهيداً لربط بوابة الدفع المحلية.</p>
            </div>
          )}
          {method === 'wallet' && (
            <div className="mt-3 rounded-xl border border-[#EDE4D6] bg-[#FCFAF6] p-3 text-center">
              <Smartphone className="mx-auto h-6 w-6 text-[#0F766E]" />
              <p className="mt-1 text-[11px] font-bold text-[#0E2233]">محفظة إلكترونية</p>
              <p className="text-[10px] text-[#7B8794]">سيصلك طلب دفع على هاتفك بعد الضغط على «تأكيد الاشتراك».</p>
            </div>
          )}
          {method === 'voucher' && (
            <div className="mt-3 rounded-xl border border-[#EDE4D6] bg-[#FCFAF6] p-3">
              <label>
                <span className="text-[10px] font-bold text-[#5B6B79]">رمز القسيمة</span>
                <input placeholder="HALAB-GIFT-XXXX" dir="ltr" className="mt-1 w-full rounded-lg border border-[#E4DCCD] bg-white px-3 py-2 font-mono text-xs outline-none focus:border-[#0F766E]" />
              </label>
            </div>
          )}

          <div className="mt-4 rounded-xl bg-[#FBF7F0] p-3">
            <p className="flex items-center gap-1.5 text-[10px] font-bold text-[#7A6242]"><ShieldCheck className="h-3.5 w-3.5" /> ضمان الخصم</p>
            <p className="mt-1 text-[10px] leading-5 text-[#8A7433]">إذا لم تحصل على خصم من أي شريك ملتزم، نعيد لك قيمة الاشتراك بالكامل خلال 14 يوماً.</p>
          </div>
        </Card>

        <div className="space-y-3">
          <Card className="p-5">
            <h2 className="text-sm font-extrabold text-[#0E2233]">ملخص الطلب</h2>
            <div className="mt-3 space-y-2 text-xs">
              <div className="flex items-center justify-between text-[#5B6B79]"><span>باقة {plan.name}</span><span>${plan.price.toFixed(2)}</span></div>
              {launch && <div className="flex items-center justify-between text-[#0F766E]"><span>خصم الإطلاق (50%)</span><span>−${(plan.price * 0.5).toFixed(2)}</span></div>}
              <div className="flex items-center justify-between text-[#5B6B79]"><span>الهدية الترحيبية</span><span className="font-bold text-[#0F766E]">مجاناً</span></div>
              <div className="flex items-center justify-between border-t border-[#EDE4D6] pt-2 text-base font-extrabold text-[#0E2233]"><span>الإجمالي</span><span>${total.toFixed(2)}</span></div>
              <p className="text-[9px] text-[#98A4AE]">السعر بالدولار الأمريكي · يُحوّل إلى الليرة عند الدفع الفعلي</p>
            </div>
            <Button full size="lg" className="mt-4" loading={loading} onClick={pay} icon={<Lock className="h-4 w-4" />}>تأكيد الاشتراك والدفع</Button>
            <p className="mt-2 text-center text-[9px] text-[#98A4AE]">بالضغط أنت توافق على شروط العضوية وسياسة الاستخدام</p>
          </Card>

          <Card className="p-4">
            <p className="text-xs font-extrabold text-[#0E2233]">ماذا تحصل عليه؟</p>
            <ul className="mt-2 space-y-2">
              {[
                'خصومات دائمة 15%–30% في 20+ محل',
                'بطاقة عضوية رقمية ورقم عضوية فريد',
                'كود OTD لمرة واحدة صالح 60 ثانية',
                'هدية ترحيبية فورية من شركائنا',
                'سجل معاملات وتوفير شخصي',
              ].map((f) => (
                <li key={f} className="flex items-start gap-1.5 text-[10px] leading-5 text-[#5B6B79]"><Check className="mt-0.5 h-3 w-3 shrink-0 text-[#0F766E]" /> {f}</li>
              ))}
            </ul>
          </Card>

          <div className="rounded-xl border border-[#E9E1D3] bg-white p-3 text-center">
            <p className="text-[10px] text-[#98A4AE]">لديك قسيمة أو سؤال؟</p>
            <button onClick={() => notify('فريق الدعم متاح يومياً من 9 صباحاً حتى 9 مساءً على واتساب', 'info')} className="mt-1 text-[11px] font-bold text-[#0F766E]">تواصل مع خدمة العملاء</button>
          </div>
        </div>
      </div>
    </div>
  );
}

const GIFT_ICONS: Record<GiftType['icon'], React.ReactNode> = {
  gift: <Gift className="h-6 w-6" />,
  meal: <Utensils className="h-6 w-6" />,
  coffee: <Coffee className="h-6 w-6" />,
};

export function GiftSelectionPage() {
  const { currentUser, gifts, claimGift, navigate, notify } = useStore();
  const available = useMemo(
    () => gifts.filter((g) => (currentUser?.giftsOptions ?? []).includes(g.id)),
    [gifts, currentUser],
  );
  const [selected, setSelected] = useState<GiftType | null>(null);
  const [copied, setCopied] = useState(false);
  const active = isActiveSubscriber(currentUser);
  const claimed = currentUser?.welcomeGiftClaimed ?? false;
  const chosen = gifts.find((g) => g.id === currentUser?.selectedGiftId) ?? null;

  const copy = async () => {
    if (!currentUser?.giftCode) return;
    try {
      await navigator.clipboard.writeText(currentUser.giftCode);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      notify('تعذر النسخ', 'error');
    }
  };

  if (!currentUser) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20">
        <EmptyState title="سجّل الدخول لعرض هديتك" text="الهدايا الترحيبية متاحة لأعضاء حلب خصومات." icon={<Gift className="h-5 w-5" />} />
        <div className="mt-4 flex justify-center gap-2"><Button onClick={() => navigate('register')}>إنشاء حساب</Button><Button variant="outline" onClick={() => navigate('login')}>دخول</Button></div>
      </div>
    );
  }

  if (!active) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20">
        <EmptyState title="الهدية الترحيبية للمشتركين" text="اشترك أولاً لتختار هديتك الترحيبية من شركائنا في حلب." icon={<Lock className="h-5 w-5" />} />
        <div className="mt-4 text-center"><Button onClick={() => navigate('subscription')}>اشترك والأفضل الآن</Button></div>
      </div>
    );
  }

  const confirm = () => {
    if (!selected) return;
    const res = claimGift(selected.id);
    if (!res.ok) {
      notify(res.error ?? 'تعذر اختيار الهدية', 'error');
      return;
    }
    setSelected(null);
    notify(`تم استلام هديتك: ${selected.title} 🎉`);
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6">
      <div className="mb-4 flex items-center justify-between">
        <button onClick={() => navigate('home')} className="flex items-center gap-1.5 text-xs font-bold text-[#6C7A87] hover:text-[#0E2233]"><ArrowRight className="h-4 w-4" /> الرئيسية</button>
        <Badge tone={claimed ? 'green' : 'gold'}><Gift className="h-3 w-3" /> {claimed ? 'تم استلام الهدية' : 'هدية ترحيبية متاحة'}</Badge>
      </div>

      <div className="mb-6 text-center">
        <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-[#E76F51] to-[#D4A24C] text-white shadow-lg shadow-[#E76F51]/20"><Gift className="h-7 w-7" /></span>
        <h1 className="mt-3 text-2xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>{claimed ? 'هديتك جاهزة للاستخدام' : 'اختر هديتك الترحيبية'}</h1>
        <p className="mx-auto mt-1 max-w-lg text-xs leading-6 text-[#6C7A87]">
          {claimed
            ? 'احتفظ بكود الهدية وأظهره لدى الشريك المانح ضمن فترة الصلاحية المحددة.'
            : 'نقدّر انضمامك إلى حلب خصومات. اختر واحدة من الهدايا التالية — بعد الاختيار تُخفى بقية الخيارات نهائياً.'}
        </p>
      </div>

      {claimed && chosen ? (
        <div className="grid gap-4 sm:grid-cols-[1fr_1.1fr]">
          <Card className={`overflow-hidden bg-gradient-to-br ${chosen.tone} p-6 text-white`}>
            <div className="flex items-start justify-between">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white/20 backdrop-blur">{GIFT_ICONS[chosen.icon]}</span>
              <Badge tone="gold" className="!border-white/20 !bg-white/90 !text-[#8A6515]"><BadgeCheck className="h-3 w-3" /> تم الاستلام</Badge>
            </div>
            <h2 className="mt-5 text-xl font-extrabold" style={{ fontFamily: 'Cairo, sans-serif' }}>{chosen.title}</h2>
            <p className="mt-1 text-xs text-white/80">من {chosen.merchant}</p>
            <p className="mt-4 text-[11px] leading-6 text-white/80">{chosen.description}</p>
            <div className="mt-5 flex items-center justify-between rounded-xl bg-white/15 px-3 py-2 text-[11px] backdrop-blur">
              <span className="flex items-center gap-1"><CalendarDays className="h-3.5 w-3.5" /> {chosen.expiry}</span>
              <span className="font-extrabold">{chosen.value}</span>
            </div>
          </Card>
          <Card className="p-5">
            <p className="text-[10px] font-bold text-[#98A4AE]">كود الهدية</p>
            <div className="mt-1 flex items-center justify-between rounded-xl border border-dashed border-[#0F766E]/40 bg-[#F2FAF8] p-3">
              <span className="font-mono text-base font-extrabold tracking-wider text-[#0E2233]" dir="ltr">{currentUser.giftCode}</span>
              <button onClick={copy} className="rounded-lg bg-white px-2.5 py-1.5 text-[10px] font-bold text-[#0F766E] shadow-sm">{copied ? 'تم النسخ' : 'نسخ'}</button>
            </div>
            <div className="mt-4 space-y-3">
              {[
                { icon: <Store className="h-4 w-4" />, title: 'مكان الاستخدام', text: `أي فرع من فروع ${chosen.merchant} في حلب.` },
                { icon: <Timer className="h-4 w-4" />, title: 'الصلاحية', text: `${chosen.expiry} من تاريخ الاستلام — لا يمكن تمديدها.` },
                { icon: <ShieldCheck className="h-4 w-4" />, title: 'مرة واحدة فقط', text: 'الكود مخصص لعضويتك ولا يمكن نقله أو إعادة استخدامه.' },
              ].map((x) => (
                <div key={x.title} className="flex items-start gap-2.5 rounded-xl border border-[#EDE4D6] p-3">
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-[#F3EEE4] text-[#7A6242]">{x.icon}</span>
                  <div>
                    <p className="text-[11px] font-extrabold text-[#0E2233]">{x.title}</p>
                    <p className="text-[10px] text-[#7B8794]">{x.text}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 flex gap-2">
              <Button full variant="outline" onClick={() => navigate('home')}>ابدأ التصفح</Button>
              <Button full onClick={() => navigate('profile')}>حسابي</Button>
            </div>
          </Card>
        </div>
      ) : (
        <>
          <div className="grid gap-3 sm:grid-cols-3">
            {available.map((g) => (
              <Card key={g.id} hover className="overflow-hidden">
                <div className={`h-20 bg-gradient-to-br ${g.tone} px-4 py-3 text-white`}>
                  <div className="flex items-center justify-between">
                    <span className="grid h-9 w-9 place-items-center rounded-xl bg-white/20 backdrop-blur">{GIFT_ICONS[g.icon]}</span>
                    <Badge tone="gold" className="!bg-white/90 !text-[#8A6515]">{g.value}</Badge>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-sm font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>{g.title}</h3>
                  <p className="mt-0.5 text-[10px] font-bold text-[#B08968]">{g.merchant}</p>
                  <p className="mt-2 text-[10px] leading-5 text-[#7B8794]">{g.description}</p>
                  <p className="mt-2 flex items-center gap-1 text-[10px] text-[#98A4AE]"><CalendarDays className="h-3 w-3" /> {g.expiry}</p>
                  <Button full size="sm" className="mt-3" variant="outline" onClick={() => setSelected(g)}>اختيار هذه الهدية</Button>
                </div>
              </Card>
            ))}
          </div>
          <div className="mt-4 flex items-start gap-2 rounded-xl border border-[#F0E1BC] bg-[#FBF3DF] p-3 text-[10px] leading-5 text-[#8A7433]">
            <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            <span>بعد تأكيد الاختيار يُسجّل خيارك نهائياً في حسابك، ولا يمكن استبداله أو استعادة بقية الخيارات. تأكد من رغبتك قبل المتابعة.</span>
          </div>
        </>
      )}

      <div className="mt-5 flex flex-wrap justify-center gap-2 text-[10px] text-[#98A4AE]">
        <span className="flex items-center gap-1"><Percent className="h-3 w-3" /> الهدايا مقدمة من شركاء حلب خصومات</span>
        <span className="flex items-center gap-1"><Banknote className="h-3 w-3" /> لا تُحوّل الهدية إلى نقد</span>
        <span className="flex items-center gap-1"><ChevronLeft className="h-3 w-3" /> عرض التفاصيل في حسابك</span>
      </div>

      <Modal open={!!selected} onClose={() => setSelected(null)} title="تأكيد اختيار الهدية">
        {selected && (
          <div>
            <div className={`rounded-2xl bg-gradient-to-br ${selected.tone} p-4 text-white`}>
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/20">{GIFT_ICONS[selected.icon]}</span>
              <p className="mt-3 text-base font-extrabold">{selected.title}</p>
              <p className="text-xs text-white/80">{selected.merchant} · {selected.value}</p>
            </div>
            <p className="mt-4 flex items-start gap-2 rounded-xl bg-[#FBF3DF] p-3 text-[11px] leading-5 text-[#8A7433]">
              <PartyPopper className="mt-0.5 h-4 w-4 shrink-0" />
              بعد التأكيد ستحصل على كود هدية فريد، وتُخفى جميع الخيارات الأخرى. هل أنت متأكد؟
            </p>
            <div className="mt-4 flex gap-2">
              <Button full variant="ghost" onClick={() => setSelected(null)} icon={<X className="h-4 w-4" />}>تراجع</Button>
              <Button full onClick={confirm} icon={<Gift className="h-4 w-4" />}>تأكيد واستلام</Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
