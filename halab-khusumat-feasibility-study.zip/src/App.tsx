import { useEffect, useState } from 'react';
import {
  Bell, Crown, FlaskConical, Gift, Home, LayoutDashboard, LogOut, Menu, QrCode,
  ScanLine, ShieldCheck, Sparkles, User, Users, X,
} from 'lucide-react';
import { StoreProvider, useStore } from './app/store';
import { isActiveSubscriber, subscriptionDaysLeft } from './app/logic';
import { Avatar, Button, Logo, RoleBadge, Toasts } from './components/ui';
import { ForgotPasswordPage, LoginPage, RegisterPage, WelcomePage } from './pages/Auth';
import { HomePage } from './pages/Home';
import { MerchantDetailsPage, OtdPage } from './pages/Merchant';
import { GiftSelectionPage, SubscriptionPage } from './pages/Subscribe';
import { ProfilePage } from './pages/Profile';
import { MerchantAppPage } from './pages/MerchantApp';
import { AdminPage } from './pages/Admin';

interface NavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  roles: string[];
}

const NAV: NavItem[] = [
  { id: 'home', label: 'الرئيسية', icon: <Home className="h-4 w-4" />, roles: ['anonymous', 'subscriber', 'admin'] },
  { id: 'subscription', label: 'الاشتراك', icon: <Crown className="h-4 w-4" />, roles: ['anonymous', 'subscriber', 'admin'] },
  { id: 'gifts', label: 'الهدية', icon: <Gift className="h-4 w-4" />, roles: ['subscriber', 'admin'] },
  { id: 'profile', label: 'حسابي', icon: <User className="h-4 w-4" />, roles: ['anonymous', 'subscriber', 'admin'] },
  { id: 'merchantApp', label: 'تطبيق التاجر', icon: <ScanLine className="h-4 w-4" />, roles: ['merchant'] },
  { id: 'admin', label: 'لوحة التحكم', icon: <LayoutDashboard className="h-4 w-4" />, roles: ['admin'] },
];

function AppHeader() {
  const { role, currentUser, navigate, route, logout, notify } = useStore();
  const [open, setOpen] = useState(false);
  const active = isActiveSubscriber(currentUser);
  const links = NAV.filter((n) => n.roles.includes(role));
  const displayRole = role === 'anonymous' ? 'guest' : role;

  const go = (id: string) => {
    navigate(id);
    setOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 border-b border-[#E9E1D3] bg-[#FBF7F0]/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <button onClick={() => go(role === 'merchant' ? 'merchantApp' : role === 'admin' ? 'admin' : 'home')} className="shrink-0"><Logo /></button>

        <nav className="hidden items-center gap-1 lg:flex">
          {links.map((n) => {
            const isActive = route === n.id || (n.id === 'home' && route === 'merchant');
            return (
              <button
                key={n.id}
                onClick={() => go(n.id)}
                className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-[12px] font-bold transition ${isActive ? 'bg-[#0F766E] text-white shadow-sm' : 'text-[#4A5A68] hover:bg-[#F1EBE0]'}`}
              >
                {n.icon} {n.label}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center gap-2">
          {active && (
            <div className="hidden items-center gap-1.5 rounded-full border border-[#C7E7E1] bg-[#F2FAF8] px-3 py-1.5 xl:flex">
              <ShieldCheck className="h-3.5 w-3.5 text-[#0F766E]" />
              <span className="text-[10px] font-bold text-[#0F5F59]">عضوية نشطة</span>
              <span className="h-3 w-px bg-[#C7E7E1]" />
              <span className="text-[10px] font-bold text-[#0F5F59]">{subscriptionDaysLeft(currentUser)} يوم</span>
            </div>
          )}
          {role !== 'anonymous' && currentUser ? (
            <>
              <button onClick={() => notify('لديك 3 تنبيهات: هدية ترحيبية، عرض جديد من كافيه المدينة، وتذكير بتجديد العضوية', 'info')} className="relative grid h-9 w-9 place-items-center rounded-xl border border-[#E4DCCD] bg-white text-[#5B6B79] hover:border-[#0F766E]" title="الإشعارات">
                <Bell className="h-4 w-4" />
                <span className="absolute -left-0.5 -top-0.5 grid h-4 w-4 place-items-center rounded-full bg-[#E76F51] text-[8px] font-bold text-white">3</span>
              </button>
              <button onClick={() => navigate('profile')} className="flex items-center gap-2 rounded-xl border border-[#E4DCCD] bg-white py-1 pl-2 pr-1 hover:border-[#0F766E]">
                <Avatar name={currentUser.name} size={28} tone={currentUser.role === 'admin' ? 'ink' : currentUser.role === 'merchant' ? 'gold' : 'teal'} />
                <div className="hidden text-right sm:block">
                  <p className="max-w-[110px] truncate text-[11px] font-extrabold text-[#0E2233]">{currentUser.name}</p>
                  <RoleBadge role={currentUser.role} />
                </div>
              </button>
              <button onClick={logout} title="تسجيل الخروج" className="hidden h-9 w-9 place-items-center rounded-xl text-[#7B8794] hover:bg-[#FCEAE6] hover:text-[#B91C1C] sm:grid">
                <LogOut className="h-4 w-4" />
              </button>
            </>
          ) : (
            <>
              <Button size="sm" variant="ghost" onClick={() => navigate('login')}>دخول</Button>
              <Button size="sm" onClick={() => navigate('register')} icon={<User className="h-4 w-4" />}>حساب جديد</Button>
            </>
          )}
          <button onClick={() => setOpen((s) => !s)} className="grid h-9 w-9 place-items-center rounded-xl border border-[#E4DCCD] bg-white text-[#5B6B79] lg:hidden">
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-[#E9E1D3] bg-[#FBF7F0] px-4 py-3 lg:hidden">
          <div className="grid grid-cols-2 gap-2">
            {links.map((n) => (
              <button key={n.id} onClick={() => go(n.id)} className={`flex items-center gap-2 rounded-xl border px-3 py-2.5 text-xs font-bold ${route === n.id ? 'border-[#0F766E] bg-[#0F766E] text-white' : 'border-[#E4DCCD] bg-white text-[#4A5A68]'}`}>
                {n.icon} {n.label}
              </button>
            ))}
            {role === 'anonymous' && (
              <button onClick={() => go('register')} className="flex items-center gap-2 rounded-xl border border-[#0F766E] bg-[#0F766E] px-3 py-2.5 text-xs font-bold text-white">
                <Sparkles className="h-4 w-4" /> اشترك الآن
              </button>
            )}
          </div>
          <div className="mt-2 flex items-center justify-between rounded-xl bg-white px-3 py-2 text-[10px] text-[#7B8794]">
            <span>الدور الحالي</span>
            <span className="font-bold text-[#0E2233]">{displayRole === 'guest' ? 'زائر / وضع مجاني' : currentUser?.name}</span>
          </div>
        </div>
      )}
    </header>
  );
}

function BottomNav() {
  const { role, route, navigate, currentUser } = useStore();
  const items = role === 'merchant'
    ? [{ id: 'merchantApp', label: 'الماسح', icon: <ScanLine className="h-5 w-5" /> }, { id: 'profile', label: 'حسابي', icon: <User className="h-5 w-5" /> }]
    : role === 'admin'
      ? [{ id: 'admin', label: 'التحكم', icon: <LayoutDashboard className="h-5 w-5" /> }, { id: 'home', label: 'التطبيق', icon: <Home className="h-5 w-5" /> }, { id: 'profile', label: 'حسابي', icon: <User className="h-5 w-5" /> }]
      : [
          { id: 'home', label: 'الرئيسية', icon: <Home className="h-5 w-5" /> },
          { id: 'otd', label: 'الخصم', icon: <QrCode className="h-5 w-5" /> },
          { id: 'gifts', label: 'الهدية', icon: <Gift className="h-5 w-5" /> },
          { id: isActiveSubscriber(currentUser) ? 'profile' : 'subscription', label: isActiveSubscriber(currentUser) ? 'حسابي' : 'اشترك', icon: <User className="h-5 w-5" /> },
        ];
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-[#E9E1D3] bg-white/95 backdrop-blur md:hidden">
      <div className="mx-auto flex max-w-lg items-stretch">
        {items.map((i) => (
          <button
            key={i.id}
            onClick={() => navigate(i.id)}
            className={`flex flex-1 flex-col items-center gap-0.5 py-2.5 text-[10px] font-bold ${route === i.id ? 'text-[#0F766E]' : 'text-[#98A4AE]'}`}
          >
            {i.icon}
            {i.label}
          </button>
        ))}
      </div>
    </nav>
  );
}

function Footer() {
  const { navigate, role } = useStore();
  return (
    <footer className="mt-10 border-t border-[#E9E1D3] bg-white/60 py-6 pb-20 md:pb-6">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-5 text-center sm:flex-row sm:text-right">
        <div className="flex items-center gap-2 text-[10px] text-[#98A4AE]">
          <Logo compact />
          <span>حلب خصومات · الإصدار 2.0 · مايو 2026 — نموذج تفاعلي لنظام العضوية والصلاحيات</span>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-3 text-[10px] font-bold text-[#7B8794]">
          <button onClick={() => navigate('home')} className="hover:text-[#0F766E]">دليل الشركاء</button>
          <button onClick={() => navigate('subscription')} className="hover:text-[#0F766E]">الاشتراك</button>
          {role === 'admin' && <button onClick={() => navigate('admin')} className="flex items-center gap-1 hover:text-[#0F766E]"><FlaskConical className="h-3 w-3" /> مركز الجودة</button>}
          <span className="flex items-center gap-1"><Users className="h-3 w-3" /> 20+ شريك في حلب</span>
        </div>
      </div>
    </footer>
  );
}

function GuestBand() {
  const { role, navigate, continueAsGuest, currentUser } = useStore();
  if (role !== 'anonymous' || currentUser) return null;
  return (
    <div className="bg-[#0E2233] px-4 py-2 text-center text-[10px] text-white/70">
      <span className="inline-flex flex-wrap items-center justify-center gap-2">
        <ShieldCheck className="h-3 w-3 text-[#8FE3D8]" /> أنت تتصفح كزائر — نسب الخصم وأكواد OTD تتطلب عضوية نشطة.
        <button onClick={() => navigate('subscription')} className="font-bold text-[#F2D59B] underline">اشترك من 10$</button>
        <button onClick={continueAsGuest} className="font-bold text-white/80">تحديث الوضع</button>
      </span>
    </div>
  );
}

function Shell() {
  const { route, currentUser, role, navigate } = useStore();

  useEffect(() => {
    const publicRoutes = ['welcome', 'login', 'register', 'forgot'];
    if (!currentUser && role === 'anonymous' && publicRoutes.includes(route)) return;
    if (role === 'merchant' && !['merchantApp', 'profile', 'welcome'].includes(route)) navigate('merchantApp');
  }, [role, route, currentUser, navigate]);

  if (['welcome', 'login', 'register', 'forgot'].includes(route) && role === 'anonymous') {
    if (route === 'login') return <LoginPage />;
    if (route === 'register') return <RegisterPage />;
    if (route === 'forgot') return <ForgotPasswordPage />;
    return <WelcomePage />;
  }

  if (!currentUser && role === 'anonymous' && route !== 'home') {
    return <WelcomePage />;
  }

  let page: React.ReactNode;
  if (role === 'merchant') {
    page = route === 'profile' ? <ProfilePage /> : <MerchantAppPage />;
  } else if (role === 'admin') {
    if (route === 'home') page = <HomePage />;
    else if (route === 'merchant') page = <MerchantDetailsPage />;
    else if (route === 'subscription') page = <SubscriptionPage />;
    else if (route === 'gifts') page = <GiftSelectionPage />;
    else if (route === 'profile') page = <ProfilePage />;
    else if (route === 'merchantApp') page = <MerchantAppPage />;
    else if (route === 'otd') page = <OtdPage />;
    else page = <AdminPage />;
  } else {
    switch (route) {
      case 'merchant':
        page = <MerchantDetailsPage />;
        break;
      case 'subscription':
        page = <SubscriptionPage />;
        break;
      case 'gifts':
        page = <GiftSelectionPage />;
        break;
      case 'profile':
        page = <ProfilePage />;
        break;
      case 'otd':
        page = <OtdPage />;
        break;
      default:
        page = <HomePage />;
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-[#FBF7F0]">
      <GuestBand />
      <AppHeader />
      <main className="flex-1">{page}</main>
      <Footer />
      <BottomNav />
      <Toasts />
    </div>
  );
}

function AppInner() {
  const { notify } = useStore();
  useEffect(() => {
    const onHash = () => {
      if (window.location.hash === '#login') notify('استخدم نموذج تسجيل الدخول بالبريد التجريبي', 'info');
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, [notify]);
  return <Shell />;
}

export default function App() {
  return (
    <StoreProvider>
      <AppInner />
    </StoreProvider>
  );
}
