export type Role = 'anonymous' | 'subscriber' | 'merchant' | 'admin';

export interface AppUser {
  uid: string;
  name: string;
  email: string;
  phone: string;
  password: string;
  role: Role;
  isSubscriber: boolean;
  verified: boolean;
  memberId: string;
  qrSecret: string;
  subscriptionEndDate: string | null;
  plan: string | null;
  welcomeGiftClaimed: boolean;
  selectedGiftId: string | null;
  giftCode: string | null;
  giftsOptions: string[];
  merchantId: string | null;
  savings: number;
  visits: number;
  createdAt: string;
}

export interface Branch {
  id: string;
  name: string;
  address: string;
  hours: string;
  phone: string;
}

export interface Merchant {
  id: string;
  name: string;
  category: string;
  categoryLabel: string;
  emoji: string;
  gradient: string;
  discount: number;
  description: string;
  branches: Branch[];
  active: boolean;
  featured: boolean;
  rating: number;
  reviews: number;
  ad: { title: string; text: string; badge: string } | null;
}

export interface Txn {
  id: string;
  userId: string;
  userName: string;
  merchantId: string;
  merchantName: string;
  branchId: string;
  branchName: string;
  code: string;
  discountPct: number;
  amount: number;
  discountAmount: number;
  createdAt: string;
  status: 'completed' | 'flagged';
}

export interface Gift {
  id: string;
  title: string;
  merchant: string;
  description: string;
  value: string;
  expiry: string;
  icon: 'gift' | 'meal' | 'coffee';
  tone: string;
}

export interface Plan {
  id: string;
  name: string;
  price: number;
  perMonth: number;
  months: number;
  days: number;
  badge: string | null;
  save: string | null;
}

export interface Toast {
  id: number;
  message: string;
  tone: 'success' | 'error' | 'info';
}

export const CATEGORIES = [
  { id: 'all', label: 'كل التصنيفات', emoji: '✨' },
  { id: 'restaurant', label: 'مطاعم', emoji: '🍽️' },
  { id: 'cafe', label: 'مقاهي', emoji: '☕' },
  { id: 'fashion', label: 'ألبسة', emoji: '👕' },
  { id: 'beauty', label: 'صحة وجمال', emoji: '💅' },
  { id: 'sweets', label: 'حلويات', emoji: '🧁' },
  { id: 'books', label: 'مكتبات', emoji: '📚' },
  { id: 'gifts', label: 'هدايا', emoji: '🎁' },
  { id: 'fitness', label: 'رياضة', emoji: '🏋️' },
];

export const PLANS: Plan[] = [
  { id: 'monthly', name: 'شهري', price: 3, perMonth: 3, months: 1, days: 30, badge: null, save: null },
  { id: 'semi', name: 'نصف سنوي', price: 14, perMonth: 2.33, months: 6, days: 180, badge: 'وفّر 22%', save: '22%' },
  { id: 'annual', name: 'سنوي', price: 20, perMonth: 1.67, months: 12, days: 365, badge: 'الأكثر شعبية', save: '44%' },
];

export const GIFTS: Gift[] = [
  {
    id: 'g1',
    title: 'قسيمة شراء بـ 1,000 ليرة',
    merchant: 'بوتيك النور',
    description: 'قسيمة مشتريات صالحة على كامل المجموعة الشتوية، تُستخدم مرة واحدة.',
    value: '1,000 ل.س',
    expiry: 'صالح لمدة شهر',
    icon: 'gift',
    tone: 'from-[#E76F51] to-[#D4A24C]',
  },
  {
    id: 'g2',
    title: 'وجبة رئيسية مجانية',
    merchant: 'مطعم الأمير',
    description: 'اطلب أي وجبة رئيسية من القائمة واحصل على الثانية مجاناً داخل الفرع.',
    value: '1,500 ل.س',
    expiry: 'صالح لمدة أسبوعين',
    icon: 'meal',
    tone: 'from-[#0F766E] to-[#0E7490]',
  },
  {
    id: 'g3',
    title: 'مشروبان مجانيان',
    merchant: 'كافيه المدينة',
    description: 'قهوة مختصة أو مشروب بارد من اختيارك، في فرع الجامعة أو الفردوس.',
    value: '800 ل.س',
    expiry: 'صالح لمدة شهر',
    icon: 'coffee',
    tone: 'from-[#8B5E34] to-[#C08552]',
  },
];

const DEMO_SECRET = 'JBSWY3DPEHPK3PXPHALAB';

export const SEED_USERS: AppUser[] = [
  {
    uid: 'u-admin',
    name: 'مدير المنصة',
    email: 'admin@halab.com',
    phone: '+963 900 000 001',
    password: 'admin123',
    role: 'admin',
    isSubscriber: true,
    verified: true,
    memberId: 'ALD-2026-00001',
    qrSecret: DEMO_SECRET + 'ADMIN',
    subscriptionEndDate: '2027-05-01T00:00:00.000Z',
    plan: 'annual',
    welcomeGiftClaimed: true,
    selectedGiftId: 'g2',
    giftCode: 'HALAB-G2-0001',
    giftsOptions: ['g1', 'g2', 'g3'],
    merchantId: null,
    savings: 42000,
    visits: 31,
    createdAt: '2026-01-04T09:00:00.000Z',
  },
  {
    uid: 'u-merchant',
    name: 'أبو محمد — مطعم الأمير',
    email: 'merchant@halab.com',
    phone: '+963 900 000 002',
    password: 'merchant123',
    role: 'merchant',
    isSubscriber: false,
    verified: true,
    memberId: 'ALD-M-00001',
    qrSecret: DEMO_SECRET + 'MERCHANT',
    subscriptionEndDate: null,
    plan: null,
    welcomeGiftClaimed: false,
    selectedGiftId: null,
    giftCode: null,
    giftsOptions: [],
    merchantId: 'm1',
    savings: 0,
    visits: 0,
    createdAt: '2026-02-11T09:00:00.000Z',
  },
  {
    uid: 'u-sara',
    name: 'سارة الحلبي',
    email: 'sara@halab.com',
    phone: '+963 944 123 456',
    password: '123456',
    role: 'subscriber',
    isSubscriber: true,
    verified: true,
    memberId: 'ALD-2026-00041',
    qrSecret: DEMO_SECRET + 'SARA',
    subscriptionEndDate: new Date(Date.now() + 128 * 86400000).toISOString(),
    plan: 'annual',
    welcomeGiftClaimed: true,
    selectedGiftId: 'g2',
    giftCode: 'HALAB-G2-00041',
    giftsOptions: ['g1', 'g2', 'g3'],
    merchantId: null,
    savings: 15500,
    visits: 12,
    createdAt: '2026-03-18T09:00:00.000Z',
  },
  {
    uid: 'u-free',
    name: 'أحمد العلي',
    email: 'free@halab.com',
    phone: '+963 955 777 888',
    password: 'free123',
    role: 'subscriber',
    isSubscriber: false,
    verified: true,
    memberId: 'ALD-2026-00102',
    qrSecret: DEMO_SECRET + 'FREE',
    subscriptionEndDate: null,
    plan: null,
    welcomeGiftClaimed: false,
    selectedGiftId: null,
    giftCode: null,
    giftsOptions: ['g1', 'g2', 'g3'],
    merchantId: null,
    savings: 0,
    visits: 0,
    createdAt: '2026-05-02T09:00:00.000Z',
  },
];

export const SEED_MERCHANTS: Merchant[] = [
  {
    id: 'm1',
    name: 'مطعم الأمير',
    category: 'restaurant',
    categoryLabel: 'مطاعم',
    emoji: '🍽️',
    gradient: 'from-[#7C2D12] to-[#E76F51]',
    discount: 20,
    description: 'مطعم شرقي عريق في قلب حلب منذ 1995. مشاوي على الفحم، مقبلات شامية، وأجواء عائلية دافئة.',
    branches: [
      { id: 'm1-b1', name: 'فرع الفردوس', address: 'شارع الجامعة، بجانب مصرف سورية المركزي', hours: 'يومياً 9:00 ص — 11:00 م', phone: '021 123 4567' },
      { id: 'm1-b2', name: 'فرع الجابري', address: 'ساحة سعد الله الجابري، مقابل الحديقة', hours: 'يومياً 10:00 ص — 12:00 م', phone: '021 123 8899' },
    ],
    active: true,
    featured: true,
    rating: 4.8,
    reviews: 127,
    ad: { title: 'غداء العائلة في الأمير', text: 'خصم إضافي 5% على قائمة العائلة يوم الجمعة', badge: 'إعلان مميز' },
  },
  {
    id: 'm2',
    name: 'كافيه المدينة',
    category: 'cafe',
    categoryLabel: 'مقاهي',
    emoji: '☕',
    gradient: 'from-[#78350F] to-[#D4A24C]',
    discount: 25,
    description: 'قهوة مختصة، حلويات طازجة، ومساحة هادئة للعمل واللقاءات في أجمل أحياء حلب.',
    branches: [
      { id: 'm2-b1', name: 'فرع الجامعة', address: 'دوار جامعة حلب، بناء المدينة', hours: 'يومياً 8:00 ص — 12:00 م', phone: '021 222 3344' },
    ],
    active: true,
    featured: true,
    rating: 4.6,
    reviews: 96,
    ad: { title: 'قهوتك الثانية مجاناً', text: 'لكل مشترك في حلب خصومات، كل يوم حتى 11 صباحاً', badge: 'رعاية' },
  },
  {
    id: 'm3',
    name: 'بوتيك النور',
    category: 'fashion',
    categoryLabel: 'ألبسة',
    emoji: '👗',
    gradient: 'from-[#831843] to-[#E76F51]',
    discount: 30,
    description: 'أزياء نسائية حديثة ومحتشمة، تشكيلات موسمية مختارة بعناية من دور الأزياء التركية.',
    branches: [
      { id: 'm3-b1', name: 'فرع شارع الحبيب', address: 'شارع الحبيب الأول، مجمع النور', hours: 'يومياً 10:00 ص — 9:00 م', phone: '021 456 7788' },
    ],
    active: true,
    featured: true,
    rating: 4.7,
    reviews: 74,
    ad: null,
  },
  {
    id: 'm4',
    name: 'صالون ليليان',
    category: 'beauty',
    categoryLabel: 'صحة وجمال',
    emoji: '💅',
    gradient: 'from-[#9D174D] to-[#F472B6]',
    discount: 15,
    description: 'عناية بالشعر، أظافر، ومكياج مناسبات بأيدي خبيرات، مع أجود المواد العالمية.',
    branches: [
      { id: 'm4-b1', name: 'فرع الشهباء', address: 'الجديدة، شارع الشهباء', hours: 'السبت — الخميس 10:00 ص — 8:00 م', phone: '021 333 2211' },
    ],
    active: true,
    featured: false,
    rating: 4.5,
    reviews: 58,
    ad: null,
  },
  {
    id: 'm5',
    name: 'حلويات الشام',
    category: 'sweets',
    categoryLabel: 'حلويات',
    emoji: '🧁',
    gradient: 'from-[#92400E] to-[#FBBF24]',
    discount: 20,
    description: 'بقلاوة، كنافة، وحلويات شامية أصلية تُصنع يومياً في معملنا الصغير.',
    branches: [
      { id: 'm5-b1', name: 'فرع الميدان', address: 'الميدان، مقابل جامع الأربعين', hours: 'يومياً 9:00 ص — 10:00 م', phone: '021 777 1122' },
    ],
    active: true,
    featured: false,
    rating: 4.9,
    reviews: 143,
    ad: { title: 'علبة الكنافة هدية', text: 'مع كل طلب 2 كيلو وردة شامية هذا الأسبوع', badge: 'إعلان مميز' },
  },
  {
    id: 'm6',
    name: 'مكتبة المعرفة',
    category: 'books',
    categoryLabel: 'مكتبات',
    emoji: '📚',
    gradient: 'from-[#0F766E] to-[#5EEAD4]',
    discount: 18,
    description: 'كتب عربية وأجنبية، أدوات مدرسية، وقرطاسية فنية لكل الأعمار.',
    branches: [
      { id: 'm6-b1', name: 'فرع العزيزية', address: 'شارع العزيزية، جانب الثانوية', hours: 'السبت — الخميس 9:00 ص — 8:00 م', phone: '021 665 0099' },
    ],
    active: true,
    featured: false,
    rating: 4.4,
    reviews: 41,
    ad: null,
  },
  {
    id: 'm7',
    name: 'متجر الهدايا',
    category: 'gifts',
    categoryLabel: 'هدايا',
    emoji: '🎁',
    gradient: 'from-[#4338CA] to-[#A78BFA]',
    discount: 22,
    description: 'تغليف هدايا احترافي، بطاقات مكتوبة يدوياً، وتشكيلات لمناسبات الزفاف والتخرج.',
    branches: [
      { id: 'm7-b1', name: 'فرع الأنصاري', address: 'شارع الأنصاري، مجمع الياسمين', hours: 'السبت — الخميس 10:00 ص — 9:00 م', phone: '021 999 7755' },
    ],
    active: true,
    featured: true,
    rating: 4.6,
    reviews: 39,
    ad: { title: 'جهّز هدية التخرج', text: 'تغليف مجاني لكل مشترك على حلب خصومات', badge: 'شريك الإطلاق' },
  },
  {
    id: 'm8',
    name: 'نادي القوة',
    category: 'fitness',
    categoryLabel: 'رياضة',
    emoji: '🏋️',
    gradient: 'from-[#0C4A6E] to-[#38BDF8]',
    discount: 25,
    description: 'صالة رياضية مجهزة بالكامل، مدربون معتمدون، وحصص جماعية صباحية ومسائية.',
    branches: [
      { id: 'm8-b1', name: 'فرع صلاح الدين', address: 'صلاح الدين، مقابل مشفى الرازي', hours: 'يومياً 6:00 ص — 11:00 م', phone: '021 888 3344' },
    ],
    active: true,
    featured: false,
    rating: 4.3,
    reviews: 33,
    ad: null,
  },
  {
    id: 'm9',
    name: 'مطعم بيت الشام',
    category: 'restaurant',
    categoryLabel: 'مطاعم',
    emoji: '🥘',
    gradient: 'from-[#166534] to-[#86EFAC]',
    discount: 15,
    description: 'أطباق شامية بيتية، مقلوبة، شاورما، ومشروبات طازجة بأسعار مدروسة.',
    branches: [
      { id: 'm9-b1', name: 'فرع الزهراء', address: 'حي الزهراء، شارع المستشفى', hours: 'يومياً 11:00 ص — 12:00 م', phone: '021 444 5566' },
    ],
    active: true,
    featured: false,
    rating: 4.5,
    reviews: 81,
    ad: null,
  },
  {
    id: 'm10',
    name: 'مركز الفردوس الطبي',
    category: 'beauty',
    categoryLabel: 'صحة وجمال',
    emoji: '🩺',
    gradient: 'from-[#0369A1] to-[#7DD3FC]',
    discount: 20,
    description: 'أسنان، جلدية، وتغذية بإشراف أطباء مختصين ومواعيد مرنة.',
    branches: [
      { id: 'm10-b1', name: 'فرع الفردوس', address: 'شارع تشرين، بناء برج الفردوس', hours: 'السبت — الخميس 9:00 ص — 7:00 م', phone: '021 111 2233' },
    ],
    active: true,
    featured: false,
    rating: 4.7,
    reviews: 52,
    ad: null,
  },
  {
    id: 'm11',
    name: 'بيت القهوة',
    category: 'cafe',
    categoryLabel: 'مقاهي',
    emoji: '🫖',
    gradient: 'from-[#4C1D95] to-[#C084FC]',
    discount: 15,
    description: 'قهوة عربية على الرمل، شاي بالنعناع، وأجواء تراثية في بيت حلب القديمة.',
    branches: [
      { id: 'm11-b1', name: 'فرع الجميلية', address: 'الجميلية، قرب الساعة القديمة', hours: 'يومياً 10:00 ص — 1:00 ص', phone: '021 505 6060' },
    ],
    active: true,
    featured: false,
    rating: 4.4,
    reviews: 64,
    ad: null,
  },
  {
    id: 'm12',
    name: 'أثاث الأصالة',
    category: 'gifts',
    categoryLabel: 'هدايا',
    emoji: '🪑',
    gradient: 'from-[#3F2A14] to-[#B08968]',
    discount: 12,
    description: 'قطع موبيليا شرقية مصنوعة يدوياً، suitable للهدايا والمناسبات.',
    branches: [
      { id: 'm12-b1', name: 'فرع باب الحديد', address: 'باب الحديد، طريق المعرض', hours: 'يومياً 9:00 ص — 8:00 م', phone: '021 606 7070' },
    ],
    active: false,
    featured: false,
    rating: 4.2,
    reviews: 18,
    ad: null,
  },
];

export const SEED_TRANSACTIONS: Txn[] = [
  { id: 't-1001', userId: 'u-sara', userName: 'سارة الحلبي', merchantId: 'm1', merchantName: 'مطعم الأمير', branchId: 'm1-b1', branchName: 'فرع الفردوس', code: '482193', discountPct: 20, amount: 12500, discountAmount: 2500, createdAt: new Date(Date.now() - 2 * 86400000).toISOString(), status: 'completed' },
  { id: 't-1002', userId: 'u-sara', userName: 'سارة الحلبي', merchantId: 'm2', merchantName: 'كافيه المدينة', branchId: 'm2-b1', branchName: 'فرع الجامعة', code: '735110', discountPct: 25, amount: 6000, discountAmount: 1500, createdAt: new Date(Date.now() - 5 * 86400000).toISOString(), status: 'completed' },
  { id: 't-1003', userId: 'u-sara', userName: 'سارة الحلبي', merchantId: 'm3', merchantName: 'بوتيك النور', branchId: 'm3-b1', branchName: 'فرع شارع الحبيب', code: '209884', discountPct: 30, amount: 40000, discountAmount: 12000, createdAt: new Date(Date.now() - 9 * 86400000).toISOString(), status: 'completed' },
  { id: 't-1004', userId: 'u-free', userName: 'أحمد العلي', merchantId: 'm1', merchantName: 'مطعم الأمير', branchId: 'm1-b2', branchName: 'فرع الجابري', code: '991027', discountPct: 20, amount: 8000, discountAmount: 1600, createdAt: new Date(Date.now() - 12 * 86400000).toISOString(), status: 'flagged' },
  { id: 't-1005', userId: 'u-sara', userName: 'سارة الحلبي', merchantId: 'm1', merchantName: 'مطعم الأمير', branchId: 'm1-b1', branchName: 'فرع الفردوس', code: '512908', discountPct: 20, amount: 15000, discountAmount: 3000, createdAt: new Date(Date.now() - 15 * 86400000).toISOString(), status: 'completed' },
  { id: 't-1006', userId: 'u-sara', userName: 'سارة الحلبي', merchantId: 'm5', merchantName: 'حلويات الشام', branchId: 'm5-b1', branchName: 'فرع الميدان', code: '340055', discountPct: 20, amount: 9000, discountAmount: 1800, createdAt: new Date(Date.now() - 19 * 86400000).toISOString(), status: 'completed' },
  { id: 't-1007', userId: 'u-sara', userName: 'سارة الحلبي', merchantId: 'm7', merchantName: 'متجر الهدايا', branchId: 'm7-b1', branchName: 'فرع الأنصاري', code: '667431', discountPct: 22, amount: 20000, discountAmount: 4400, createdAt: new Date(Date.now() - 24 * 86400000).toISOString(), status: 'completed' },
  { id: 't-1008', userId: 'u-sara', userName: 'سارة الحلبي', merchantId: 'm2', merchantName: 'كافيه المدينة', branchId: 'm2-b1', branchName: 'فرع الجامعة', code: '119872', discountPct: 25, amount: 4500, discountAmount: 1125, createdAt: new Date(Date.now() - 30 * 86400000).toISOString(), status: 'completed' },
];

export const DEMO_ACCOUNTS = [
  { label: 'مدير المنصة', email: 'admin@halab.com', password: 'admin123', color: 'bg-[#14213D]' },
  { label: 'تاجر — مطعم الأمير', email: 'merchant@halab.com', password: 'merchant123', color: 'bg-[#0F766E]' },
  { label: 'مشتركة نشطة', email: 'sara@halab.com', password: '123456', color: 'bg-[#E76F51]' },
  { label: 'حساب غير مشترك', email: 'free@halab.com', password: 'free123', color: 'bg-[#B08968]' },
];
