import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import {
  GIFTS,
  SEED_MERCHANTS,
  SEED_TRANSACTIONS,
  SEED_USERS,
} from './data';
import type { AppUser, Branch, Gift, Merchant, Plan, Role, Toast, Txn } from './data';
import {
  canAccess,
  isActiveSubscriber,
  makeMemberId,
  makeSecret,
  makeUid,
  planById,
  subscriptionDaysLeft,
  timeWindow,
  totpCode,
} from './logic';

const LS = {
  users: 'haleb_v2_users',
  merchants: 'haleb_v2_merchants',
  txns: 'haleb_v2_transactions',
  used: 'haleb_v2_used_codes',
  session: 'haleb_v2_session',
  guest: 'haleb_v2_guest',
  pending: 'haleb_v2_pending_verification',
};

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function save(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore quota errors */
  }
}

interface UsedCode {
  userId: string;
  merchantId: string;
  window: number;
  code: string;
}

export interface VerifyOtdResult {
  ok: boolean;
  reason?: string;
  user?: AppUser;
  merchant?: Merchant;
  branch?: Branch;
  code?: string;
}

export interface RedeemResult extends VerifyOtdResult {
  transaction?: Txn;
  discountAmount?: number;
}

export interface RouteParams {
  merchantId?: string;
  branchId?: string;
  tab?: string;
}

interface StoreValue {
  users: AppUser[];
  currentUser: AppUser | null;
  role: Role;
  merchants: Merchant[];
  transactions: Txn[];
  gifts: Gift[];
  route: string;
  params: RouteParams;
  toasts: Toast[];
  pendingUid: string | null;
  adsEnabled: Record<string, boolean>;
  navigate: (route: string, params?: RouteParams) => void;
  notify: (message: string, tone?: Toast['tone']) => void;
  dismissToast: (id: number) => void;
  login: (email: string, password: string) => { ok: boolean; error?: string; user?: AppUser };
  signup: (data: { name: string; email: string; phone: string; password: string }) => { ok: boolean; error?: string };
  verifyAccount: (code: string) => { ok: boolean; error?: string; user?: AppUser };
  resendVerification: () => void;
  continueAsGuest: () => void;
  logout: () => void;
  subscribe: (planId: string) => { ok: boolean; error?: string; plan?: Plan };
  claimGift: (giftId: string) => { ok: boolean; error?: string };
  verifyCode: (code: string, merchantId: string, branchId: string) => VerifyOtdResult;
  redeemCode: (code: string, merchantId: string, branchId: string, amount: number) => RedeemResult;
  toggleMerchantActive: (id: string) => void;
  toggleFeatured: (id: string) => void;
  toggleAd: (id: string) => void;
  addMerchant: (data: { name: string; category: string; categoryLabel: string; discount: number; description: string; address: string }) => void;
  updateUserRole: (uid: string, role: Role) => void;
  resetDemoData: () => void;
}

const StoreContext = createContext<StoreValue | null>(null);

const PUBLIC_ROUTES = ['welcome', 'login', 'register', 'forgot'];

export function StoreProvider({ children }: { children: ReactNode }) {
  const [users, setUsers] = useState<AppUser[]>(() => load(LS.users, SEED_USERS));
  const [merchants, setMerchants] = useState<Merchant[]>(() => load(LS.merchants, SEED_MERCHANTS));
  const [transactions, setTransactions] = useState<Txn[]>(() => load(LS.txns, SEED_TRANSACTIONS));
  const [usedCodes, setUsedCodes] = useState<UsedCode[]>(() => load(LS.used, []));
  const [currentUid, setCurrentUid] = useState<string | null>(() => load<string | null>(LS.session, null));
  const [guest, setGuest] = useState<boolean>(() => load<boolean>(LS.guest, false));
  const [pendingUid, setPendingUid] = useState<string | null>(() => load<string | null>(LS.pending, null));
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [adsEnabled, setAdsEnabled] = useState<Record<string, boolean>>({});
  const toastId = useRef(1);

  const initialUser = useMemo(() => users.find((u) => u.uid === currentUid) ?? null, [users, currentUid]);
  const [route, setRoute] = useState<string>(() => {
    const uid = load<string | null>(LS.session, null);
    if (uid) {
      const u = load<AppUser[]>(LS.users, SEED_USERS).find((x) => x.uid === uid);
      if (u?.role === 'admin') return 'admin';
      if (u?.role === 'merchant') return 'merchantApp';
      return 'home';
    }
    if (load<boolean>(LS.guest, false)) return 'home';
    return 'welcome';
  });
  const [params, setParams] = useState<RouteParams>({});

  useEffect(() => save(LS.users, users), [users]);
  useEffect(() => save(LS.merchants, merchants), [merchants]);
  useEffect(() => save(LS.txns, transactions), [transactions]);
  useEffect(() => save(LS.used, usedCodes), [usedCodes]);
  useEffect(() => {
    save(LS.session, currentUid);
    save(LS.guest, guest);
    save(LS.pending, pendingUid);
  }, [currentUid, guest, pendingUid]);

  const currentUser = useMemo(() => users.find((u) => u.uid === currentUid) ?? initialUser, [users, currentUid, initialUser]);
  const role: Role = currentUser?.role ?? 'anonymous';

  const notify = useCallback((message: string, tone: Toast['tone'] = 'success') => {
    const id = toastId.current++;
    setToasts((prev) => [...prev, { id, message, tone }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3800);
  }, []);

  const dismissToast = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const navigate = useCallback(
    (next: string, nextParams: RouteParams = {}) => {
      const activeRole: Role = currentUser?.role ?? 'anonymous';
      const isAuthed = !!currentUser || guest;
      if (!isAuthed && !PUBLIC_ROUTES.includes(next)) {
        setRoute('welcome');
        setParams({});
        return;
      }
      if (isAuthed && PUBLIC_ROUTES.includes(next)) {
        if (activeRole === 'admin') {
          setRoute('admin');
          setParams({});
          return;
        }
        if (activeRole === 'merchant') {
          setRoute('merchantApp');
          setParams({});
          return;
        }
      }
      if (activeRole === 'merchant' && !['merchantApp', 'profile', 'welcome'].includes(next)) {
        notify('حساب التاجر مخصص لتطبيق المسح فقط', 'info');
        setRoute('merchantApp');
        return;
      }
      if (!canAccess(activeRole, next)) {
        notify('لا تملك صلاحية الوصول إلى هذه الصفحة', 'error');
        return;
      }
      if (next === 'otd' && !isActiveSubscriber(currentUser)) {
        notify('يلزم اشتراك نشط للحصول على كود الخصم', 'error');
        setRoute('subscription');
        return;
      }
      setRoute(next);
      setParams(nextParams);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    [currentUser, guest, notify],
  );

  const login = useCallback(
    (email: string, password: string) => {
      const normalized = email.trim().toLowerCase();
      const user = users.find((u) => u.email.toLowerCase() === normalized);
      if (!user) return { ok: false, error: 'لا يوجد حساب مسجل بهذا البريد الإلكتروني' };
      if (user.password !== password) return { ok: false, error: 'كلمة المرور غير صحيحة، حاول مرة أخرى' };
      if (!user.verified) {
        setPendingUid(user.uid);
        return { ok: false, error: 'الحساب غير مُفعّل بعد. أدخل رمز التحقق المرسل إليك.' };
      }
      setCurrentUid(user.uid);
      setGuest(false);
      let dest = 'home';
      if (user.role === 'admin') dest = 'admin';
      else if (user.role === 'merchant') dest = 'merchantApp';
      else if (!isActiveSubscriber(user)) dest = 'subscription';
      setRoute(dest);
      setParams({});
      notify(`أهلاً بعودتك، ${user.name.split(' ')[0]} 👋`);
      return { ok: true, user };
    },
    [users, notify],
  );

  const signup = useCallback(
    (data: { name: string; email: string; phone: string; password: string }) => {
      const email = data.email.trim().toLowerCase();
      if (users.some((u) => u.email.toLowerCase() === email)) {
        return { ok: false, error: 'هذا البريد الإلكتروني مسجل مسبقاً، يمكنك تسجيل الدخول' };
      }
      if (data.password.length < 6) return { ok: false, error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' };
      const uid = makeUid();
      const newUser: AppUser = {
        uid,
        name: data.name.trim(),
        email,
        phone: data.phone.trim(),
        password: data.password,
        role: 'subscriber',
        isSubscriber: false,
        verified: false,
        memberId: makeMemberId(users.length + 200),
        qrSecret: makeSecret(),
        subscriptionEndDate: null,
        plan: null,
        welcomeGiftClaimed: false,
        selectedGiftId: null,
        giftCode: null,
        giftsOptions: GIFTS.map((g) => g.id),
        merchantId: null,
        savings: 0,
        visits: 0,
        createdAt: new Date().toISOString(),
      };
      setUsers((prev) => [...prev, newUser]);
      setPendingUid(uid);
      return { ok: true };
    },
    [users],
  );

  const verifyAccount = useCallback(
    (code: string) => {
      if (!pendingUid) return { ok: false, error: 'لا توجد عملية تسجيل قيد الانتظار' };
      if (code.trim() !== '123456') return { ok: false, error: 'رمز التحقق غير صحيح. رمز العرض التجريبي هو 123456' };
      let activated: AppUser | undefined;
      setUsers((prev) =>
        prev.map((u) => {
          if (u.uid === pendingUid) {
            activated = { ...u, verified: true };
            return activated;
          }
          return u;
        }),
      );
      setCurrentUid(pendingUid);
      setPendingUid(null);
      setGuest(false);
      setRoute('subscription');
      notify('تم تأكيد حسابك بنجاح. اختر باقة الاشتراك للبدء');
      return { ok: true, user: activated };
    },
    [pendingUid, notify],
  );

  const resendVerification = useCallback(() => {
    notify('تم إعادة إرسال رمز التحقق إلى بريدك الإلكتروني (رمز العرض: 123456)', 'info');
  }, [notify]);

  const continueAsGuest = useCallback(() => {
    setGuest(true);
    setCurrentUid(null);
    setPendingUid(null);
    setRoute('home');
    setParams({});
    notify('أنت تتصفح حلب خصومات في الوضع المجاني — نسب الخصم مخفية', 'info');
  }, [notify]);

  const logout = useCallback(() => {
    setCurrentUid(null);
    setGuest(false);
    setPendingUid(null);
    setRoute('welcome');
    setParams({});
    notify('تم تسجيل الخروج بنجاح', 'info');
  }, [notify]);

  const subscribe = useCallback(
    (planId: string) => {
      if (!currentUser) return { ok: false, error: 'يجب تسجيل الدخول أولاً' };
      const plan = planById(planId);
      const end = new Date(Date.now() + plan.days * 86400000).toISOString();
      setUsers((prev) =>
        prev.map((u) =>
          u.uid === currentUser.uid
            ? {
                ...u,
                isSubscriber: true,
                subscriptionEndDate: end,
                plan: plan.id,
                qrSecret: u.qrSecret || makeSecret(),
                giftsOptions: u.welcomeGiftClaimed ? u.giftsOptions : GIFTS.map((g) => g.id),
              }
            : u,
        ),
      );
      return { ok: true, plan };
    },
    [currentUser],
  );

  const claimGift = useCallback(
    (giftId: string) => {
      if (!currentUser) return { ok: false, error: 'يجب تسجيل الدخول أولاً' };
      if (!isActiveSubscriber(currentUser)) return { ok: false, error: 'الهدية الترحيبية متاحة للمشتركين النشطين فقط' };
      if (currentUser.welcomeGiftClaimed) return { ok: false, error: 'لقد حصلت على هديتك الترحيبية مسبقاً' };
      const gift = GIFTS.find((g) => g.id === giftId);
      if (!gift) return { ok: false, error: 'الهدية غير موجودة' };
      const code = `HALAB-${giftId.toUpperCase()}-${currentUser.memberId.slice(-5)}`;
      setUsers((prev) =>
        prev.map((u) =>
          u.uid === currentUser.uid
            ? { ...u, welcomeGiftClaimed: true, selectedGiftId: giftId, giftCode: code }
            : u,
        ),
      );
      return { ok: true };
    },
    [currentUser],
  );

  const verifyCode = useCallback(
    (code: string, merchantId: string, branchId: string): VerifyOtdResult => {
      const normalized = code.replace(/[^0-9]/g, '');
      if (normalized.length !== 6) return { ok: false, reason: 'أدخل كوداً من 6 أرقام' };
      const merchant = merchants.find((m) => m.id === merchantId && m.active);
      if (!merchant) return { ok: false, reason: 'التاجر غير موجود أو غير مفعّل' };
      const branch = merchant.branches.find((b) => b.id === branchId) ?? merchant.branches[0];
      const candidate = users.find(
        (u) => isActiveSubscriber(u) && totpCode(u.qrSecret, merchantId) === normalized,
      );
      if (!candidate) return { ok: false, reason: 'كود OTD غير صحيح أو منتهي الصلاحية' };
      const window = timeWindow();
      if (usedCodes.some((c) => c.userId === candidate.uid && c.merchantId === merchantId && c.window === window)) {
        return { ok: false, reason: 'تم استخدام هذا الكود خلال الدقيقة الحالية — الكود لمرة واحدة' };
      }
      return { ok: true, user: candidate, merchant, branch, code: normalized };
    },
    [merchants, users, usedCodes],
  );

  const redeemCode = useCallback(
    (code: string, merchantId: string, branchId: string, amount: number): RedeemResult => {
      const verification = verifyCode(code, merchantId, branchId);
      if (!verification.ok || !verification.user || !verification.merchant || !verification.branch) {
        return verification;
      }
      const merchant = verification.merchant;
      const user = verification.user;
      const discountValue = Math.round((amount * merchant.discount) / 100);
      const txn: Txn = {
        id: `t-${Date.now().toString(36)}`,
        userId: user.uid,
        userName: user.name,
        merchantId,
        merchantName: merchant.name,
        branchId: verification.branch.id,
        branchName: verification.branch.name,
        code: verification.code ?? code,
        discountPct: merchant.discount,
        amount,
        discountAmount: discountValue,
        createdAt: new Date().toISOString(),
        status: 'completed',
      };
      setTransactions((prev) => [txn, ...prev]);
      setUsedCodes((prev) => [...prev, { userId: user.uid, merchantId, window: timeWindow(), code: txn.code }]);
      setUsers((prev) =>
        prev.map((u) =>
          u.uid === user.uid
            ? { ...u, savings: u.savings + discountValue, visits: u.visits + 1 }
            : u,
        ),
      );
      return { ...verification, transaction: txn, discountAmount: discountValue };
    },
    [verifyCode],
  );

  const toggleMerchantActive = useCallback((id: string) => {
    setMerchants((prev) => prev.map((m) => (m.id === id ? { ...m, active: !m.active } : m)));
  }, []);

  const toggleFeatured = useCallback((id: string) => {
    setMerchants((prev) => prev.map((m) => (m.id === id ? { ...m, featured: !m.featured } : m)));
  }, []);

  const toggleAd = useCallback((id: string) => {
    setAdsEnabled((prev) => ({ ...prev, [id]: prev[id] === false }));
  }, []);

  const addMerchant = useCallback(
    (data: { name: string; category: string; categoryLabel: string; discount: number; description: string; address: string }) => {
      const id = `m-${Date.now().toString(36)}`;
      const emoji = { restaurant: '🍽️', cafe: '☕', fashion: '👕', beauty: '💅', sweets: '🧁', books: '📚', gifts: '🎁', fitness: '🏋️' }[data.category] ?? '🏬';
      const merchant: Merchant = {
        id,
        name: data.name,
        category: data.category,
        categoryLabel: data.categoryLabel,
        emoji,
        gradient: 'from-[#0F766E] to-[#D4A24C]',
        discount: data.discount,
        description: data.description,
        branches: [
          { id: `${id}-b1`, name: 'الفرع الرئيسي', address: data.address, hours: 'يومياً 9:00 ص — 9:00 م', phone: '021 000 0000' },
        ],
        active: true,
        featured: false,
        rating: 4.5,
        reviews: 0,
        ad: null,
      };
      setMerchants((prev) => [merchant, ...prev]);
    },
    [],
  );

  const updateUserRole = useCallback((uid: string, nextRole: Role) => {
    setUsers((prev) =>
      prev.map((u) =>
        u.uid === uid
          ? {
              ...u,
              role: nextRole,
              isSubscriber: nextRole === 'subscriber' ? u.isSubscriber : nextRole === 'admin' || nextRole === 'merchant' ? false : u.isSubscriber,
            }
          : u,
      ),
    );
  }, []);

  const resetDemoData = useCallback(() => {
    [LS.users, LS.merchants, LS.txns, LS.used, LS.session, LS.guest, LS.pending].forEach((k) => localStorage.removeItem(k));
    setUsers(SEED_USERS);
    setMerchants(SEED_MERCHANTS);
    setTransactions(SEED_TRANSACTIONS);
    setUsedCodes([]);
    setCurrentUid(null);
    setGuest(false);
    setRoute('welcome');
    setParams({});
    notify('تمت إعادة بيانات العرض التجريبي إلى حالتها الأصلية', 'info');
  }, [notify]);

  const value: StoreValue = {
    users,
    currentUser,
    role,
    merchants,
    transactions,
    gifts: GIFTS,
    route,
    params,
    toasts,
    pendingUid,
    adsEnabled,
    navigate,
    notify,
    dismissToast,
    login,
    signup,
    verifyAccount,
    resendVerification,
    continueAsGuest,
    logout,
    subscribe,
    claimGift,
    verifyCode,
    redeemCode,
    toggleMerchantActive,
    toggleFeatured,
    toggleAd,
    addMerchant,
    updateUserRole,
    resetDemoData,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): StoreValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}

export function useCurrentGift(): Gift | null {
  const { currentUser, gifts } = useStore();
  if (!currentUser?.selectedGiftId) return null;
  return gifts.find((g) => g.id === currentUser.selectedGiftId) ?? null;
}

export function useDaysLeft(): number {
  const { currentUser } = useStore();
  return subscriptionDaysLeft(currentUser);
}
