import type { AppUser, Merchant, Plan, Role } from './data';
import { PLANS } from './data';

/** بصمة رقمية مستقرة (FNV-1a) — تُحاكي HMAC في نسخة العرض */
export function fingerprint(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

export const OTD_WINDOW_SECONDS = 60;

export function timeWindow(at: number = Date.now()): number {
  return Math.floor(at / 1000 / OTD_WINDOW_SECONDS);
}

/** كود OTD من 6 أرقام: سر المستخدم × التاجر × النافذة الزمنية الحالية */
export function totpCode(secret: string, merchantId: string, at: number = Date.now()): string {
  const window = timeWindow(at);
  const raw = fingerprint(`${secret}|${merchantId}|${window}|HALAB-OTD`);
  return String(raw % 1000000).padStart(6, '0');
}

export function remainingSeconds(at: number = Date.now()): number {
  const elapsed = Math.floor(at / 1000) % OTD_WINDOW_SECONDS;
  return OTD_WINDOW_SECONDS - elapsed;
}

export function isActiveSubscriber(user: AppUser | null): boolean {
  if (!user || !user.isSubscriber || !user.subscriptionEndDate) return false;
  return new Date(user.subscriptionEndDate).getTime() > Date.now();
}

export function subscriptionDaysLeft(user: AppUser | null): number {
  if (!user?.subscriptionEndDate) return 0;
  const diff = new Date(user.subscriptionEndDate).getTime() - Date.now();
  return Math.max(0, Math.ceil(diff / 86400000));
}

/** نسبة الخصم الظاهرة — «؟» في الوضع المجاني */
export function visibleDiscount(user: AppUser | null, merchant: Merchant): string {
  if (!isActiveSubscriber(user)) return '؟';
  return `${merchant.discount}%`;
}

export function canAccess(role: Role, route: string): boolean {
  const publicRoutes = ['welcome', 'login', 'register', 'forgot'];
  if (publicRoutes.includes(route)) return true;
  if (route === 'home' || route === 'merchant') return role === 'anonymous' || role === 'subscriber' || role === 'admin';
  if (route === 'subscription' || route === 'gifts' || route === 'profile') {
    return role === 'anonymous' || role === 'subscriber' || role === 'admin';
  }
  if (route === 'otd') return role === 'subscriber';
  if (route === 'merchantApp') return role === 'merchant' || role === 'admin';
  if (route === 'welcome') return true;
  if (['admin', 'qa', 'adminMerchants', 'adminTransactions', 'adminUsers', 'adminAds'].includes(route)) {
    return role === 'admin';
  }
  return false;
}

export function canClaimGift(user: AppUser | null): boolean {
  return !!user && isActiveSubscriber(user) && !user.welcomeGiftClaimed;
}

export function discountAmount(amount: number, pct: number): number {
  if (!Number.isFinite(amount) || amount <= 0) return 0;
  return Math.round((amount * pct) / 100);
}

export function planById(id: string): Plan {
  return PLANS.find((p) => p.id === id) ?? PLANS[2];
}

export function annualPerMonth(plan: Plan): number {
  return Number((plan.price / plan.months).toFixed(2));
}

export function formatDate(value: string | null | undefined): string {
  if (!value) return '—';
  return new Intl.DateTimeFormat('ar-SY', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(value));
}

export function formatDateTime(value: string): string {
  return new Intl.DateTimeFormat('ar-SY', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(value));
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat('en-US').format(Math.round(value));
}

export function makeSecret(): string {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let out = '';
  for (let i = 0; i < 32; i++) out += alphabet[Math.floor(Math.random() * alphabet.length)];
  return out;
}

export function makeMemberId(index: number): string {
  return `ALD-2026-${String(index).padStart(5, '0')}`;
}

export function makeUid(): string {
  return `u-${Date.now().toString(36)}-${Math.floor(Math.random() * 9999)}`;
}

export function initials(name: string): string {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join('');
}

export function categoryEmoji(id: string): string {
  return { restaurant: '🍽️', cafe: '☕', fashion: '👕', beauty: '💅', sweets: '🧁', books: '📚', gifts: '🎁', fitness: '🏋️' }[id] ?? '✨';
}

/** فحص صحة كود OTD لتاجر معيّن */
export function verifyOtdAgainstUser(
  user: AppUser,
  merchantId: string,
  code: string,
  at: number = Date.now(),
): { ok: boolean; reason?: string } {
  if (!isActiveSubscriber(user)) return { ok: false, reason: 'اشتراك العميل غير نشط أو منتهٍ' };
  const normalized = code.replace(/\s/g, '');
  const current = totpCode(user.qrSecret, merchantId, at);
  const previous = totpCode(user.qrSecret, merchantId, at - OTD_WINDOW_SECONDS * 1000);
  if (normalized === current) return { ok: true };
  if (normalized === previous) return { ok: false, reason: 'انتهت صلاحية الكود (60 ثانية). اطلب من العميل توليد كود جديد.' };
  return { ok: false, reason: 'الكود غير صحيح أو لا يخص هذا الفرع' };
}

export function csvEscape(value: string | number): string {
  const s = String(value);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function downloadCsv(filename: string, headers: string[], rows: (string | number)[][]): void {
  const content = '\uFEFF' + [headers, ...rows].map((r) => r.map(csvEscape).join(',')).join('\n');
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
