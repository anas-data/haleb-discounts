import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode } from 'react';
import { useState } from 'react';
import { AlertCircle, Check, Loader2, X } from 'lucide-react';
import { useStore } from '../app/store';
import { initials } from '../app/logic';

export function Logo({ compact = false, light = false }: { compact?: boolean; light?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="relative grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-[#E76F51] to-[#D4A24C] shadow-lg shadow-[#E76F51]/25">
        <span className="text-xl font-black text-white" style={{ fontFamily: 'Cairo, sans-serif' }}>%</span>
        <span className="absolute -left-1 -top-1 grid h-4 w-4 place-items-center rounded-full bg-[#0F766E] text-[9px] font-bold text-white">✓</span>
      </div>
      {!compact && (
        <div className="leading-tight">
          <p className={`text-lg font-extrabold ${light ? 'text-white' : 'text-[#0E2233]'}`} style={{ fontFamily: 'Cairo, sans-serif' }}>
            حلب خصومات
          </p>
          <p className={`text-[10px] tracking-wide ${light ? 'text-white/60' : 'text-[#7B8794]'}`}>HALAB DISCOUNTS · نادي الادخار</p>
        </div>
      )}
    </div>
  );
}

type Variant = 'primary' | 'outline' | 'ghost' | 'dark' | 'gold' | 'danger';

export function Button({
  children,
  variant = 'primary',
  size = 'md',
  loading = false,
  full = false,
  icon,
  className = '',
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  full?: boolean;
  icon?: ReactNode;
}) {
  const variants: Record<Variant, string> = {
    primary: 'bg-[#0F766E] text-white hover:bg-[#115E59] shadow-lg shadow-[#0F766E]/20',
    outline: 'border border-[#DCD3C4] bg-white text-[#0E2233] hover:border-[#0F766E] hover:bg-[#F3F8F6]',
    ghost: 'text-[#4A5A68] hover:bg-[#F1EBE0] hover:text-[#0E2233]',
    dark: 'bg-[#0E2233] text-white hover:bg-[#1B3448] shadow-lg shadow-[#0E2233]/20',
    gold: 'bg-[#D4A24C] text-[#2A1D08] hover:bg-[#C4923D] shadow-lg shadow-[#D4A24C]/25',
    danger: 'bg-[#B91C1C] text-white hover:bg-[#991B1B]',
  };
  const sizes = { sm: 'px-3 py-1.5 text-xs', md: 'px-4 py-2.5 text-sm', lg: 'px-6 py-3.5 text-base' };
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 rounded-xl font-bold transition-all duration-200 disabled:cursor-not-allowed disabled:opacity-50 ${variants[variant]} ${sizes[size]} ${full ? 'w-full' : ''} ${className}`}
      disabled={loading || props.disabled}
      {...props}
    >
      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : icon}
      {children}
    </button>
  );
}

export function Card({ children, className = '', hover = false }: { children: ReactNode; className?: string; hover?: boolean }) {
  return (
    <div
      className={`rounded-2xl border border-[#E9E1D3] bg-white ${hover ? 'transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-[#14213D]/10' : ''} ${className}`}
    >
      {children}
    </div>
  );
}

export function Badge({ children, tone = 'sand', className = '' }: { children: ReactNode; tone?: 'sand' | 'green' | 'red' | 'gold' | 'ink' | 'teal' | 'outline'; className?: string }) {
  const tones = {
    sand: 'bg-[#F3EEE4] text-[#7A6242]',
    green: 'bg-emerald-50 text-emerald-700 border border-emerald-100',
    red: 'bg-red-50 text-red-700 border border-red-100',
    gold: 'bg-[#FBF3DF] text-[#8A6515] border border-[#F0E1BC]',
    ink: 'bg-[#EAF0F3] text-[#31485B]',
    teal: 'bg-[#E7F4F1] text-[#0F766E] border border-[#C7E7E1]',
    outline: 'border border-[#DCD3C4] text-[#5B6B79]',
  };
  return <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold ${tones[tone]} ${className}`}>{children}</span>;
}

export function SectionTitle({ eyebrow, title, subtitle, action }: { eyebrow?: string; title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        {eyebrow && <p className="mb-1 text-[11px] font-bold uppercase tracking-[0.2em] text-[#B08968]">{eyebrow}</p>}
        <h2 className="text-xl font-extrabold text-[#0E2233] sm:text-2xl" style={{ fontFamily: 'Cairo, sans-serif' }}>{title}</h2>
        {subtitle && <p className="mt-1 max-w-2xl text-sm text-[#6C7A87]">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function Avatar({ name, src, size = 40, tone = 'teal' }: { name: string; src?: string | null; size?: number; tone?: 'teal' | 'gold' | 'ink' }) {
  const tones = { teal: 'from-[#0F766E] to-[#0E7490]', gold: 'from-[#D4A24C] to-[#E76F51]', ink: 'from-[#14213D] to-[#31485B]' };
  return src ? (
    <img src={src} alt={name} className="rounded-full object-cover" style={{ width: size, height: size }} />
  ) : (
    <div
      className={`grid shrink-0 place-items-center rounded-full bg-gradient-to-br font-bold text-white ${tones[tone]}`}
      style={{ width: size, height: size, fontSize: size * 0.34 }}
    >
      {initials(name)}
    </div>
  );
}

export function Field({
  label,
  error,
  hint,
  icon,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string; hint?: string; icon?: ReactNode }) {
  const [show, setShow] = useState(false);
  const isPassword = props.type === 'password';
  return (
    <label className="block">
      <span className="mb-1.5 flex items-center justify-between text-xs font-bold text-[#31485B]">
        {label}
        {props.required && <span className="text-[#B91C1C]">*</span>}
      </span>
      <span className="relative block">
        {icon && <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[#9AA7B1]">{icon}</span>}
        <input
          {...props}
          type={isPassword && show ? 'text' : props.type}
          dir={props.type === 'email' || props.type === 'tel' ? 'ltr' : 'rtl'}
          className={`w-full rounded-xl border bg-[#FCFAF6] px-3 py-2.5 text-sm text-[#0E2233] outline-none transition placeholder:text-[#A9B2BA] focus:border-[#0F766E] focus:bg-white focus:ring-4 focus:ring-[#0F766E]/10 ${icon ? 'pr-10' : ''} ${isPassword ? 'pl-10' : ''} ${error ? 'border-red-300 bg-red-50/40' : 'border-[#E4DCCD]'} ${props.className ?? ''}`}
        />
        {isPassword && (
          <button type="button" onClick={() => setShow((s) => !s)} className="absolute left-3 top-1/2 -translate-y-1/2 text-[11px] font-bold text-[#0F766E]">
            {show ? 'إخفاء' : 'إظهار'}
          </button>
        )}
      </span>
      {error && (
        <span className="mt-1 flex items-center gap-1 text-[11px] font-semibold text-red-600">
          <AlertCircle className="h-3 w-3" /> {error}
        </span>
      )}
      {hint && !error && <span className="mt-1 block text-[11px] text-[#8794A0]">{hint}</span>}
    </label>
  );
}

export function Modal({ open, onClose, title, children, wide = false }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
      <button aria-label="إغلاق" className="absolute inset-0 bg-[#0B1B28]/60 backdrop-blur-sm" onClick={onClose} />
      <div className={`relative max-h-[88vh] w-full overflow-y-auto rounded-3xl bg-[#FBF7F0] p-6 shadow-2xl ${wide ? 'max-w-3xl' : 'max-w-md'}`}>
        <div className="mb-5 flex items-center justify-between">
          <h3 className="text-lg font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>{title}</h3>
          <button onClick={onClose} className="rounded-lg p-1.5 text-[#6C7A87] hover:bg-[#EDE5D8]"><X className="h-5 w-5" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Toasts() {
  const { toasts, dismissToast } = useStore();
  return (
    <div className="pointer-events-none fixed bottom-5 left-1/2 z-[100] flex w-full max-w-sm -translate-x-1/2 flex-col gap-2 px-4 sm:bottom-6">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`pointer-events-auto flex items-center gap-2.5 rounded-xl border px-4 py-3 text-sm font-semibold shadow-xl backdrop-blur ${
            t.tone === 'error'
              ? 'border-red-200 bg-red-50/95 text-red-800'
              : t.tone === 'info'
                ? 'border-[#C7E7E1] bg-[#EAF7F4]/95 text-[#0F5F59]'
                : 'border-emerald-200 bg-emerald-50/95 text-emerald-800'
          }`}
        >
          <span className={`grid h-6 w-6 shrink-0 place-items-center rounded-full text-white ${t.tone === 'error' ? 'bg-red-500' : t.tone === 'info' ? 'bg-[#0F766E]' : 'bg-emerald-500'}`}>
            {t.tone === 'error' ? <X className="h-3.5 w-3.5" /> : <Check className="h-3.5 w-3.5" />}
          </span>
          <span className="flex-1">{t.message}</span>
          <button onClick={() => dismissToast(t.id)} className="text-current opacity-50 hover:opacity-100"><X className="h-4 w-4" /></button>
        </div>
      ))}
    </div>
  );
}

export function Stat({ icon, label, value, hint, tone = 'teal' }: { icon: ReactNode; label: string; value: string; hint?: string; tone?: 'teal' | 'gold' | 'ink' | 'rose' }) {
  const tones = {
    teal: 'bg-[#E7F4F1] text-[#0F766E]',
    gold: 'bg-[#FBF3DF] text-[#A57C1B]',
    ink: 'bg-[#EAF0F3] text-[#14213D]',
    rose: 'bg-[#FCEAE6] text-[#C2410C]',
  };
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-bold text-[#7B8794]">{label}</p>
          <p className="mt-1 text-xl font-extrabold text-[#0E2233]" style={{ fontFamily: 'Cairo, sans-serif' }}>{value}</p>
          {hint && <p className="mt-1 text-[10px] text-[#98A4AE]">{hint}</p>}
        </div>
        <span className={`grid h-10 w-10 place-items-center rounded-xl ${tones[tone]}`}>{icon}</span>
      </div>
    </Card>
  );
}

export function RoleBadge({ role }: { role: string }) {
  const map: Record<string, { label: string; tone: 'teal' | 'gold' | 'ink' | 'red' | 'sand' }> = {
    subscriber: { label: 'مشترك', tone: 'teal' },
    merchant: { label: 'تاجر', tone: 'gold' },
    admin: { label: 'مدير المنصة', tone: 'ink' },
    anonymous: { label: 'زائر', tone: 'sand' },
  };
  const r = map[role] ?? map.anonymous;
  return <Badge tone={r.tone}>{r.label}</Badge>;
}

export function EmptyState({ title, text, icon }: { title: string; text: string; icon?: ReactNode }) {
  return (
    <div className="rounded-2xl border border-dashed border-[#DCD3C4] bg-[#FBF7F0] p-10 text-center">
      <div className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-white text-[#0F766E] shadow-sm">{icon ?? <AlertCircle className="h-5 w-5" />}</div>
      <p className="font-bold text-[#0E2233]">{title}</p>
      <p className="mt-1 text-sm text-[#7B8794]">{text}</p>
    </div>
  );
}
