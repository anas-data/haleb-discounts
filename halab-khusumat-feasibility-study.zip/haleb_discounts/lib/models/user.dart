import 'package:cloud_firestore/cloud_firestore.dart';

class User {
  final String userId;
  final String name;
  final String phone;
  final String? email;
  final bool isSubscriber;
  final DateTime? subscriptionEndDate;
  final String? qrSecret; // Base32 secret for TOTP
  final bool welcomeGiftClaimed;
  final List<String> giftsOptions; // Available gift IDs
  final String? selectedGiftId;
  final DateTime registrationDate;
  final String? profilePhotoUrl;
  final int totalDiscountsUsed;
  final double totalSavings;

  User({
    required this.userId,
    required this.name,
    required this.phone,
    this.email,
    this.isSubscriber = false,
    this.subscriptionEndDate,
    this.qrSecret,
    this.welcomeGiftClaimed = false,
    this.giftsOptions = const [],
    this.selectedGiftId,
    required this.registrationDate,
    this.profilePhotoUrl,
    this.totalDiscountsUsed = 0,
    this.totalSavings = 0.0,
  });

  // إنشاء من Firestore
  factory User.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    
    return User(
      userId: doc.id,
      name: data['name'] ?? '',
      phone: data['phone'] ?? '',
      email: data['email'],
      isSubscriber: data['isSubscriber'] ?? false,
      subscriptionEndDate: data['subscriptionEndDate'] != null
          ? (data['subscriptionEndDate'] as Timestamp).toDate()
          : null,
      qrSecret: data['qrSecret'],
      welcomeGiftClaimed: data['welcomeGiftClaimed'] ?? false,
      giftsOptions: List<String>.from(data['giftsOptions'] ?? []),
      selectedGiftId: data['selectedGiftId'],
      registrationDate: (data['registrationDate'] as Timestamp).toDate(),
      profilePhotoUrl: data['profilePhotoUrl'],
      totalDiscountsUsed: data['totalDiscountsUsed'] ?? 0,
      totalSavings: (data['totalSavings'] ?? 0.0).toDouble(),
    );
  }

  // تحويل إلى Map
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'phone': phone,
      'email': email,
      'isSubscriber': isSubscriber,
      'subscriptionEndDate': subscriptionEndDate != null
          ? Timestamp.fromDate(subscriptionEndDate!)
          : null,
      'qrSecret': qrSecret,
      'welcomeGiftClaimed': welcomeGiftClaimed,
      'giftsOptions': giftsOptions,
      'selectedGiftId': selectedGiftId,
      'registrationDate': Timestamp.fromDate(registrationDate),
      'profilePhotoUrl': profilePhotoUrl,
      'totalDiscountsUsed': totalDiscountsUsed,
      'totalSavings': totalSavings,
    };
  }

  // نسخ مع تعديلات
  User copyWith({
    String? name,
    String? phone,
    String? email,
    bool? isSubscriber,
    DateTime? subscriptionEndDate,
    String? qrSecret,
    bool? welcomeGiftClaimed,
    List<String>? giftsOptions,
    String? selectedGiftId,
    String? profilePhotoUrl,
    int? totalDiscountsUsed,
    double? totalSavings,
  }) {
    return User(
      userId: userId,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      isSubscriber: isSubscriber ?? this.isSubscriber,
      subscriptionEndDate: subscriptionEndDate ?? this.subscriptionEndDate,
      qrSecret: qrSecret ?? this.qrSecret,
      welcomeGiftClaimed: welcomeGiftClaimed ?? this.welcomeGiftClaimed,
      giftsOptions: giftsOptions ?? this.giftsOptions,
      selectedGiftId: selectedGiftId ?? this.selectedGiftId,
      registrationDate: registrationDate,
      profilePhotoUrl: profilePhotoUrl ?? this.profilePhotoUrl,
      totalDiscountsUsed: totalDiscountsUsed ?? this.totalDiscountsUsed,
      totalSavings: totalSavings ?? this.totalSavings,
    );
  }

  // التحقق من صلاحية الاشتراك
  bool get hasValidSubscription {
    if (!isSubscriber || subscriptionEndDate == null) return false;
    return DateTime.now().isBefore(subscriptionEndDate!);
  }

  // عدد الأيام المتبقية
  int? get daysRemaining {
    if (subscriptionEndDate == null) return null;
    return subscriptionEndDate!.difference(DateTime.now()).inDays;
  }
}
