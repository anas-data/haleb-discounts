import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';

import 'providers/auth_provider.dart';
import 'services/auth_service.dart';
import 'ui/user/welcome_page.dart';
import 'ui/user/login_page.dart';
import 'ui/user/register_page.dart';
import 'ui/user/forgot_password_page.dart';
import 'ui/user/home_page.dart';
import 'ui/merchant/scanner_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(
    ChangeNotifierProvider(
      create: (_) => AuthProvider(AuthService()),
      child: const HalebDiscountsApp(),
    ),
  );
}

class HalebDiscountsApp extends StatelessWidget {
  const HalebDiscountsApp({super.key});

  static const _ink = Color(0xFF0E2233);
  static const _teal = Color(0xFF0F766E);
  static const _sand = Color(0xFFFBF7F0);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'حلب خصومات',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar', 'SY'),
      supportedLocales: const [Locale('ar', 'SY'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: _sand,
        colorScheme: ColorScheme.fromSeed(seedColor: _teal, primary: _teal),
        appBarTheme: const AppBarTheme(backgroundColor: _sand, foregroundColor: _ink, elevation: 0),
        fontFamily: 'Cairo',
        snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
      ),
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      initialRoute: '/',
      routes: {
        '/': (_) => const AuthGate(),
        '/welcome': (_) => const WelcomePage(),
        '/login': (_) => const LoginPage(),
        '/register': (_) => const RegisterPage(),
        '/forgot-password': (_) => const ForgotPasswordPage(),
        '/home': (_) => const HomePage(),
        '/subscription': (_) => const _SubscriptionGatePage(),
        '/merchant': (_) => const MerchantScannerGate(),
        '/admin': (_) => const _AdminRedirectPage(),
      },
    );
  }
}

/// بوابة التحقق من حالة المصادقة وتوجيه المستخدم حسب الدور.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    switch (auth.status) {
      case AuthStatus.unknown:
        return const Scaffold(
          backgroundColor: Color(0xFFFBF7F0),
          body: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(color: Color(0xFF0F766E)),
                SizedBox(height: 14),
                Text('جارٍ التحقق من العضوية…', style: TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
          ),
        );
      case AuthStatus.signedOut:
        return const WelcomePage();
      case AuthStatus.guest:
        return const HomePage();
      case AuthStatus.authenticated:
        if (auth.isAdmin) return const _AdminRedirectPage();
        if (auth.isMerchant) return const MerchantScannerGate();
        if (auth.isSubscriberActive) return const HomePage();
        return const _SubscriptionGatePage();
    }
  }
}

/// غير المشترك: يُوجَّه إلى الاشتراك أو يستطيع التصفح في الوضع المجاني.
class _SubscriptionGatePage extends StatelessWidget {
  const _SubscriptionGatePage();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFBF7F0),
      appBar: AppBar(title: const Text('الاشتراك في حلب خصومات', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: const Color(0xFF0E2233),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('عضوية حلب خصومات', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                    SizedBox(height: 6),
                    Text('خصومات دائمة بين 15% و30% + هدية ترحيبية + كود OTD آمن', style: TextStyle(color: Colors.white60, fontSize: 11, height: 1.7)),
                    SizedBox(height: 14),
                    Text(r'$20 / سنة', style: TextStyle(color: Color(0xFFD4A24C), fontSize: 26, fontWeight: FontWeight.w900)),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              for (final plan in const [
                ('شهري', r'$3', 'تجربة مرنة'),
                ('نصف سنوي', r'$14', 'توفير 22%'),
                ('سنوي', r'$20', 'الأكثر شعبية · توفير 44%'),
              ])
                Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: const Color(0xFFE9E1D3)),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(plan.$1, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF0E2233))),
                            Text(plan.$3, style: const TextStyle(fontSize: 10, color: Color(0xFF7B8794))),
                          ],
                        ),
                      ),
                      Text(plan.$2, style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF0F766E))),
                    ],
                  ),
                ),
              const SizedBox(height: 6),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF0F766E),
                  foregroundColor: Colors.white,
                  minimumSize: const Size.fromHeight(52),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('اختيار الباقة متاح داخل شاشة الاشتراك الكاملة بعد ربط بوابة الدفع.')),
                  );
                },
                child: const Text('اختيار باقة والمتابعة للدفع', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              TextButton(
                onPressed: () => Navigator.pushReplacementNamed(context, '/home'),
                child: const Text('متابعة التصفح في الوضع المجاني', style: TextStyle(color: Color(0xFF7B8794), fontSize: 12, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// حماية تطبيق المستخدم من دخول التجار.
class MerchantScannerGate extends StatelessWidget {
  const MerchantScannerGate({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    if (auth.isAdmin) {
      return const _AdminRedirectPage();
    }
    if (!auth.isMerchant) {
      return const AuthGate();
    }
    return const MerchantScannerScreen(branchId: 'm1-b1');
  }
}

/// الأدمن يُوجّه إلى لوحة التحكم (Flutter Web) — لا يستخدم تطبيق المستخدم.
class _AdminRedirectPage extends StatelessWidget {
  const _AdminRedirectPage();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFBF7F0),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.admin_panel_settings_outlined, size: 72, color: Color(0xFF0F766E)),
                const SizedBox(height: 14),
                const Text('لوحة تحكم حلب خصومات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Color(0xFF0E2233))),
                const SizedBox(height: 6),
                const Text('حسابك مدير منصة. تُدار التقارير والشركاء والإعلانات من لوحة التحكم على الويب.',
                    textAlign: TextAlign.center, style: TextStyle(fontSize: 12, height: 1.7, color: Color(0xFF6C7A87))),
                const SizedBox(height: 16),
                OutlinedButton.icon(
                  onPressed: () => context.read<AuthProvider>().signOut(),
                  icon: const Icon(Icons.logout),
                  label: const Text('تسجيل الخروج'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
