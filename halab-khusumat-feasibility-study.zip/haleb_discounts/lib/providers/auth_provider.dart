import 'dart:async';

import 'package:flutter/foundation.dart';

import '../services/auth_service.dart';

enum AuthStatus { unknown, signedOut, authenticated, guest }

/// مزوّد حالة المصادقة والأدوار — Provider (ChangeNotifier).
class AuthProvider extends ChangeNotifier {
  AuthProvider(this._service) {
    _subscription = _service.authStateChanges.listen(_onAuthStateChanged);
  }

  final AuthService _service;
  StreamSubscription? _subscription;

  AuthStatus status = AuthStatus.unknown;
  AppUser? currentUser;
  bool isLoading = false;
  String? error;

  bool get isSignedIn => status == AuthStatus.authenticated && currentUser != null;
  bool get isGuest => status == AuthStatus.guest;
  bool get isSubscriberActive => currentUser?.hasActiveSubscription ?? false;
  bool get isMerchant => currentUser?.isMerchant ?? false;
  bool get isAdmin => currentUser?.isAdmin ?? false;

  String get role {
    if (status == AuthStatus.guest) return 'anonymous';
    return currentUser?.role ?? 'anonymous';
  }

  Future<void> _onAuthStateChanged(Object? _) async {
    final fbUser = _service.firebaseUser;
    if (fbUser == null) {
      if (status != AuthStatus.guest) {
        status = AuthStatus.signedOut;
        currentUser = null;
        notifyListeners();
      }
      return;
    }
    await _loadProfile(fbUser.uid);
  }

  Future<void> _loadProfile(String uid) async {
    try {
      currentUser = await _service.fetchProfile(uid);
      status = currentUser == null ? AuthStatus.signedOut : AuthStatus.authenticated;
    } catch (_) {
      status = AuthStatus.signedOut;
      error = 'تعذر تحميل بيانات العضوية.';
    }
    notifyListeners();
  }

  Future<bool> signUp({
    required String name,
    required String phone,
    required String email,
    required String password,
  }) async {
    isLoading = true;
    error = null;
    notifyListeners();

    final message = await _service.signUpWithEmail(
      name: name,
      phone: phone,
      email: email,
      password: password,
    );

    isLoading = false;
    if (message != null) {
      error = message;
      notifyListeners();
      return false;
    }
    final fbUser = _service.firebaseUser;
    if (fbUser != null) {
      await _loadProfile(fbUser.uid);
    }
    notifyListeners();
    return true;
  }

  Future<bool> signIn({required String email, required String password}) async {
    isLoading = true;
    error = null;
    notifyListeners();

    final result = await _service.signInWithEmail(email: email, password: password);
    isLoading = false;
    if (result.error != null) {
      error = result.error;
      notifyListeners();
      return false;
    }
    currentUser = result.user;
    status = AuthStatus.authenticated;
    notifyListeners();
    return true;
  }

  Future<void> continueAsGuest() async {
    status = AuthStatus.guest;
    currentUser = null;
    notifyListeners();
  }

  Future<void> signOut() async {
    await _service.signOut();
    currentUser = null;
    status = AuthStatus.signedOut;
    notifyListeners();
  }

  Future<String?> sendPasswordReset(String email) async {
    isLoading = true;
    notifyListeners();
    final result = await _service.resetPassword(email);
    isLoading = false;
    error = result;
    notifyListeners();
    return result;
  }

  void clearError() {
    error = null;
    notifyListeners();
  }

  /// توجيه المستخدم بعد تسجيل الدخول حسب الدور/الاشتراك:
  /// admin → لوحة التحكم، merchant → تطبيق الماسح،
  /// مشترك نشط → الرئيسية، غير مشترك → صفحة الاشتراك.
  String routeForCurrentUser() {
    if (isGuest) return '/home';
    if (isAdmin) return '/admin';
    if (isMerchant) return '/merchant';
    if (isSubscriberActive) return '/home';
    if (currentUser != null) return '/subscription';
    return '/welcome';
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}
