import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';

/// تطبيق التاجر — مسح كود OTD والتحقق منه عبر Cloud Function.
class MerchantScannerScreen extends StatefulWidget {
  const MerchantScannerScreen({
    super.key,
    required this.branchId,
    this.merchantId = 'm1',
  });

  final String branchId;
  final String merchantId;

  @override
  State<MerchantScannerScreen> createState() => _MerchantScannerScreenState();
}

class _MerchantScannerScreenState extends State<MerchantScannerScreen> {
  final MobileScannerController _scanner = MobileScannerController();
  final TextEditingController _manualCode = TextEditingController();
  final TextEditingController _amount = TextEditingController(text: '12000');

  bool _processing = false;
  String? _error;
  Map<String, dynamic>? _verification;
  Map<String, dynamic>? _receipt;

  @override
  void dispose() {
    _scanner.dispose();
    _manualCode.dispose();
    _amount.dispose();
    super.dispose();
  }

  Future<void> _verify(String code, {String? userId}) async {
    if (_processing) return;
    setState(() {
      _processing = true;
      _error = null;
      _verification = null;
      _receipt = null;
    });
    try {
      final callable = FirebaseFunctions.instanceFor(region: 'europe-west1').httpsCallable('verifyOtdCode');
      final response = await callable.call(<String, dynamic>{
        'code': code,
        'merchantId': widget.merchantId,
        'branchId': widget.branchId,
        if (userId != null) 'userId': userId,
      });
      final data = Map<String, dynamic>.from(response.data as Map);
      if (!mounted) return;
      setState(() => _verification = data);
      await _scanner.stop();
    } on FirebaseFunctionsException catch (e) {
      if (!mounted) return;
      setState(() => _error = e.message ?? 'فشل التحقق من الكود');
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = 'تعذر الاتصال بخدمة التحقق');
    } finally {
      if (mounted) setState(() => _processing = false);
    }
  }

  Future<void> _confirm() async {
    final data = _verification;
    if (data == null) return;
    final user = data['user'] as Map?;
    final amount = double.tryParse(_amount.text) ?? 0;
    if (amount <= 0) {
      setState(() => _error = 'أدخل قيمة فاتورة صحيحة');
      return;
    }
    setState(() => _processing = true);
    try {
      final callable = FirebaseFunctions.instanceFor(region: 'europe-west1').httpsCallable('recordTransaction');
      final response = await callable.call(<String, dynamic>{
        'userId': user?['userId'],
        'merchantId': widget.merchantId,
        'branchId': widget.branchId,
        'code': _manualCode.text.trim().isEmpty ? data['transactionToken'] : _manualCode.text.trim(),
        'amount': amount,
      });
      if (!mounted) return;
      setState(() {
        _receipt = Map<String, dynamic>.from(response.data as Map);
        _verification = null;
        _manualCode.clear();
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم تسجيل الخصم بنجاح'), backgroundColor: Color(0xFF0F766E)),
      );
    } on FirebaseFunctionsException catch (e) {
      setState(() => _error = e.message ?? 'تعذر تسجيل العملية');
    } finally {
      if (mounted) setState(() => _processing = false);
    }
  }

  void _onDetect(BarcodeCapture capture) {
    if (_processing || capture.barcodes.isEmpty) return;
    final raw = capture.barcodes.first.rawValue;
    if (raw == null || !raw.startsWith('halab-discounts://redeem/')) return;
    final uri = Uri.tryParse(raw);
    if (uri == null) return;
    final code = uri.pathSegments.isNotEmpty ? uri.pathSegments.last : '';
    final userId = uri.queryParameters['u'];
    _manualCode.text = code;
    _verify(code, userId: userId);
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      backgroundColor: const Color(0xFFFBF7F0),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFBF7F0),
        title: const Text('تطبيق التاجر — مسح الخصم', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            tooltip: 'تسجيل الخروج',
            onPressed: () => context.read<AuthProvider>().signOut(),
            icon: const Icon(Icons.logout, color: Color(0xFF7B8794)),
          ),
        ],
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: const Color(0xFF0E2233), borderRadius: BorderRadius.circular(14)),
              child: Row(
                children: [
                  const Icon(Icons.storefront, color: Colors.white70),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(auth.currentUser?.name ?? 'التاجر', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                        Text('فرع: ${widget.branchId} · صلاحيات التاجر فقط', style: const TextStyle(color: Colors.white54, fontSize: 10)),
                      ],
                    ),
                  ),
                  const Icon(Icons.verified, color: Color(0xFFD4A24C)),
                ],
              ),
            ),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: AspectRatio(
                aspectRatio: 4 / 3,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    MobileScanner(controller: _scanner, onDetect: _onDetect),
                    Container(color: Colors.black26),
                    Center(
                      child: Container(
                        width: 220,
                        height: 220,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.white, width: 2),
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                    const Positioned(
                      bottom: 12,
                      left: 0,
                      right: 0,
                      child: Text('وجّه الكاميرا نحو QR المشترك', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 11)),
                    ),
                    if (_processing) const Center(child: CircularProgressIndicator(color: Colors.white)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _manualCode,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    textDirection: TextDirection.ltr,
                    decoration: const InputDecoration(
                      labelText: 'إدخال يدوي لكود OTD',
                      counterText: '',
                      border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0F766E), foregroundColor: Colors.white, minimumSize: const Size(90, 52)),
                  onPressed: _processing ? null : () => _verify(_manualCode.text.trim()),
                  child: const Text('تحقق'),
                ),
              ],
            ),
            if (_error != null)
              Container(
                margin: const EdgeInsets.only(top: 10),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: const Color(0xFFFEE2E2), borderRadius: BorderRadius.circular(10)),
                child: Text(_error!, style: const TextStyle(color: Color(0xFFB91C1C), fontSize: 11, fontWeight: FontWeight.bold)),
              ),
            if (_verification != null) _buildVerification(),
            if (_receipt != null) _buildReceipt(),
          ],
        ),
      ),
    );
  }

  Widget _buildVerification() {
    final user = (_verification!['user'] as Map?) ?? {};
    final discount = _verification!['discountPercentage'] ?? 0;
    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFC7E7E1))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Row(
            children: [
              Icon(Icons.check_circle, color: Color(0xFF0F766E)),
              SizedBox(width: 6),
              Text('كود OTD صالح — عضوية نشطة', style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF0F5F59), fontSize: 12)),
            ],
          ),
          const SizedBox(height: 10),
          CircleAvatar(radius: 28, backgroundColor: const Color(0xFFE7F4F1), child: Text((user['name'] ?? '؟').toString().substring(0, 1), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Color(0xFF0F766E)))),
          const SizedBox(height: 6),
          Text((user['name'] ?? '').toString(), textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: Color(0xFF0E2233))),
          Text((user['memberId'] ?? '').toString(), textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: Color(0xFF98A4AE), fontFamily: 'monospace')),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: const Color(0xFFF2FAF8), borderRadius: BorderRadius.circular(10)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('الخصم المتفق عليه', style: TextStyle(fontSize: 11, color: Color(0xFF5B6B79))),
                Text('$discount%', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFF0F766E))),
              ],
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _amount,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'قيمة الفاتورة قبل الخصم (ل.س)',
              border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
            ),
          ),
          const SizedBox(height: 10),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF0F766E),
              foregroundColor: Colors.white,
              minimumSize: const Size.fromHeight(48),
            ),
            onPressed: _processing ? null : _confirm,
            icon: const Icon(Icons.check),
            label: const Text('تأكيد منح الخصم وتسجيل العملية', style: TextStyle(fontWeight: FontWeight.w800)),
          ),
          TextButton(
            onPressed: () {
              setState(() => _verification = null);
              _scanner.start();
            },
            child: const Text('إلغاء', style: TextStyle(color: Colors.grey, fontSize: 11)),
          ),
        ],
      ),
    );
  }

  Widget _buildReceipt() {
    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFFF2FAF8), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFC7E7E1))),
      child: Column(
        children: [
          const Icon(Icons.verified, color: Color(0xFF0F766E), size: 42),
          const SizedBox(height: 6),
          const Text('تم تسجيل الخصم بنجاح', style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF0F5F59))),
          Text('رقم العملية: ${_receipt!['transactionId'] ?? '—'}', style: const TextStyle(fontSize: 10, color: Color(0xFF7B8794), fontFamily: 'monospace')),
          const SizedBox(height: 6),
          Text('قيمة الخصم: ${_receipt!['discountAmount'] ?? 0} ل.س — المبلغ النهائي: ${_receipt!['finalAmount'] ?? 0} ل.س',
              style: const TextStyle(fontSize: 11, color: Color(0xFF0E2233), fontWeight: FontWeight.bold)),
          TextButton(
            onPressed: () {
              setState(() => _receipt = null);
              _scanner.start();
            },
            child: const Text('عملية جديدة'),
          ),
        ],
      ),
    );
  }
}
