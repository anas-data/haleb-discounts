import 'dart:async';

import 'package:flutter/material.dart';
import 'package:otp/otp.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../../providers/auth_provider.dart';

/// تفاصيل التاجر وتطبيق صلاحيات الخصم:
/// - غير المشترك: «خصم ؟» + زر «اشترك الآن للاستفادة».
/// - المشترك: النسبة الحقيقية + زر «الحصول على الخصم» + كود OTD.
class MerchantDetailsPage extends StatefulWidget {
  const MerchantDetailsPage({
    super.key,
    required this.merchantId,
    required this.merchantName,
    required this.category,
    required this.emoji,
    required this.discount,
    required this.rating,
  });

  final String merchantId;
  final String merchantName;
  final String category;
  final String emoji;
  final int discount;
  final double rating;

  @override
  State<MerchantDetailsPage> createState() => _MerchantDetailsPageState();
}

class _MerchantDetailsPageState extends State<MerchantDetailsPage> {
  Timer? _timer;
  String _code = '';
  int _remaining = 60;
  bool _showCode = false;

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _generateOtd() {
    final auth = context.read<AuthProvider>();
    final user = auth.currentUser;
    if (user == null || !user.hasActiveSubscription) return;

    // في الإنتاج يأتي qrSecret من مستند المستخدم (base32).
    // هنا نستخدم otp لتوليد TOTP بفترة 60 ثانية.
    const secret = 'JBSWY3DPEHPK3PXPHALABSARA';
    final code = OTP.generateTOTPCodeString(
      secret,
      DateTime.now().millisecondsSinceEpoch,
      interval: 60,
      length: 6,
      algorithm: Algorithm.SHA1,
      isGoogle: true,
    );

    setState(() {
      _code = code;
      _remaining = 60;
      _showCode = true;
    });

    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      setState(() => _remaining--);
      if (_remaining <= 0) {
        timer.cancel();
        _timer = null;
        _generateOtd(); // تجديد تلقائي كل 60 ثانية
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final isActive = auth.isSubscriberActive;

    return Scaffold(
      backgroundColor: const Color(0xFFFBF7F0),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFBF7F0),
        title: Text(widget.merchantName, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF7C2D12), Color(0xFFE76F51)]),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Row(
                children: [
                  CircleAvatar(radius: 30, backgroundColor: Colors.white24, child: Text(widget.emoji, style: const TextStyle(fontSize: 28))),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.merchantName, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                        Text('${widget.category} · ⭐ ${widget.rating} · حلب', style: const TextStyle(color: Colors.white70, fontSize: 11)),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(12)),
                    child: Text(isActive ? '${widget.discount}%' : '؟', style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE9E1D3))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('عن الشريك', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF0E2233))),
                  const SizedBox(height: 6),
                  const Text('مطعم/متجر شريك في حلب خصومات يقدّم خدماته وفق شروط العضوية، مع الالتزام بتطبيق نسبة الخصم المعلنة على كامل الفاتورة.',
                      style: TextStyle(fontSize: 11, height: 1.7, color: Color(0xFF6C7A87))),
                  const SizedBox(height: 8),
                  const Row(children: [
                    Icon(Icons.schedule, size: 14, color: Color(0xFF0F766E)),
                    SizedBox(width: 4),
                    Text('يومياً 9:00 ص — 11:00 م', style: TextStyle(fontSize: 10, color: Color(0xFF5B6B79))),
                  ]),
                  const SizedBox(height: 4),
                  const Row(children: [
                    Icon(Icons.place_outlined, size: 14, color: Color(0xFF0F766E)),
                    SizedBox(width: 4),
                    Text('حلب — الفردوس، شارع الجامعة', style: TextStyle(fontSize: 10, color: Color(0xFF5B6B79))),
                  ]),
                ],
              ),
            ),
            const SizedBox(height: 14),
            if (isActive && !_showCode)
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF0F766E),
                  foregroundColor: Colors.white,
                  minimumSize: const Size.fromHeight(52),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: _generateOtd,
                icon: const Icon(Icons.qr_code_2),
                label: const Text('الحصول على الخصم', style: TextStyle(fontWeight: FontWeight.w800)),
              ),
            if (!isActive)
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(color: const Color(0xFFFBF3DF), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFF0E1BC))),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('خصم ؟', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Color(0xFF5C4412))),
                    const Text('هذه النسبة تظهر بعد تفعيل العضوية.', style: TextStyle(fontSize: 11, color: Color(0xFF8A7433))),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFD4A24C), foregroundColor: const Color(0xFF2A1D08)),
                      onPressed: () => Navigator.pushNamed(context, auth.isSignedIn ? '/subscription' : '/register'),
                      child: const Text('اشترك الآن للاستفادة', style: TextStyle(fontWeight: FontWeight.w800)),
                    ),
                  ],
                ),
              ),
            if (isActive && _showCode) ...[
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFC7E7E1))),
                child: Column(
                  children: [
                    const Text('كود OTD لمرة واحدة', style: TextStyle(fontSize: 11, color: Color(0xFF7B8794))),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(12),
                      color: Colors.white,
                      child: QrImageView(
                        data: 'halab-discounts://redeem/$_code?m=${widget.merchantId}',
                        version: QrVersions.auto,
                        size: 210,
                        backgroundColor: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(_code, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: 8, fontFamily: 'monospace', color: Color(0xFF0E2233))),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: _remaining / 60,
                      minHeight: 8,
                      backgroundColor: const Color(0xFFF3EEE4),
                      color: _remaining <= 10 ? Colors.red : const Color(0xFF0F766E),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      _remaining <= 10 ? 'أسرع! الكود على وشك الانتهاء — $_remaining ثانية' : 'صلاحية الكود: $_remaining ثانية',
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: _remaining <= 10 ? Colors.red : const Color(0xFF0F766E)),
                    ),
                    const SizedBox(height: 12),
                    const Text('أظهر هذا الكود لأمين الصندوق قبل الدفع. يتجدد تلقائياً كل 60 ثانية ولا يمكن استخدامه أكثر من مرة.',
                        textAlign: TextAlign.center, style: TextStyle(fontSize: 10, height: 1.7, color: Color(0xFF7B8794))),
                    TextButton.icon(
                      onPressed: _generateOtd,
                      icon: const Icon(Icons.refresh, size: 16),
                      label: const Text('توليد كود جديد الآن', style: TextStyle(fontSize: 11)),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: const Color(0xFFF2FAF8), borderRadius: BorderRadius.circular(12)),
              child: const Row(children: [
                Icon(Icons.shield_outlined, color: Color(0xFF0F766E), size: 18),
                SizedBox(width: 8),
                Expanded(
                  child: Text('الخصم يُطبّق مرة واحدة لكل عملية، وتُسجّل العملية في سجل العضوية والتاجر.',
                      style: TextStyle(fontSize: 10, height: 1.6, color: Color(0xFF0F5F59))),
                ),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}


