import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';
import 'merchant_details_page.dart';

/// الصفحة الرئيسية المزدوجة:
/// - الزائر / غير المشترك: يرى أسماء الشركاء و«؟» بدل نسبة الخصم.
/// - المشترك النشط: يرى النسبة الحقيقية وزر الحصول على الخصم.
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _category = 'الكل';
  final _search = TextEditingController();

  static const _demoMerchants = <Map<String, dynamic>>[
    {'id': 'm1', 'name': 'مطعم الأمير', 'category': 'مطاعم', 'emoji': '🍽️', 'discount': 20, 'rating': 4.8},
    {'id': 'm2', 'name': 'كافيه المدينة', 'category': 'مقاهي', 'emoji': '☕', 'discount': 25, 'rating': 4.6},
    {'id': 'm3', 'name': 'بوتيك النور', 'category': 'ألبسة', 'emoji': '👗', 'discount': 30, 'rating': 4.7},
    {'id': 'm4', 'name': 'صالون ليليان', 'category': 'صحة وجمال', 'emoji': '💅', 'discount': 15, 'rating': 4.5},
    {'id': 'm5', 'name': 'حلويات الشام', 'category': 'حلويات', 'emoji': '🧁', 'discount': 20, 'rating': 4.9},
    {'id': 'm6', 'name': 'مكتبة المعرفة', 'category': 'مكتبات', 'emoji': '📚', 'discount': 18, 'rating': 4.4},
  ];

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final isActive = auth.isSubscriberActive;
    final categories = ['الكل', 'مطاعم', 'مقاهي', 'ألبسة', 'صحة وجمال', 'حلويات', 'مكتبات'];

    final merchants = _demoMerchants.where((m) {
      final matchesCategory = _category == 'الكل' || m['category'] == _category;
      final query = _search.text.trim();
      final matchesQuery = query.isEmpty || (m['name'] as String).contains(query);
      return matchesCategory && matchesQuery;
    }).toList();

    return Scaffold(
      backgroundColor: const Color(0xFFFBF7F0),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFBF7F0),
        title: const Row(
          children: [
            CircleAvatar(radius: 16, backgroundColor: Color(0xFF0F766E), child: Text('%', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
            SizedBox(width: 8),
            Text('حلب خصومات', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: Color(0xFF0E2233))),
          ],
        ),
        actions: [
          IconButton(
            tooltip: auth.isSignedIn ? 'حسابي' : 'دخول',
            onPressed: () {
              if (auth.isSignedIn) {
                Navigator.pushNamed(context, '/home');
              } else {
                Navigator.pushNamed(context, '/login');
              }
            },
            icon: Icon(auth.isSignedIn ? Icons.person_outline : Icons.login, color: const Color(0xFF0F766E)),
          ),
        ],
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // شريط الوضع المجاني
            if (!isActive)
              Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFFBF3DF),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFF0E1BC)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.visibility_outlined, color: Color(0xFFA57C1B)),
                    const SizedBox(width: 8),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('أنت في الوضع المجاني', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Color(0xFF5C4412))),
                          Text('نسب الخصم وأكواد OTD متاحة للمشتركين فقط.', style: TextStyle(fontSize: 10, color: Color(0xFF8A7433))),
                        ],
                      ),
                    ),
                    TextButton(
                      onPressed: () => Navigator.pushNamed(context, auth.isSignedIn ? '/subscription' : '/register'),
                      child: const Text('اشترك الآن', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
                    ),
                  ],
                ),
              ),

            // بطاقة العضوية للمشترك
            if (isActive)
              Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: const Color(0xFF0E2233), borderRadius: BorderRadius.circular(16)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('مرحباً ${auth.currentUser?.name ?? ''} 👋', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 4),
                    const Text('عضوية نشطة · بطاقة العضوية الرقمية جاهزة', style: TextStyle(color: Colors.white60, fontSize: 10)),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        const Icon(Icons.qr_code_2, color: Colors.white70, size: 32),
                        const SizedBox(width: 8),
                        Text(auth.currentUser?.memberId ?? '', style: const TextStyle(color: Color(0xFFD4A24C), fontFamily: 'monospace', fontSize: 12)),
                      ],
                    ),
                  ],
                ),
              ),

            TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'ابحث عن محل أو تصنيف...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE4DCCD))),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 38,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final c = categories[index];
                  final selected = _category == c;
                  return ChoiceChip(
                    label: Text(c, style: TextStyle(fontSize: 11, color: selected ? Colors.white : const Color(0xFF4A5A68))),
                    selected: selected,
                    selectedColor: const Color(0xFF0F766E),
                    backgroundColor: Colors.white,
                    onSelected: (_) => setState(() => _category = c),
                  );
                },
              ),
            ),
            const SizedBox(height: 14),
            const Text('الشركاء القريبون منك', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: Color(0xFF0E2233))),
            const SizedBox(height: 8),
            for (final m in merchants)
              Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: Color(0xFFE9E1D3))),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MerchantDetailsPage(
                        merchantId: m['id'] as String,
                        merchantName: m['name'] as String,
                        category: m['category'] as String,
                        emoji: m['emoji'] as String,
                        discount: m['discount'] as int,
                        rating: (m['rating'] as num).toDouble(),
                      ),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        CircleAvatar(radius: 22, backgroundColor: const Color(0xFFF3EEE4), child: Text(m['emoji'] as String, style: const TextStyle(fontSize: 20))),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(m['name'] as String, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF0E2233))),
                              Text('${m['category']} · ⭐ ${m['rating']}', style: const TextStyle(fontSize: 10, color: Color(0xFF98A4AE))),
                            ],
                          ),
                        ),
                        if (isActive)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(color: const Color(0xFFE7F4F1), borderRadius: BorderRadius.circular(20)),
                            child: Text('خصم ${m['discount']}%', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFF0F766E))),
                          )
                        else
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(color: const Color(0xFFF3EEE4), borderRadius: BorderRadius.circular(20)),
                            child: const Text('خصم ؟', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFF7A6242))),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            if (merchants.isEmpty)
              const Padding(
                padding: EdgeInsets.all(30),
                child: Center(child: Text('لا توجد نتائج مطابقة', style: TextStyle(color: Colors.grey, fontSize: 12))),
              ),
            if (!isActive)
              Container(
                margin: const EdgeInsets.only(top: 8),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: const Color(0xFF0E2233), borderRadius: BorderRadius.circular(14)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('وفّر أكثر مع عضوية حلب خصومات', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15)),
                    const SizedBox(height: 4),
                    const Text('خصومات دائمة + هدية ترحيبية + كود OTD آمن', style: TextStyle(color: Colors.white54, fontSize: 10)),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFD4A24C), foregroundColor: const Color(0xFF2A1D08)),
                        onPressed: () => Navigator.pushNamed(context, '/subscription'),
                        child: const Text('اشترك من 10\$ سنوياً', style: TextStyle(fontWeight: FontWeight.w800)),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
