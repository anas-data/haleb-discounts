import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';

class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({super.key});

  @override
  State<ForgotPasswordPage> createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  bool _sent = false;
  String? _error;

  @override
  void dispose() {
    _email.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (!_formKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final error = await auth.sendPasswordReset(_email.text.trim());
    if (!mounted) return;
    if (error != null) {
      setState(() => _error = error);
      return;
    }
    setState(() {
      _sent = true;
      _error = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      backgroundColor: const Color(0xFFFBF7F0),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: const Color(0xFF0E2233),
        title: const Text('استعادة كلمة المرور', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: _sent
                  ? Column(
                      children: [
                        const CircleAvatar(
                          radius: 34,
                          backgroundColor: Color(0xFFE7F4F1),
                          child: Icon(Icons.mark_email_read_outlined, color: Color(0xFF0F766E), size: 32),
                        ),
                        const SizedBox(height: 16),
                        const Text('تفقّد بريدك الإلكتروني', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Color(0xFF0E2233))),
                        const SizedBox(height: 6),
                        Text(
                          'أرسلنا رابط إعادة تعيين كلمة المرور إلى ${_email.text.trim()}.\nالرابط صالح لمدة 30 دقيقة.',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 12, height: 1.7, color: Color(0xFF6C7A87)),
                        ),
                        const SizedBox(height: 20),
                        OutlinedButton(
                          onPressed: () => setState(() => _sent = false),
                          child: const Text('إرسال إلى بريد آخر'),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pushReplacementNamed(context, '/login'),
                          child: const Text('العودة لتسجيل الدخول', style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ],
                    )
                  : Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            width: 52,
                            height: 52,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(color: const Color(0xFFFBF3DF), borderRadius: BorderRadius.circular(16)),
                            child: const Icon(Icons.key_outlined, color: Color(0xFFA57C1B), size: 26),
                          ),
                          const SizedBox(height: 16),
                          const Text('نسيت كلمة المرور؟', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Color(0xFF0E2233))),
                          const SizedBox(height: 4),
                          const Text('أدخل بريدك الإلكتروني وسنرسل لك رابطاً آمناً لإعادة تعيين كلمة المرور.', style: TextStyle(fontSize: 12, height: 1.7, color: Color(0xFF6C7A87))),
                          const SizedBox(height: 20),
                          TextFormField(
                            controller: _email,
                            keyboardType: TextInputType.emailAddress,
                            textDirection: TextDirection.ltr,
                            decoration: InputDecoration(
                              labelText: 'البريد الإلكتروني المسجل',
                              prefixIcon: const Icon(Icons.mail_outline),
                              errorText: _error,
                              border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
                            ),
                            validator: (v) {
                              if (v == null || v.isEmpty) return 'أدخل بريدك الإلكتروني';
                              if (!RegExp(r'^\S+@\S+\.\S+$').hasMatch(v.trim())) return 'البريد غير صالح';
                              return null;
                            },
                          ),
                          const SizedBox(height: 14),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF0F766E),
                              foregroundColor: Colors.white,
                              minimumSize: const Size.fromHeight(52),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                            ),
                            onPressed: auth.isLoading ? null : _send,
                            child: auth.isLoading
                                ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                : const Text('إرسال رابط الاستعادة', style: TextStyle(fontWeight: FontWeight.bold)),
                          ),
                          const SizedBox(height: 16),
                          TextButton(
                            onPressed: () => Navigator.pushReplacementNamed(context, '/login'),
                            child: const Text('العودة لتسجيل الدخول', style: TextStyle(fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
