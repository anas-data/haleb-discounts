import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';

/// شاشة الترحيب — تظهر لأول فتح أو بعد تسجيل الخروج.
class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  static const _ink = Color(0xFF0E2233);
  static const _teal = Color(0xFF0F766E);
  static const _sand = Color(0xFFFBF7F0);
  static const _gold = Color(0xFFD4A24C);

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: _sand,
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(colors: [_gold, Color(0xFFE76F51)]),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          alignment: Alignment.center,
                          child: const Text('%', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
                        ),
                        const SizedBox(width: 10),
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('حلب خصومات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: _ink)),
                            Text('HALAB DISCOUNTS', style: TextStyle(fontSize: 9, letterSpacing: 2, color: Colors.grey)),
                          ],
                        ),
                      ],
                    ),
                    TextButton(
                      onPressed: () => Navigator.pushNamed(context, '/login'),
                      child: const Text('دخول', style: TextStyle(color: _teal, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
                const SizedBox(height: 36),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(color: const Color(0xFFE7F4F1), borderRadius: BorderRadius.circular(20)),
                  child: const Text('الإصدار 2.0 · المرحلة الأولى: حلب', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: _teal)),
                ),
                const SizedBox(height: 16),
                const Text(
                  'خصوماتك الدائمة\nفي كل مكان بحلب',
                  style: TextStyle(fontSize: 32, height: 1.3, fontWeight: FontWeight.w900, color: _ink),
                ),
                const SizedBox(height: 12),
                const Text(
                  'اشترك مرة واحدة واحصل على خصومات بين 15% و30% طوال العام لدى أفضل المطاعم والكافيهات والمتاجر. بطاقة عضوية رقمية، أكواد OTD، وهدية ترحيبية.',
                  style: TextStyle(fontSize: 13, height: 1.8, color: Color(0xFF5B6B79)),
                ),
                const SizedBox(height: 24),
                const Card(
                  elevation: 0,
                  color: _ink,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20))),
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('بطاقة العضوية الرقمية', style: TextStyle(color: Colors.white54, fontSize: 10)),
                        SizedBox(height: 8),
                        Text('حلب خصومات', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                        Text('ALD-2026-00041', style: TextStyle(color: _gold, fontFamily: 'monospace', fontSize: 12)),
                        SizedBox(height: 16),
                        Row(
                          children: [
                            Icon(Icons.qr_code_2, color: Colors.white70, size: 38),
                            SizedBox(width: 8),
                            Expanded(
                              child: Text('خصومات دائمة · هدية ترحيبية · نظام OTD لمرة واحدة صالح 60 ثانية',
                                  style: TextStyle(color: Colors.white60, fontSize: 10, height: 1.6)),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _teal,
                    foregroundColor: Colors.white,
                    minimumSize: const Size.fromHeight(52),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  onPressed: () => Navigator.pushNamed(context, '/register'),
                  child: const Text('إنشاء حساب جديد', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 10),
                OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _ink,
                    minimumSize: const Size.fromHeight(52),
                    side: const BorderSide(color: Color(0xFFDCD3C4)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  onPressed: () => Navigator.pushNamed(context, '/login'),
                  child: const Text('تسجيل الدخول', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 10),
                TextButton.icon(
                  onPressed: auth.isLoading ? null : () => context.read<AuthProvider>().continueAsGuest(),
                  icon: const Icon(Icons.visibility_outlined, size: 18),
                  label: const Text('تصفح التطبيق كزائر (الوضع المجاني)', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF7B8794))),
                ),
                const Divider(height: 32),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: const [
                    _Feature(icon: Icons.percent, title: 'خصم 30%', subtitle: 'حتى'),
                    _Feature(icon: Icons.storefront, title: '20+', subtitle: 'شريك'),
                    _Feature(icon: Icons.shield_outlined, title: 'OTD', subtitle: 'آمن'),
                  ],
                ),
                const SizedBox(height: 20),
                const Text('© 2026 حلب خصومات — جميع الحقوق محفوظة', textAlign: TextAlign.center, style: TextStyle(fontSize: 9, color: Colors.grey)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Feature extends StatelessWidget {
  const _Feature({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(color: const Color(0xFFE7F4F1), borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: const Color(0xFF0F766E), size: 20),
        ),
        const SizedBox(height: 6),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF0E2233), fontSize: 13)),
        Text(subtitle, style: const TextStyle(fontSize: 10, color: Colors.grey)),
      ],
    );
  }
}
