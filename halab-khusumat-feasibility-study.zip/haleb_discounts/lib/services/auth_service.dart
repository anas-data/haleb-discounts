import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// نموذج المستخدم الموحّد في Firestore.
class AppUser {
  final String uid;
  final String name;
  final String email;
  final String phone;
  final String role; // subscriber | merchant | admin
  final bool isSubscriber;
  final DateTime? subscriptionEndDate;
  final bool welcomeGiftClaimed;
  final String memberId;

  const AppUser({
    required this.uid,
    required this.name,
    required this.email,
    required this.phone,
    required this.role,
    required this.isSubscriber,
    required this.subscriptionEndDate,
    required this.welcomeGiftClaimed,
    required this.memberId,
  });

  bool get hasActiveSubscription =>
      isSubscriber &&
      subscriptionEndDate != null &&
      subscriptionEndDate!.isAfter(DateTime.now());

  bool get isMerchant => role == 'merchant';
  bool get isAdmin => role == 'admin';

  factory AppUser.fromMap(String uid, Map<String, dynamic> data) {
    final rawEnd = data['subscriptionEndDate'];
    return AppUser(
      uid: uid,
      name: (data['name'] ?? '') as String,
      email: (data['email'] ?? '') as String,
      phone: (data['phone'] ?? '') as String,
      role: (data['role'] ?? 'subscriber') as String,
      isSubscriber: (data['isSubscriber'] ?? false) as bool,
      subscriptionEndDate: rawEnd is Timestamp ? rawEnd.toDate() : null,
      welcomeGiftClaimed: (data['welcomeGiftClaimed'] ?? false) as bool,
      memberId: (data['memberId'] ?? '') as String,
    );
  }
}

/// خدمة المصادقة والعضوية — Firebase Auth + Firestore.
class AuthService {
  AuthService({FirebaseAuth? auth, FirebaseFirestore? firestore})
      : _auth = auth ?? FirebaseAuth.instance,
        _db = firestore ?? FirebaseFirestore.instance;

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;

  User? get firebaseUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  CollectionReference<Map<String, dynamic>> get _users => _db.collection('users');

  /// إنشاء حساب جديد: البريد + كلمة المرور، ثم مستند Firestore بدور مشترك غير مدفوع.
  Future<String?> signUpWithEmail({
    required String name,
    required String phone,
    required String email,
    required String password,
  }) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final uid = credential.user!.uid;
      await credential.user!.updateDisplayName(name.trim());
      await credential.user!.sendEmailVerification();

      await _users.doc(uid).set({
        'uid': uid,
        'name': name.trim(),
        'email': email.trim().toLowerCase(),
        'phone': phone.trim(),
        'role': 'subscriber',
        'isSubscriber': false,
        'subscriptionEndDate': null,
        'qrSecret': _generateSecret(),
        'welcomeGiftClaimed': false,
        'giftsOptions': const ['g1', 'g2', 'g3'],
        'memberId': 'ALD-${DateTime.now().year}-${uid.substring(0, 5).toUpperCase()}',
        'emailVerified': false,
        'createdAt': FieldValue.serverTimestamp(),
      });
      return null;
    } on FirebaseAuthException catch (e) {
      return _mapAuthError(e.code);
    } catch (_) {
      return 'حدث خطأ غير متوقع أثناء إنشاء الحساب.';
    }
  }

  /// تسجيل الدخول بالبريد وكلمة المرور، مع جلب الدور وحالة الاشتراك.
  Future<({String? error, AppUser? user})> signInWithEmail({
    required String email,
    required String password,
  }) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final user = credential.user!;
      final profile = await fetchProfile(user.uid);
      if (profile == null) {
        return (error: 'لا يوجد ملف عضوية مرتبط بهذا الحساب.', user: null);
      }
      return (error: null, user: profile);
    } on FirebaseAuthException catch (e) {
      return (error: _mapAuthError(e.code), user: null);
    } catch (_) {
      return (error: 'تعذر تسجيل الدخول، تحقق من الاتصال.', user: null);
    }
  }

  Future<String?> signOut() async {
    try {
      await _auth.signOut();
      return null;
    } catch (_) {
      return 'تعذر تسجيل الخروج.';
    }
  }

  Future<String?> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email.trim());
      return null;
    } on FirebaseAuthException catch (e) {
      return _mapAuthError(e.code);
    }
  }

  Future<String?> sendVerificationEmail() async {
    try {
      await _auth.currentUser?.sendEmailVerification();
      return null;
    } on FirebaseAuthException catch (e) {
      return _mapAuthError(e.code);
    }
  }

  /// Alias متوافق مع مواصفات المهمة: تأكيد البريد الإلكتروني.
  Future<String?> verifyEmail() => sendVerificationEmail();

  Future<bool> isEmailVerified() async => _auth.currentUser?.emailVerified ?? false;

  Future<AppUser?> fetchProfile(String uid) async {
    final doc = await _users.doc(uid).get();
    if (!doc.exists) return null;
    return AppUser.fromMap(uid, doc.data()!);
  }

  Stream<AppUser?> profileStream(String uid) {
    return _users.doc(uid).snapshots().map(
          (doc) => doc.exists ? AppUser.fromMap(uid, doc.data()!) : null,
        );
  }

  /// الحقول المسموح للمستخدم بتحديثها فقط.
  Future<void> updateProfileFields(String uid, Map<String, dynamic> fields) async {
    final allowed = <String>{'name', 'phone', 'profilePhotoUrl'};
    final safe = Map.fromEntries(fields.entries.where((e) => allowed.contains(e.key)));
    if (safe.isEmpty) return;
    await _users.doc(uid).update(safe);
  }

  String _generateSecret() {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    final now = DateTime.now().microsecondsSinceEpoch;
    final buffer = StringBuffer();
    for (var i = 0; i < 32; i++) {
      buffer.write(alphabet[(now + i * 7) % alphabet.length]);
    }
    return buffer.toString();
  }

  String _mapAuthError(String code) {
    switch (code) {
      case 'email-already-in-use':
        return 'هذا البريد مسجل مسبقاً. يمكنك تسجيل الدخول بدلاً من إنشاء حساب جديد.';
      case 'invalid-email':
        return 'صيغة البريد الإلكتروني غير صحيحة.';
      case 'weak-password':
        return 'كلمة المرور ضعيفة. استخدم 6 أحرف على الأقل.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'البريد الإلكتروني أو كلمة المرور غير صحيحة.';
      case 'user-disabled':
        return 'تم تعطيل هذا الحساب. تواصل مع الدعم.';
      case 'too-many-requests':
        return 'محاولات كثيرة. انتظر قليلاً ثم حاول مرة أخرى.';
      case 'network-request-failed':
        return 'تعذر الاتصال بالشبكة. تحقق من الإنترنت.';
      case 'requires-recent-login':
        return 'يرجى إعادة تسجيل الدخول لتأكيد العملية.';
      default:
        return 'حدث خطأ في المصادقة ($code).';
    }
  }
}
