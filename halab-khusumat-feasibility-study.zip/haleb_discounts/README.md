# 🎯 حلب خصومات - تطبيق الخصومات بنموذج الاشتراك

## نظرة عامة

**حلب خصومات** هو تطبيق جوال مبتكر يقدم خصومات دائمة (15-30%) في أكثر من 20 محل تجاري في مدينة حلب، مقابل اشتراك سنوي بقيمة $20.

### الميزات الأساسية

- ✅ خصومات دائمة طوال السنة (ليست لمرة واحدة)
- ✅ نظام OTD آمن (كود متغير كل 60 ثانية)
- ✅ هدية ترحيبية عند الاشتراك
- ✅ وضع مجاني للتصفح
- ✅ تطبيق منفصل للتجار (Scanner)
- ✅ لوحة تحكم ويب للإدارة

---

## 🚀 التشغيل السريع

### المتطلبات

- Flutter SDK 3.0.0+
- Dart 3.0.0+
- Firebase CLI
- Node.js 18+ (للـ Cloud Functions)
- Android Studio / Xcode

### التثبيت

```bash
# 1. نسخ المشروع
git clone https://github.com/your-org/haleb_discounts.git
cd haleb_discounts

# 2. تثبيت الحزم
flutter pub get

# 3. إعداد Firebase
flutterfire configure

# 4. تشغيل التطبيق
flutter run
```

---

## 📁 هيكل المشروع

```
lib/
├── models/          # نماذج البيانات (User, Merchant, Transaction)
├── services/        # خدمات العمل (Auth, OTD, Subscription)
├── providers/       # مزودي الحالة (Provider Pattern)
├── ui/              # واجهات المستخدم
│   ├── user/        # تطبيق المستخدم
│   └── merchant/    # تطبيق التاجر
└── utils/           # أدوات مساعدة

functions/           # Cloud Functions (Node.js/TypeScript)
web_admin/           # لوحة التحكم (Flutter Web)
test/                # الاختبارات
```

---

## 🔧 التكوين

### Firebase

1. أنشئ مشروع Firebase جديد
2. فعّل Authentication (Phone)
3. أنشئ قاعدة بيانات Firestore
4. نزّل `google-services.json` (Android) و `GoogleService-Info.plist` (iOS)
5. راجع `docs/FIREBASE_SETUP.md` للتفاصيل

### المتغيرات البيئية

أنشئ ملف `.env` في المجلد الرئيسي:

```env
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_API_KEY=your-api-key
PAYMENT_GATEWAY_KEY=your-payment-key
```

---

## 🧪 الاختبار

```bash
# اختبارات الوحدة
flutter test

# اختبارات التكامل
flutter drive --target=test_driver/app.dart

# تغطية الكود
flutter test --coverage
```

---

## 📦 البناء والنشر

### Android

```bash
flutter build appbundle --release
```

### iOS

```bash
flutter build ipa --release
```

راجع `docs/DEPLOYMENT.md` للتفاصيل الكاملة.

---

## 🔐 الأمان

- نظام OTD يستخدم TOTP (RFC 6238)
- أكواد صالحة لـ 60 ثانية فقط
- استخدام واحد لكل كود
- تشفير end-to-end للبيانات الحساسة
- Firestore Security Rules صارمة

---

## 🤝 المساهمة

نرحب بالمساهمات! يرجى قراءة `CONTRIBUTING.md` أولاً.

---

## 📄 الترخيص

© 2026 حلب خصومات. جميع الحقوق محفوظة.

---

## 📞 الدعم

- 📧 support@halab-discounts.com
- 🌐 https://halab-discounts.com
- 📱 +963-XXX-XXXXXX
