# وثيقة المواصفات التقنية الشاملة
## مشروع "حلب خصومات" - الإصدار 2.0

---

## 1. بنية النظام الكاملة (System Architecture)

### 1.1 نظرة عامة على البنية

المشروع يعتمد على **بنية ثلاثية الطبقات (3-Tier Architecture)** مع **معمارية Microservices** للقابلية للتوسع:

```
┌─────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                        │
├──────────────┬──────────────┬──────────────┬────────────────┤
│ تطبيق        │ تطبيق        │ موقع ويب     │ لوحة تحكم      │
│ المستخدم     │ التاجر       │ PWA          │ الإدارة        │
│ (Flutter)    │ (Flutter)    │ (React)      │ (React)        │
└──────────────┴──────────────┴──────────────┴────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    API GATEWAY LAYER                         │
│                  (Firebase/AWS API Gateway)                  │
│  - Rate Limiting                                             │
│  - Authentication & Authorization                            │
│  - Request Routing                                           │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                   BUSINESS LOGIC LAYER                       │
├──────────────┬──────────────┬──────────────┬────────────────┤
│ User Service │ Merchant     │ Transaction  │ Notification   │
│              │ Service      │ Service      │ Service        │
│ - التسجيل    │ - إدارة      │ - توليد OTD  │ - Push         │
│ - الاشتراك   │   التجار     │ - التحقق     │ - Geofencing   │
│ - الملف      │ - العقود     │ - الأرشفة    │ - Email/SMS    │
│   الشخصي     │              │              │                │
└──────────────┴──────────────┴──────────────┴────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                      DATA LAYER                              │
├──────────────┬──────────────┬──────────────┬────────────────┤
│ Firestore/   │ Cloud        │ Redis Cache  │ Cloud Storage  │
│ DynamoDB     │ Functions    │              │                │
│ (NoSQL)      │ (Serverless) │ (Session/OTD)│ (Media Files)  │
└──────────────┴──────────────┴──────────────┴────────────────┘
```

### 1.2 اختيار التقنيات الأساسية

#### Front-End Applications

**1. تطبيق المستخدم (Customer App) - Flutter**
- **المنصات**: iOS & Android (Single Codebase)
- **لغة البرمجة**: Dart
- **الحزم الرئيسية**:
  - `firebase_core` و `firebase_auth` للمصادقة
  - `qr_flutter` لتوليد QR codes
  - `provider` أو `riverpod` لإدارة الحالة
  - `geolocator` للـ Geofencing
  - `flutter_local_notifications` للإشعارات

**2. تطبيق التاجر (Merchant App) - Flutter**
- نفس التقنية للتوافق
- **إضافات خاصة**:
  - `mobile_scanner` أو `qr_code_scanner` لمسح الأكواد
  - `syncfusion_flutter_charts` للتقارير

**3. موقع الويب PWA - React**
- **Framework**: React 18 + TypeScript
- **UI Library**: Tailwind CSS
- **State Management**: Redux Toolkit أو Zustand
- **PWA Support**: Workbox للعمل Offline

**4. لوحة تحكم الإدارة (Admin Dashboard) - React**
- **إضافات**: 
  - Material-UI أو Ant Design
  - Recharts للتحليلات
  - React Table للجداول

#### Back-End Infrastructure

**الخيار الموصى به: Firebase (Google Cloud)**

**المبررات**:
- ✅ سرعة التطوير (MVP في 8 أسابيع)
- ✅ تكامل ممتاز مع Flutter
- ✅ تكلفة منخفضة للبداية (Pay-as-you-go)
- ✅ قابلية توسع تلقائية
- ✅ Authentication جاهزة
- ✅ Firestore للبيانات الفورية (Real-time)

**الخدمات المستخدمة**:

1. **Firebase Authentication**
   - التسجيل عبر الهاتف (Phone OTP)
   - التسجيل عبر البريد وكلمة المرور
   - Custom Claims للتمييز بين (مجاني، مشترك، تاجر، إدارة)

2. **Cloud Firestore (قاعدة البيانات)**
   - NoSQL للمرونة
   - Real-time Sync
   - Offline Support

3. **Cloud Functions (الوظائف الخلفية)**
   - Node.js/TypeScript
   - معالجة المدفوعات
   - توليد OTD Tokens
   - التحقق من الأكواد
   - إرسال الإشعارات

4. **Cloud Storage**
   - تخزين صور الشركات
   - شعارات المنتجات
   - صور المستخدمين

5. **Firebase Cloud Messaging (FCM)**
   - Push Notifications
   - Geofencing Triggers

6. **Firebase Performance Monitoring**
   - مراقبة الأداء

**الخيار البديل: AWS**

إذا اختير AWS:
- **Cognito**: للمصادقة
- **DynamoDB**: قاعدة البيانات NoSQL
- **Lambda**: للوظائف Serverless
- **API Gateway**: لإدارة APIs
- **S3**: للملفات
- **SNS/SQS**: للإشعارات
- **ElastiCache (Redis)**: للـ Caching

### 1.3 بنية الأمان (Security Architecture)

```
┌────────────────────────────────────────────────────┐
│         Security Layers (طبقات الأمان)             │
├────────────────────────────────────────────────────┤
│ 1. Transport Layer (HTTPS/TLS 1.3)                │
│ 2. Authentication (Firebase Auth + JWT)           │
│ 3. Authorization (Custom Claims + RBAC)           │
│ 4. API Rate Limiting (منع الهجمات)                │
│ 5. Input Validation (Sanitization)                │
│ 6. OTD Token Security (TOTP + Server Validation)  │
│ 7. Data Encryption (at rest & in transit)         │
│ 8. Audit Logging (تسجيل كل العمليات)              │
└────────────────────────────────────────────────────┘
```

---

## 2. مخطط قاعدة البيانات (Database Schema)

### 2.1 هيكل Firestore Collections

#### Collection: `users`
```javascript
users/{userId}
{
  // معلومات أساسية
  userId: string,              // معرف فريد (Firebase UID)
  phoneNumber: string,         // رقم الهاتف (فريد)
  email: string | null,        // البريد (اختياري)
  fullName: string,            // الاسم الكامل
  profilePhoto: string | null, // رابط الصورة الشخصية
  
  // حالة الاشتراك
  accountType: enum('free', 'subscriber', 'merchant', 'admin'),
  
  // بيانات الاشتراك (إن كان مشتركاً)
  subscription: {
    membershipId: string,      // رقم العضوية الفريد (مثال: ALD-2026-00001)
    qrCode: string,            // QR Code ثابت للعضوية (للعرض فقط)
    status: enum('active', 'expired', 'suspended'),
    plan: enum('monthly', 'semi-annual', 'annual'),
    startDate: timestamp,
    endDate: timestamp,
    renewalDate: timestamp,
    autoRenew: boolean,
    paymentMethod: string,     // 'card', 'wallet', 'voucher'
    
    // الهدية الترحيبية
    welcomeGift: {
      isRedeemed: boolean,
      giftId: string | null,   // معرف الهدية المختارة
      redeemedAt: timestamp | null,
      availableGifts: [giftId1, giftId2, giftId3] // الخيارات المعروضة
    }
  } | null,
  
  // إحصائيات الاستخدام
  stats: {
    totalDiscountsUsed: number,
    totalSavings: number,       // بالليرة السورية
    favoriteCategories: [string],
    lastUsedAt: timestamp | null
  },
  
  // الإعدادات
  settings: {
    notificationsEnabled: boolean,
    geofencingEnabled: boolean,
    language: string,            // 'ar', 'en'
  },
  
  // Metadata
  createdAt: timestamp,
  updatedAt: timestamp,
  lastLoginAt: timestamp
}
```

#### Collection: `merchants` (التجار)
```javascript
merchants/{merchantId}
{
  merchantId: string,
  ownerId: string,             // ربط بـ userId في حال كان المالك مسجلاً
  
  // معلومات العمل
  businessName: string,        // اسم المحل (مثال: "مطعم الأمير")
  businessNameEn: string | null,
  logo: string,                // رابط الشعار
  category: enum('restaurant', 'cafe', 'fashion', 'beauty', 'books', 'gifts', 'delivery', 'other'),
  subcategory: string,         // تصنيف فرعي
  
  // معلومات الاتصال
  contactInfo: {
    phoneNumbers: [string],
    email: string | null,
    website: string | null,
    socialMedia: {
      facebook: string | null,
      instagram: string | null,
      whatsapp: string | null
    }
  },
  
  // الفروع (دعم متعدد)
  branches: [
    {
      branchId: string,
      name: string,
      address: string,
      location: geopoint,      // للـ Geofencing
      workingHours: {
        sunday: {open: '09:00', close: '23:00', isClosed: false},
        monday: {...},
        // ... باقي الأيام
      },
      phone: string
    }
  ],
  
  // الخصم المقدم
  discount: {
    percentage: number,        // مثال: 20
    description: string,       // "20% على كامل الفاتورة"
    descriptionEn: string | null,
    minPurchase: number | null,// الحد الأدنى للشراء (اختياري)
    maxDiscount: number | null,// الحد الأقصى للخصم (اختياري)
    excludedItems: [string] | null, // عناصر مستثناة
    validDays: [0,1,2,3,4,5,6], // الأيام الصالحة (0=الأحد)
    validHours: {start: '00:00', end: '23:59'} | null
  },
  
  // حالة الاشتراك في المنصة
  subscription: {
    status: enum('trial', 'active', 'suspended', 'cancelled'),
    plan: enum('basic', 'premium'), // basic=إدراج عادي, premium=إعلانات مميزة
    startDate: timestamp,
    endDate: timestamp,
    monthlyFee: number,        // بالدولار
    paymentStatus: enum('paid', 'pending', 'overdue')
  },
  
  // إحصائيات
  stats: {
    totalScans: number,        // عدد مرات مسح الكود
    totalRevenue: number,      // الإيرادات التي جاءت عبر المنصة (تقديري)
    averageTicket: number,     // متوسط قيمة الفاتورة
    rating: number,            // تقييم من المستخدمين (1-5)
    totalReviews: number
  },
  
  // معلومات إضافية
  media: {
    photos: [string],          // صور المحل/المنتجات
    menu: string | null,       // رابط لقائمة الطعام (PDF)
    video: string | null
  },
  
  // Metadata
  isVerified: boolean,         // تم التحقق من المحل
  isFeatured: boolean,         // ظهور مميز
  createdAt: timestamp,
  updatedAt: timestamp
}
```

#### Collection: `transactions` (سجل المعاملات)
```javascript
transactions/{transactionId}
{
  transactionId: string,
  
  // الأطراف المعنية
  userId: string,              // المشترك
  merchantId: string,          // التاجر
  branchId: string,            // الفرع
  
  // تفاصيل العملية
  otdToken: string,            // الكود الذي تم استخدامه
  generatedAt: timestamp,      // وقت توليد الكود
  scannedAt: timestamp,        // وقت المسح الفعلي
  expiresAt: timestamp,        // وقت انتهاء صلاحية الكود (generatedAt + 60 ثانية)
  
  // معلومات الخصم
  discountPercentage: number,  // النسبة المطبقة
  originalAmount: number | null, // قيمة الفاتورة الأصلية (اختياري)
  discountAmount: number | null, // قيمة الخصم بالليرة
  finalAmount: number | null,    // المبلغ النهائي
  
  // بيانات الموقع (للتحقق)
  location: geopoint | null,
  
  // حالة العملية
  status: enum('generated', 'scanned', 'expired', 'fraudulent'),
  
  // معلومات التحقق
  verification: {
    merchantUserId: string,    // من قام بالمسح من جانب التاجر
    deviceId: string,          // معرف جهاز التاجر
    ipAddress: string
  },
  
  // Fraud Detection
  fraudFlags: {
    isDuplicate: boolean,
    isOutsideGeofence: boolean,
    isExpired: boolean,
    suspiciousActivity: string | null
  },
  
  createdAt: timestamp
}
```

#### Collection: `gifts` (الهدايا الترحيبية)
```javascript
gifts/{giftId}
{
  giftId: string,
  
  // معلومات الهدية
  title: string,               // "قسيمة شراء بقيمة 500 ليرة"
  titleEn: string | null,
  description: string,
  image: string,
  
  // القيمة
  value: number,               // القيمة التقديرية
  
  // الجهة المانحة
  providedBy: {
    merchantId: string,        // التاجر الذي يقدم الهدية
    merchantName: string
  },
  
  // الشروط
  termsAndConditions: string,
  validUntil: timestamp | null, // صلاحية الهدية
  isActive: boolean,
  stock: number | null,        // الكمية المتاحة (null = غير محدود)
  
  // إحصائيات
  stats: {
    totalRedeemed: number,
    totalOffered: number
  },
  
  createdAt: timestamp,
  updatedAt: timestamp
}
```

#### Collection: `advertisements` (الإعلانات المميزة)
```javascript
advertisements/{adId}
{
  adId: string,
  merchantId: string,
  
  // محتوى الإعلان
  title: string,
  description: string,
  image: string,
  ctaText: string,             // نص الزر (Call to Action)
  ctaLink: string,             // الرابط أو الإجراء
  
  // الاستهداف
  targeting: {
    categories: [string] | null,
    cities: ['حلب'] | null,
    userType: enum('all', 'subscribers_only', 'free_users')
  },
  
  // الجدولة
  schedule: {
    startDate: timestamp,
    endDate: timestamp,
    isActive: boolean
  },
  
  // الموضع
  placement: enum('home_banner', 'category_top', 'push_notification'),
  priority: number,            // 1 = أعلى أولوية
  
  // التكلفة والنتائج
  pricing: {
    model: enum('flat_fee', 'cpm', 'cpc'), // رسم ثابت، تكلفة لكل ألف ظهور، تكلفة لكل نقرة
    amount: number
  },
  
  stats: {
    impressions: number,       // عدد مرات الظهور
    clicks: number,            // عدد النقرات
    conversions: number        // عدد الاشتراكات/المعاملات الناتجة
  },
  
  createdAt: timestamp,
  updatedAt: timestamp
}
```

#### Collection: `notifications` (سجل الإشعارات)
```javascript
notifications/{notificationId}
{
  notificationId: string,
  
  // المستلم
  userId: string | null,       // null = إشعار جماعي
  userSegment: string | null,  // 'all_subscribers', 'near_merchant_X', إلخ.
  
  // المحتوى
  title: string,
  body: string,
  image: string | null,
  
  // الإجراء
  action: {
    type: enum('open_app', 'open_merchant', 'open_url'),
    payload: string | null     // merchantId أو URL
  },
  
  // الإرسال
  sentAt: timestamp,
  deliveredCount: number,
  openedCount: number,
  
  // الحالة
  status: enum('scheduled', 'sent', 'failed'),
  
  createdAt: timestamp
}
```

#### Collection: `geofences` (المناطق الجغرافية للإشعارات)
```javascript
geofences/{geofenceId}
{
  geofenceId: string,
  merchantId: string,
  branchId: string,
  
  // الموقع
  center: geopoint,
  radius: number,              // بالمتر (مثال: 100)
  
  // الإشعار المُرسَل
  notification: {
    title: string,
    body: string,              // "أنت على بعد 100 متر من مطعم X، خصمك 20% جاهز!"
    enabled: boolean
  },
  
  // الإحصائيات
  stats: {
    totalTriggers: number,     // عدد المرات التي دخل فيها مستخدمون المنطقة
    totalConversions: number   // عدد المستخدمين الذين استفادوا بالفعل
  },
  
  isActive: boolean,
  createdAt: timestamp
}
```

#### Collection: `referrals` (برنامج الإحالة)
```javascript
referrals/{referralId}
{
  referralId: string,
  
  referrerId: string,          // المُحيل
  referredUserId: string,      // المُحال
  
  // الحالة
  status: enum('pending', 'completed', 'rewarded'),
  
  // المكافأة
  reward: {
    type: enum('free_month', 'discount', 'cash'),
    value: number,
    appliedAt: timestamp | null
  },
  
  createdAt: timestamp,
  completedAt: timestamp | null
}
```

### 2.2 مؤشرات Firestore (Indexes)

لتحسين الأداء، يجب إنشاء المؤشرات التالية:

```javascript
// Index 1: استعلام المعاملات حسب المستخدم والتاريخ
Collection: transactions
Fields: userId (Ascending), scannedAt (Descending)

// Index 2: استعلام التجار حسب التصنيف والتقييم
Collection: merchants
Fields: category (Ascending), stats.rating (Descending), subscription.status (Ascending)

// Index 3: الإعلانات النشطة حسب الأولوية
Collection: advertisements
Fields: schedule.isActive (Ascending), priority (Ascending)

// Index 4: المستخدمين المشتركين النشطين
Collection: users
Fields: accountType (Ascending), subscription.status (Ascending), subscription.endDate (Ascending)
```

### 2.3 قواعد الأمان (Security Rules)

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // دالة مساعدة للتحقق من المصادقة
    function isAuthenticated() {
      return request.auth != null;
    }
    
    // دالة للتحقق من نوع المستخدم
    function isSubscriber() {
      return isAuthenticated() && 
             get(/databases/$(database)/documents/users/$(request.auth.uid)).data.accountType == 'subscriber';
    }
    
    function isMerchant() {
      return isAuthenticated() && 
             get(/databases/$(database)/documents/users/$(request.auth.uid)).data.accountType == 'merchant';
    }
    
    function isAdmin() {
      return isAuthenticated() && 
             get(/databases/$(database)/documents/users/$(request.auth.uid)).data.accountType == 'admin';
    }
    
    // قواعد المستخدمين
    match /users/{userId} {
      // القراءة: فقط المستخدم نفسه أو الإدارة
      allow read: if isAuthenticated() && (request.auth.uid == userId || isAdmin());
      
      // الكتابة: فقط المستخدم نفسه
      allow update: if isAuthenticated() && request.auth.uid == userId;
      
      // الإنشاء: أي شخص (للتسجيل)
      allow create: if isAuthenticated();
      
      // الحذف: فقط الإدارة
      allow delete: if isAdmin();
    }
    
    // قواعد التجار
    match /merchants/{merchantId} {
      // القراءة: الجميع (للعرض في التطبيق)
      allow read: if true;
      
      // الكتابة: فقط التاجر نفسه أو الإدارة
      allow update: if isAuthenticated() && 
                       (resource.data.ownerId == request.auth.uid || isAdmin());
      
      // الإنشاء والحذف: فقط الإدارة
      allow create, delete: if isAdmin();
    }
    
    // قواعد المعاملات
    match /transactions/{transactionId} {
      // القراءة: المستخدم المعني، التاجر المعني، أو الإدارة
      allow read: if isAuthenticated() && 
                     (resource.data.userId == request.auth.uid || 
                      resource.data.merchantId == request.auth.uid || 
                      isAdmin());
      
      // الإنشاء: فقط عبر Cloud Functions (للأمان)
      allow create: if false;
      
      // التحديث والحذف: فقط الإدارة
      allow update, delete: if isAdmin();
    }
    
    // قواعد الهدايا
    match /gifts/{giftId} {
      allow read: if true; // الجميع يمكنهم رؤية الهدايا
      allow write: if isAdmin();
    }
    
    // قواعد الإعلانات
    match /advertisements/{adId} {
      allow read: if true;
      allow write: if isAdmin();
    }
    
    // قواعد الإشعارات
    match /notifications/{notificationId} {
      allow read: if isAuthenticated();
      allow write: if isAdmin();
    }
    
    // قواعد Geofences
    match /geofences/{geofenceId} {
      allow read: if isAuthenticated();
      allow write: if isAdmin();
    }
    
    // قواعد الإحالات
    match /referrals/{referralId} {
      allow read: if isAuthenticated() && 
                     (resource.data.referrerId == request.auth.uid || 
                      resource.data.referredUserId == request.auth.uid);
      allow create: if isAuthenticated();
      allow update, delete: if isAdmin();
    }
  }
}
```

---

## 3. هيكل API - قائمة النقاط النهائية (Endpoints)

### 3.1 تطبيق المستخدم (Customer App API)

#### Authentication & User Management

```
POST   /api/v1/auth/register
POST   /api/v1/auth/login
POST   /api/v1/auth/verify-otp
POST   /api/v1/auth/logout
POST   /api/v1/auth/refresh-token
GET    /api/v1/auth/me
```

**مثال - التسجيل:**
```http
POST /api/v1/auth/register
Content-Type: application/json

Request:
{
  "phoneNumber": "+963987654321",
  "fullName": "أحمد محمد",
  "email": "ahmad@example.com" // optional
}

Response (201 Created):
{
  "success": true,
  "data": {
    "userId": "user_abc123",
    "phoneNumber": "+963987654321",
    "otpSent": true,
    "expiresIn": 300 // seconds
  }
}
```

#### Subscription Management

```
GET    /api/v1/subscriptions/plans
POST   /api/v1/subscriptions/subscribe
GET    /api/v1/subscriptions/my-subscription
POST   /api/v1/subscriptions/cancel
POST   /api/v1/subscriptions/renew
```

**مثال - الاشتراك:**
```http
POST /api/v1/subscriptions/subscribe
Authorization: Bearer {token}
Content-Type: application/json

Request:
{
  "plan": "annual", // 'monthly', 'semi-annual', 'annual'
  "paymentMethod": "card",
  "paymentDetails": {
    "cardToken": "tok_xxxxxxxxx"
  }
}

Response (200 OK):
{
  "success": true,
  "data": {
    "subscriptionId": "sub_xyz789",
    "membershipId": "ALD-2026-00001",
    "status": "active",
    "startDate": "2026-05-15T10:00:00Z",
    "endDate": "2027-05-15T10:00:00Z",
    "qrCode": "https://storage.../qr_codes/ALD-2026-00001.png",
    "welcomeGift": {
      "availableGifts": ["gift1", "gift2", "gift3"]
    }
  }
}
```

#### Merchants & Discounts

```
GET    /api/v1/merchants
GET    /api/v1/merchants/:merchantId
GET    /api/v1/merchants/categories
GET    /api/v1/merchants/nearby?lat=36.2&lng=37.1&radius=5000
GET    /api/v1/merchants/:merchantId/reviews
POST   /api/v1/merchants/:merchantId/reviews
```

**مثال - استعلام التجار:**
```http
GET /api/v1/merchants?category=restaurant&city=حلب&page=1&limit=20
Authorization: Bearer {token}

Response (200 OK):
{
  "success": true,
  "data": {
    "merchants": [
      {
        "merchantId": "merchant_001",
        "businessName": "مطعم الأمير",
        "logo": "https://...",
        "category": "restaurant",
        "discount": {
          "percentage": 20,
          "description": "20% على كامل الفاتورة",
          "isAvailableNow": true // يتحقق من الوقت والأيام
        },
        "branches": [...],
        "rating": 4.5,
        "isSubscriberOnly": false // في الوضع المجاني يظهر false دائماً
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 5,
      "totalItems": 95
    }
  }
}
```

#### OTD (One-Time Discount) Generation

```
POST   /api/v1/discounts/generate-otd
GET    /api/v1/discounts/history
GET    /api/v1/discounts/statistics
```

**مثال - توليد كود خصم:**
```http
POST /api/v1/discounts/generate-otd
Authorization: Bearer {token}
Content-Type: application/json

Request:
{
  "merchantId": "merchant_001",
  "branchId": "branch_001"
}

Response (200 OK):
{
  "success": true,
  "data": {
    "otdToken": "OTD_1a2b3c4d5e6f",
    "qrCodeData": "halab-discounts://redeem/OTD_1a2b3c4d5e6f",
    "generatedAt": "2026-05-15T14:30:00Z",
    "expiresAt": "2026-05-15T14:31:00Z", // 60 ثانية فقط
    "merchantInfo": {
      "name": "مطعم الأمير",
      "discount": 20
    }
  }
}

// ملاحظة: هذا الـ Token يُحفظ في Redis بـ TTL 60 ثانية
```

#### Welcome Gift

```
GET    /api/v1/gifts/available
POST   /api/v1/gifts/redeem
```

**مثال - اختيار الهدية الترحيبية:**
```http
POST /api/v1/gifts/redeem
Authorization: Bearer {token}
Content-Type: application/json

Request:
{
  "giftId": "gift_002"
}

Response (200 OK):
{
  "success": true,
  "data": {
    "giftTitle": "قسيمة شراء بقيمة 1000 ليرة من متجر النور",
    "giftCode": "WELCOME-ALD-00001",
    "redeemedAt": "2026-05-15T10:05:00Z",
    "validUntil": "2026-06-15T23:59:59Z",
    "instructions": "أظهر هذا الكود في متجر النور..."
  }
}
```

#### Referrals

```
GET    /api/v1/referrals/my-code
POST   /api/v1/referrals/apply-code
GET    /api/v1/referrals/stats
```

#### Notifications

```
GET    /api/v1/notifications
PUT    /api/v1/notifications/:notificationId/mark-read
POST   /api/v1/notifications/register-device
DELETE /api/v1/notifications/unregister-device
```

---

### 3.2 تطبيق التاجر (Merchant App API)

#### Authentication

```
POST   /api/v1/merchant-auth/login
POST   /api/v1/merchant-auth/logout
GET    /api/v1/merchant-auth/me
```

#### OTD Verification (الوظيفة الأهم)

```
POST   /api/v1/merchant/verify-otd
GET    /api/v1/merchant/transactions
GET    /api/v1/merchant/transactions/:transactionId
```

**مثال - التحقق من كود الخصم:**
```http
POST /api/v1/merchant/verify-otd
Authorization: Bearer {merchant_token}
Content-Type: application/json

Request:
{
  "otdToken": "OTD_1a2b3c4d5e6f",
  "branchId": "branch_001",
  "originalAmount": 5000, // اختياري
  "location": { // للتحقق من Geofencing
    "latitude": 36.2001,
    "longitude": 37.1556
  }
}

Response (200 OK):
{
  "success": true,
  "data": {
    "isValid": true,
    "customerInfo": {
      "membershipId": "ALD-2026-00001",
      "fullName": "أحمد محمد",
      "profilePhoto": "https://...",
      "memberSince": "2026-05-15"
    },
    "discount": {
      "percentage": 20,
      "discountAmount": 1000, // إذا تم تقديم originalAmount
      "finalAmount": 4000
    },
    "transactionId": "txn_abc123",
    "scannedAt": "2026-05-15T14:30:45Z"
  }
}

// أو في حالة خطأ:
Response (400 Bad Request):
{
  "success": false,
  "error": {
    "code": "OTD_EXPIRED",
    "message": "هذا الكود انتهت صلاحيته",
    "expiredAt": "2026-05-15T14:31:00Z"
  }
}

// أكواد الخطأ المحتملة:
// - OTD_EXPIRED: انتهت الصلاحية
// - OTD_ALREADY_USED: تم استخدام الكود مسبقاً
// - OTD_INVALID: كود غير صحيح
// - OTD_WRONG_MERCHANT: الكود ليس لهذا التاجر
// - USER_NOT_SUBSCRIBER: المستخدم ليس مشتركاً
// - GEOFENCE_VIOLATION: الموقع خارج النطاق المسموح
```

#### Reports & Analytics

```
GET    /api/v1/merchant/dashboard
GET    /api/v1/merchant/analytics?period=monthly
GET    /api/v1/merchant/reports/transactions?from=2026-05-01&to=2026-05-31
GET    /api/v1/merchant/reports/export?format=csv
```

**مثال - لوحة المعلومات:**
```http
GET /api/v1/merchant/dashboard
Authorization: Bearer {merchant_token}

Response (200 OK):
{
  "success": true,
  "data": {
    "today": {
      "totalScans": 45,
      "totalRevenue": 225000,
      "averageTicket": 5000
    },
    "thisMonth": {
      "totalScans": 1250,
      "totalRevenue": 6250000,
      "newCustomers": 320,
      "returningCustomers": 930
    },
    "topHours": [
      {"hour": "13:00-14:00", "scans": 89},
      {"hour": "20:00-21:00", "scans": 76}
    ],
    "recentTransactions": [...]
  }
}
```

#### Profile Management

```
GET    /api/v1/merchant/profile
PUT    /api/v1/merchant/profile
POST   /api/v1/merchant/branches
PUT    /api/v1/merchant/branches/:branchId
DELETE /api/v1/merchant/branches/:branchId
POST   /api/v1/merchant/media/upload
```

---

### 3.3 لوحة التحكم الإدارية (Admin Dashboard API)

#### Dashboard Overview

```
GET    /api/v1/admin/dashboard
GET    /api/v1/admin/analytics
```

#### User Management

```
GET    /api/v1/admin/users
GET    /api/v1/admin/users/:userId
PUT    /api/v1/admin/users/:userId/suspend
PUT    /api/v1/admin/users/:userId/activate
DELETE /api/v1/admin/users/:userId
```

#### Merchant Management

```
GET    /api/v1/admin/merchants
GET    /api/v1/admin/merchants/:merchantId
POST   /api/v1/admin/merchants
PUT    /api/v1/admin/merchants/:merchantId
DELETE /api/v1/admin/merchants/:merchantId
PUT    /api/v1/admin/merchants/:merchantId/verify
PUT    /api/v1/admin/merchants/:merchantId/feature
```

#### Transactions & Fraud Detection

```
GET    /api/v1/admin/transactions
GET    /api/v1/admin/transactions/suspicious
PUT    /api/v1/admin/transactions/:transactionId/flag-fraud
GET    /api/v1/admin/fraud-reports
```

#### Gifts Management

```
GET    /api/v1/admin/gifts
POST   /api/v1/admin/gifts
PUT    /api/v1/admin/gifts/:giftId
DELETE /api/v1/admin/gifts/:giftId
```

#### Advertisements

```
GET    /api/v1/admin/advertisements
POST   /api/v1/admin/advertisements
PUT    /api/v1/admin/advertisements/:adId
DELETE /api/v1/admin/advertisements/:adId
```

#### Notifications & Campaigns

```
POST   /api/v1/admin/notifications/send
POST   /api/v1/admin/notifications/schedule
GET    /api/v1/admin/notifications/history
```

#### Reports & Export

```
GET    /api/v1/admin/reports/financial?period=2026-05
GET    /api/v1/admin/reports/users?period=2026-05
GET    /api/v1/admin/reports/merchants?period=2026-05
GET    /api/v1/admin/reports/export?type=all&format=xlsx
```

---

تم إكمال الجزء الأول من المواصفات التقنية. التالي: آلية OTD بالتفصيل...
