# آلية نظام OTD (One-Time Discount) المتقدمة
## مشروع "حلب خصومات"

---

## 1. نظرة عامة على نظام OTD

### 1.1 المتطلبات الأساسية

نظام OTD يجب أن يحقق:

1. ✅ **الأمان المطلق**: منع إعادة استخدام نفس الكود
2. ✅ **منع التقاط الشاشة**: الكود صالح لمدة 60 ثانية فقط
3. ✅ **التحقق الفوري**: مسح QR يتحقق من الصلاحية فوراً
4. ✅ **منع التزوير**: استخدام خوارزميات TOTP المشفرة
5. ✅ **الأرشفة الكاملة**: تسجيل كل عملية لمنع التلاعب
6. ✅ **Geofencing**: التحقق من أن الاستخدام في الموقع الصحيح

---

## 2. الخوارزمية الأساسية - TOTP المعدلة

### 2.1 مبدأ عمل TOTP (Time-based One-Time Password)

TOTP هي خوارزمية قياسية (RFC 6238) تُستخدم في المصادقة الثنائية (2FA)، ونحن نُعدّلها لتناسب نظام الخصومات.

**المعادلة الأساسية:**
```
OTD_Token = HMAC-SHA256(
  secret_key, 
  timestamp_counter
) + metadata
```

**المكونات:**
- `secret_key`: مفتاح سري مشترك بين السيرفر والتطبيق (مخزن في Firestore/Redis)
- `timestamp_counter`: الزمن الحالي مقسوماً على 60 ثانية (النافذة الزمنية)
- `metadata`: معرف المستخدم + معرف التاجر + رقم عشوائي (nonce)

### 2.2 خطوات توليد OTD Token

#### Server-Side (Cloud Function)

```javascript
/**
 * Cloud Function: generateOTD
 * يتم استدعاؤها عندما يضغط المشترك على "استخدام الخصم"
 */

const crypto = require('crypto');
const admin = require('firebase-admin');

exports.generateOTD = async (req, res) => {
  try {
    // 1. التحقق من المصادقة
    const userId = req.auth.uid;
    const { merchantId, branchId } = req.body;
    
    // 2. التحقق من أن المستخدم مشترك نشط
    const userDoc = await admin.firestore().collection('users').doc(userId).get();
    const userData = userDoc.data();
    
    if (userData.accountType !== 'subscriber' || 
        userData.subscription.status !== 'active') {
      return res.status(403).json({
        success: false,
        error: 'USER_NOT_SUBSCRIBER'
      });
    }
    
    // 3. التحقق من وجود التاجر والفرع
    const merchantDoc = await admin.firestore()
      .collection('merchants')
      .doc(merchantId)
      .get();
    
    if (!merchantDoc.exists) {
      return res.status(404).json({
        success: false,
        error: 'MERCHANT_NOT_FOUND'
      });
    }
    
    const merchantData = merchantDoc.data();
    const branch = merchantData.branches.find(b => b.branchId === branchId);
    
    if (!branch) {
      return res.status(404).json({
        success: false,
        error: 'BRANCH_NOT_FOUND'
      });
    }
    
    // 4. التحقق من أن الخصم متاح الآن (حسب الوقت/اليوم)
    const now = new Date();
    const currentDay = now.getDay(); // 0 = الأحد
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    
    if (!merchantData.discount.validDays.includes(currentDay)) {
      return res.status(400).json({
        success: false,
        error: 'DISCOUNT_NOT_AVAILABLE_TODAY'
      });
    }
    
    // 5. توليد الـ OTD Token
    const timestamp = Math.floor(Date.now() / 1000); // Unix timestamp بالثواني
    const timeCounter = Math.floor(timestamp / 60); // نافذة 60 ثانية
    
    // المفتاح السري (يُخزن في Environment Variables ولا يُكشف أبداً)
    const SECRET_KEY = process.env.OTD_SECRET_KEY; // مثال: "halab_discounts_secret_2026_v1"
    
    // Nonce عشوائي لمنع التنبؤ
    const nonce = crypto.randomBytes(8).toString('hex');
    
    // البيانات المُدخلة للـ HMAC
    const payload = `${userId}|${merchantId}|${branchId}|${timeCounter}|${nonce}`;
    
    // توليد الـ HMAC
    const hmac = crypto.createHmac('sha256', SECRET_KEY);
    hmac.update(payload);
    const hash = hmac.digest('hex');
    
    // الـ Token النهائي (24 حرف من الـ hash + metadata مشفرة)
    const tokenCore = hash.substring(0, 24).toUpperCase();
    const otdToken = `OTD_${tokenCore}`;
    
    // 6. حفظ الـ Token في Redis (TTL = 60 ثانية)
    const redis = getRedisClient(); // دالة للحصول على اتصال Redis
    const tokenData = {
      userId,
      merchantId,
      branchId,
      discountPercentage: merchantData.discount.percentage,
      generatedAt: timestamp,
      expiresAt: timestamp + 60,
      nonce,
      timeCounter,
      hash: tokenCore
    };
    
    await redis.setex(
      `otd:${otdToken}`,
      60, // TTL بالثواني
      JSON.stringify(tokenData)
    );
    
    // 7. إنشاء QR Code Data
    const qrCodeData = `halab-discounts://redeem/${otdToken}`;
    
    // 8. الاستجابة
    return res.status(200).json({
      success: true,
      data: {
        otdToken,
        qrCodeData,
        generatedAt: new Date(timestamp * 1000).toISOString(),
        expiresAt: new Date((timestamp + 60) * 1000).toISOString(),
        merchantInfo: {
          name: merchantData.businessName,
          branch: branch.name,
          discount: merchantData.discount.percentage
        }
      }
    });
    
  } catch (error) {
    console.error('Error generating OTD:', error);
    return res.status(500).json({
      success: false,
      error: 'INTERNAL_SERVER_ERROR'
    });
  }
};
```

#### Client-Side (Flutter App)

```dart
import 'package:qr_flutter/qr_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

class OTDService {
  final String baseUrl = 'https://api.halab-discounts.com';
  
  /// طلب توليد OTD من السيرفر
  Future<OTDResponse> generateOTD({
    required String merchantId,
    required String branchId,
  }) async {
    final token = await getAuthToken(); // من Firebase Auth
    
    final response = await http.post(
      Uri.parse('$baseUrl/api/v1/discounts/generate-otd'),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'merchantId': merchantId,
        'branchId': branchId,
      }),
    );
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return OTDResponse.fromJson(data['data']);
    } else {
      throw Exception('Failed to generate OTD');
    }
  }
}

/// نموذج البيانات المُرجعة
class OTDResponse {
  final String otdToken;
  final String qrCodeData;
  final DateTime generatedAt;
  final DateTime expiresAt;
  final MerchantInfo merchantInfo;
  
  OTDResponse({
    required this.otdToken,
    required this.qrCodeData,
    required this.generatedAt,
    required this.expiresAt,
    required this.merchantInfo,
  });
  
  factory OTDResponse.fromJson(Map<String, dynamic> json) {
    return OTDResponse(
      otdToken: json['otdToken'],
      qrCodeData: json['qrCodeData'],
      generatedAt: DateTime.parse(json['generatedAt']),
      expiresAt: DateTime.parse(json['expiresAt']),
      merchantInfo: MerchantInfo.fromJson(json['merchantInfo']),
    );
  }
  
  /// مدة الصلاحية المتبقية
  Duration get remainingTime => expiresAt.difference(DateTime.now());
  
  /// هل ما زال صالحاً؟
  bool get isValid => DateTime.now().isBefore(expiresAt);
}

/// شاشة عرض QR Code مع مؤقت
class OTDDisplayScreen extends StatefulWidget {
  final OTDResponse otdData;
  
  const OTDDisplayScreen({required this.otdData});
  
  @override
  _OTDDisplayScreenState createState() => _OTDDisplayScreenState();
}

class _OTDDisplayScreenState extends State<OTDDisplayScreen> {
  late Timer _timer;
  Duration _remaining = Duration.zero;
  
  @override
  void initState() {
    super.initState();
    _remaining = widget.otdData.remainingTime;
    
    // مؤقت يُحدّث كل ثانية
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        _remaining = widget.otdData.remainingTime;
        
        // إذا انتهت الصلاحية، أغلق الشاشة
        if (_remaining.isNegative || _remaining.inSeconds == 0) {
          timer.cancel();
          Navigator.pop(context);
          showExpiredDialog();
        }
      });
    });
  }
  
  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('استخدم خصمك الآن'),
        backgroundColor: Colors.indigo,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // اسم التاجر
            Text(
              widget.otdData.merchantInfo.name,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            
            // نسبة الخصم
            Container(
              padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                'خصم ${widget.otdData.merchantInfo.discount}%',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            
            SizedBox(height: 40),
            
            // QR Code
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: QrImageView(
                data: widget.otdData.qrCodeData,
                version: QrVersions.auto,
                size: 250.0,
                errorCorrectionLevel: QrErrorCorrectLevel.H,
              ),
            ),
            
            SizedBox(height: 40),
            
            // المؤقت
            Container(
              padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
              decoration: BoxDecoration(
                color: _remaining.inSeconds <= 10 
                    ? Colors.red.shade100 
                    : Colors.blue.shade100,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                children: [
                  Text(
                    'الوقت المتبقي',
                    style: TextStyle(fontSize: 16, color: Colors.black54),
                  ),
                  SizedBox(height: 8),
                  Text(
                    '${_remaining.inSeconds} ثانية',
                    style: TextStyle(
                      fontSize: 48,
                      fontWeight: FontWeight.bold,
                      color: _remaining.inSeconds <= 10 
                          ? Colors.red 
                          : Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
            
            SizedBox(height: 30),
            
            // تحذير
            if (_remaining.inSeconds <= 10)
              Text(
                '⚠️ أسرع! الكود على وشك الانتهاء',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                ),
              ),
            
            SizedBox(height: 20),
            
            // رسالة توضيحية
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                'اطلب من أمين الصندوق مسح هذا الكود',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.black54),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  void showExpiredDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text('انتهت صلاحية الكود'),
        content: Text('يمكنك توليد كود جديد للاستفادة من الخصم.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('حسناً'),
          ),
        ],
      ),
    );
  }
}
```

---

## 3. التحقق من OTD (Merchant-Side)

### 3.1 Cloud Function للتحقق

```javascript
/**
 * Cloud Function: verifyOTD
 * يتم استدعاؤها من تطبيق التاجر عند مسح QR Code
 */

exports.verifyOTD = async (req, res) => {
  try {
    // 1. التحقق من أن المستدعي هو تاجر
    const merchantUserId = req.auth.uid;
    const merchantDoc = await admin.firestore()
      .collection('merchants')
      .where('ownerId', '==', merchantUserId)
      .limit(1)
      .get();
    
    if (merchantDoc.empty) {
      return res.status(403).json({
        success: false,
        error: 'UNAUTHORIZED_MERCHANT'
      });
    }
    
    const merchantId = merchantDoc.docs[0].id;
    const merchantData = merchantDoc.docs[0].data();
    
    // 2. استخراج البيانات من الطلب
    const { otdToken, branchId, originalAmount, location } = req.body;
    
    if (!otdToken || !branchId) {
      return res.status(400).json({
        success: false,
        error: 'MISSING_REQUIRED_FIELDS'
      });
    }
    
    // 3. جلب بيانات الـ Token من Redis
    const redis = getRedisClient();
    const tokenDataStr = await redis.get(`otd:${otdToken}`);
    
    if (!tokenDataStr) {
      // الكود غير موجود أو انتهت صلاحيته
      return res.status(400).json({
        success: false,
        error: 'OTD_EXPIRED_OR_INVALID',
        message: 'هذا الكود انتهت صلاحيته أو غير صحيح'
      });
    }
    
    const tokenData = JSON.parse(tokenDataStr);
    
    // 4. التحقق من أن الكود لهذا التاجر والفرع
    if (tokenData.merchantId !== merchantId) {
      return res.status(403).json({
        success: false,
        error: 'OTD_WRONG_MERCHANT',
        message: 'هذا الكود ليس لمحلك'
      });
    }
    
    if (tokenData.branchId !== branchId) {
      return res.status(403).json({
        success: false,
        error: 'OTD_WRONG_BRANCH',
        message: 'هذا الكود ليس لهذا الفرع'
      });
    }
    
    // 5. التحقق من عدم استخدام الكود مسبقاً (Double-Check في Firestore)
    const existingTxn = await admin.firestore()
      .collection('transactions')
      .where('otdToken', '==', otdToken)
      .where('status', '==', 'scanned')
      .limit(1)
      .get();
    
    if (!existingTxn.empty) {
      return res.status(400).json({
        success: false,
        error: 'OTD_ALREADY_USED',
        message: 'هذا الكود تم استخدامه مسبقاً'
      });
    }
    
    // 6. التحقق من Geofencing (اختياري لكن موصى به)
    if (location && merchantData.branches) {
      const branch = merchantData.branches.find(b => b.branchId === branchId);
      if (branch && branch.location) {
        const distance = calculateDistance(
          location.latitude,
          location.longitude,
          branch.location.latitude,
          branch.location.longitude
        );
        
        // السماح بـ 500 متر كحد أقصى
        if (distance > 500) {
          // تحذير لكن لا نمنع (قد يكون GPS غير دقيق)
          console.warn(`Geofence warning: distance ${distance}m for txn`);
        }
      }
    }
    
    // 7. جلب بيانات المشترك
    const userDoc = await admin.firestore()
      .collection('users')
      .doc(tokenData.userId)
      .get();
    
    if (!userDoc.exists) {
      return res.status(404).json({
        success: false,
        error: 'USER_NOT_FOUND'
      });
    }
    
    const userData = userDoc.data();
    
    // التحقق النهائي من الاشتراك
    if (userData.accountType !== 'subscriber' || 
        userData.subscription.status !== 'active') {
      return res.status(403).json({
        success: false,
        error: 'USER_SUBSCRIPTION_INVALID',
        message: 'اشتراك المستخدم غير نشط'
      });
    }
    
    // 8. حساب الخصم
    const discountPercentage = tokenData.discountPercentage;
    let discountAmount = null;
    let finalAmount = null;
    
    if (originalAmount) {
      discountAmount = Math.round(originalAmount * (discountPercentage / 100));
      finalAmount = originalAmount - discountAmount;
    }
    
    // 9. حذف الـ Token من Redis (استخدام لمرة واحدة)
    await redis.del(`otd:${otdToken}`);
    
    // 10. حفظ المعاملة في Firestore
    const transactionRef = admin.firestore().collection('transactions').doc();
    const transactionData = {
      transactionId: transactionRef.id,
      userId: tokenData.userId,
      merchantId,
      branchId,
      otdToken,
      generatedAt: admin.firestore.Timestamp.fromMillis(tokenData.generatedAt * 1000),
      scannedAt: admin.firestore.Timestamp.now(),
      expiresAt: admin.firestore.Timestamp.fromMillis(tokenData.expiresAt * 1000),
      discountPercentage,
      originalAmount,
      discountAmount,
      finalAmount,
      location: location ? new admin.firestore.GeoPoint(location.latitude, location.longitude) : null,
      status: 'scanned',
      verification: {
        merchantUserId,
        deviceId: req.body.deviceId || null,
        ipAddress: req.ip
      },
      fraudFlags: {
        isDuplicate: false,
        isOutsideGeofence: false,
        isExpired: false,
        suspiciousActivity: null
      },
      createdAt: admin.firestore.Timestamp.now()
    };
    
    await transactionRef.set(transactionData);
    
    // 11. تحديث إحصائيات المستخدم
    await admin.firestore().collection('users').doc(tokenData.userId).update({
      'stats.totalDiscountsUsed': admin.firestore.FieldValue.increment(1),
      'stats.totalSavings': admin.firestore.FieldValue.increment(discountAmount || 0),
      'stats.lastUsedAt': admin.firestore.Timestamp.now()
    });
    
    // 12. تحديث إحصائيات التاجر
    await admin.firestore().collection('merchants').doc(merchantId).update({
      'stats.totalScans': admin.firestore.FieldValue.increment(1),
      'stats.totalRevenue': admin.firestore.FieldValue.increment(finalAmount || 0)
    });
    
    // 13. الاستجابة بالنجاح
    return res.status(200).json({
      success: true,
      data: {
        isValid: true,
        customerInfo: {
          membershipId: userData.subscription.membershipId,
          fullName: userData.fullName,
          profilePhoto: userData.profilePhoto,
          memberSince: userData.subscription.startDate.toDate().toISOString().split('T')[0]
        },
        discount: {
          percentage: discountPercentage,
          discountAmount,
          finalAmount
        },
        transactionId: transactionRef.id,
        scannedAt: new Date().toISOString()
      }
    });
    
  } catch (error) {
    console.error('Error verifying OTD:', error);
    return res.status(500).json({
      success: false,
      error: 'INTERNAL_SERVER_ERROR'
    });
  }
};

/**
 * دالة مساعدة لحساب المسافة بين نقطتين (Haversine Formula)
 */
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3; // نصف قطر الأرض بالمتر
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;
  
  const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ/2) * Math.sin(Δλ/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  
  return R * c; // المسافة بالمتر
}
```

### 3.2 Merchant App Scanner (Flutter)

```dart
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MerchantScannerScreen extends StatefulWidget {
  final String branchId;
  
  const MerchantScannerScreen({required this.branchId});
  
  @override
  _MerchantScannerScreenState createState() => _MerchantScannerScreenState();
}

class _MerchantScannerScreenState extends State<MerchantScannerScreen> {
  MobileScannerController cameraController = MobileScannerController();
  bool isProcessing = false;
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('مسح كود الخصم'),
        actions: [
          IconButton(
            icon: Icon(Icons.flash_on),
            onPressed: () => cameraController.toggleTorch(),
          ),
          IconButton(
            icon: Icon(Icons.flip_camera_ios),
            onPressed: () => cameraController.switchCamera(),
          ),
        ],
      ),
      body: Stack(
        children: [
          // الكاميرا
          MobileScanner(
            controller: cameraController,
            onDetect: (capture) {
              if (!isProcessing) {
                final List<Barcode> barcodes = capture.barcodes;
                if (barcodes.isNotEmpty) {
                  final String? code = barcodes.first.rawValue;
                  if (code != null && code.startsWith('halab-discounts://redeem/')) {
                    handleScannedCode(code);
                  }
                }
              }
            },
          ),
          
          // إطار التوجيه
          Center(
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white, width: 3),
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
          
          // التعليمات
          Positioned(
            bottom: 50,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.all(16),
              margin: EdgeInsets.symmetric(horizontal: 40),
              decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Text(
                'وجّه الكاميرا نحو QR Code',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),
            ),
          ),
          
          // مؤشر المعالجة
          if (isProcessing)
            Container(
              color: Colors.black54,
              child: Center(
                child: CircularProgressIndicator(),
              ),
            ),
        ],
      ),
    );
  }
  
  Future<void> handleScannedCode(String scannedCode) async {
    setState(() => isProcessing = true);
    
    try {
      // استخراج OTD Token من الرابط
      final uri = Uri.parse(scannedCode);
      final otdToken = uri.pathSegments.last;
      
      // الحصول على الموقع الحالي
      final position = await getCurrentLocation();
      
      // إرسال الطلب للسيرفر
      final response = await verifyOTD(
        otdToken: otdToken,
        branchId: widget.branchId,
        location: position,
      );
      
      // إيقاف الكاميرا
      cameraController.stop();
      
      // عرض النتيجة
      if (response.success) {
        showSuccessScreen(response);
      } else {
        showErrorDialog(response.error);
      }
      
    } catch (e) {
      showErrorDialog('حدث خطأ أثناء التحقق من الكود');
    } finally {
      setState(() => isProcessing = false);
    }
  }
  
  Future<VerificationResponse> verifyOTD({
    required String otdToken,
    required String branchId,
    Position? location,
  }) async {
    final token = await getMerchantAuthToken();
    
    final response = await http.post(
      Uri.parse('https://api.halab-discounts.com/api/v1/merchant/verify-otd'),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'otdToken': otdToken,
        'branchId': branchId,
        'location': location != null 
          ? {'latitude': position.latitude, 'longitude': position.longitude}
          : null,
      }),
    );
    
    final data = jsonDecode(response.body);
    return VerificationResponse.fromJson(data);
  }
  
  void showSuccessScreen(VerificationResponse response) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => VerificationSuccessScreen(data: response.data),
      ),
    );
  }
  
  void showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('فشل التحقق'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              cameraController.start(); // إعادة تشغيل الكاميرا
            },
            child: Text('حاول مرة أخرى'),
          ),
        ],
      ),
    );
  }
  
  @override
  void dispose() {
    cameraController.dispose();
    super.dispose();
  }
}

/// شاشة نجاح التحقق
class VerificationSuccessScreen extends StatelessWidget {
  final VerificationData data;
  
  const VerificationSuccessScreen({required this.data});
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // أيقونة النجاح
                Icon(
                  Icons.check_circle,
                  color: Colors.green,
                  size: 120,
                ),
                
                SizedBox(height: 30),
                
                // العنوان
                Text(
                  'تم التحقق بنجاح!',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.green.shade800,
                  ),
                ),
                
                SizedBox(height: 40),
                
                // معلومات المشترك
                Container(
                  padding: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 10,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      // الصورة الشخصية
                      if (data.customerInfo.profilePhoto != null)
                        CircleAvatar(
                          radius: 50,
                          backgroundImage: NetworkImage(data.customerInfo.profilePhoto!),
                        ),
                      
                      SizedBox(height: 16),
                      
                      // الاسم
                      Text(
                        data.customerInfo.fullName,
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      
                      SizedBox(height: 8),
                      
                      // رقم العضوية
                      Text(
                        'عضو منذ ${data.customerInfo.memberSince}',
                        style: TextStyle(color: Colors.grey),
                      ),
                      
                      Divider(height: 30),
                      
                      // الخصم
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'الخصم: ',
                            style: TextStyle(fontSize: 20),
                          ),
                          Text(
                            '${data.discount.percentage}%',
                            style: TextStyle(
                              fontSize: 36,
                              fontWeight: FontWeight.bold,
                              color: Colors.green,
                            ),
                          ),
                        ],
                      ),
                      
                      if (data.discount.discountAmount != null) ...[
                        SizedBox(height: 20),
                        Text(
                          'قيمة الخصم: ${data.discount.discountAmount} ل.س',
                          style: TextStyle(fontSize: 18),
                        ),
                        Text(
                          'المبلغ النهائي: ${data.discount.finalAmount} ل.س',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                
                SizedBox(height: 40),
                
                // زر العودة
                ElevatedButton(
                  onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: Text(
                    'إنهاء',
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
```

---

## 4. إجراءات الأمان الإضافية

### 4.1 منع الهجمات الشائعة

**1. Replay Attack (إعادة استخدام الكود)**
- ✅ **الحل**: حذف Token من Redis فوراً بعد الاستخدام
- ✅ **التحقق المزدوج**: فحص Firestore للتأكد من عدم وجود معاملة سابقة

**2. Brute Force (تخمين الأكواد)**
- ✅ **الحل**: استخدام HMAC-SHA256 يجعل التخمين شبه مستحيل (2^256 احتمال)
- ✅ **Rate Limiting**: حد أقصى 5 محاولات مسح خاطئة في الدقيقة

**3. Man-in-the-Middle (اعتراض الاتصال)**
- ✅ **الحل**: HTTPS/TLS 1.3 إلزامي
- ✅ **Certificate Pinning** في التطبيق

**4. Screenshot & Screen Recording**
- ✅ **الحل**: 
  - الكود صالح لـ 60 ثانية فقط
  - يُحذف فوراً بعد الاستخدام
  - حتى لو تم تصويره، سيكون منتهي الصلاحية

### 4.2 Fraud Detection (كشف الاحتيال)

```javascript
/**
 * Cloud Function تعمل بشكل دوري (Scheduled)
 * للكشف عن الأنماط المشبوهة
 */

exports.detectFraud = functions.pubsub.schedule('every 1 hours').onRun(async (context) => {
  const now = admin.firestore.Timestamp.now();
  const oneHourAgo = new admin.firestore.Timestamp(now.seconds - 3600, now.nanoseconds);
  
  // 1. البحث عن مستخدمين استخدموا الخصم أكثر من 10 مرات في ساعة واحدة
  const suspiciousUsers = await admin.firestore()
    .collection('transactions')
    .where('scannedAt', '>', oneHourAgo)
    .get();
  
  const userCounts = {};
  suspiciousUsers.forEach(doc => {
    const userId = doc.data().userId;
    userCounts[userId] = (userCounts[userId] || 0) + 1;
  });
  
  for (const [userId, count] of Object.entries(userCounts)) {
    if (count > 10) {
      console.warn(`Suspicious activity: User ${userId} used discount ${count} times in 1 hour`);
      
      // إرسال تنبيه للإدارة
      await sendAdminAlert({
        type: 'SUSPICIOUS_USAGE',
        userId,
        count,
        timestamp: now
      });
    }
  }
  
  // 2. البحث عن تجار قاموا بمسح نفس الكود أكثر من مرة
  const duplicateScans = await admin.firestore()
    .collection('transactions')
    .where('status', '==', 'scanned')
    .get();
  
  const tokenCounts = {};
  duplicateScans.forEach(doc => {
    const token = doc.data().otdToken;
    tokenCounts[token] = (tokenCounts[token] || 0) + 1;
  });
  
  for (const [token, count] of Object.entries(tokenCounts)) {
    if (count > 1) {
      console.error(`FRAUD DETECTED: Token ${token} was scanned ${count} times`);
      
      // تعليق الحسابات المعنية
      // ...
    }
  }
});
```

---

تم إكمال وثيقة آلية OTD بالتفصيل. التالي: حل معضلة البيضة والدجاجة...
