#!/usr/bin/env bash
# ============================================================
# رفع مشروع حلب خصومات إلى GitHub بأمر واحد
# الاستخدام:
#   GITHUB_USER=اسمك GITHUB_TOKEN=ghp_xxx ./push-to-github.sh
# التوكن يحتاج صلاحية: repo (+ workflow اختياري)
# ============================================================
set -euo pipefail

REPO_NAME="${REPO_NAME:-haleb-discounts}"
VISIBILITY="${VISIBILITY:-private}"   # private | public
DESCRIPTION="حلب خصومات — نظام العضوية والصلاحيات والأدوار (RBAC)"

: "${GITHUB_USER:?عيّن GITHUB_USER=اسم_حسابك}"
: "${GITHUB_TOKEN:?عيّن GITHUB_TOKEN=التوكن_الخاص_بك}"

if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "✗ شغّل السكربت من داخل مجلد المشروع (حيث يوجد .git)"
  exit 1
fi

echo "→ إنشاء المستودع $GITHUB_USER/$REPO_NAME ($VISIBILITY)"
RESPONSE=$(curl -s -w '\n%{http_code}' -X POST https://api.github.com/user/repos \
  -H "Authorization: Bearer $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github+json" \
  -d "{\"name\":\"$REPO_NAME\",\"private\":$([ "$VISIBILITY" = "private" ] && echo true || echo false),\"description\":\"$DESCRIPTION\",\"has_issues\":true,\"has_wiki\":false}")

BODY=$(echo "$RESPONSE" | head -n -1)
CODE=$(echo "$RESPONSE" | tail -n1)

if [ "$CODE" = "201" ]; then
  echo "✓ تم إنشاء المستودع"
elif echo "$BODY" | grep -q 'name already exists'; then
  echo "ℹ المستودع موجود مسبقاً — سيتم الدفع إليه"
else
  echo "⚠ استجابة GitHub ($CODE):"
  echo "$BODY" | head -20
fi

git branch -M main 2>/dev/null || true

if git remote get-url origin >/dev/null 2>&1; then
  git remote set-url origin "https://github.com/$GITHUB_USER/$REPO_NAME.git"
else
  git remote add origin "https://github.com/$GITHUB_USER/$REPO_NAME.git"
fi

echo "→ دفع الفرع main"
git -c credential.helper= \
    -c http.extraheader="Authorization: Basic $(printf '%s:%s' "$GITHUB_USER" "$GITHUB_TOKEN" | base64 -w0)" \
    push -u origin main

echo "✓ تم الرفع: https://github.com/$GITHUB_USER/$REPO_NAME"
echo "ℹ أزل أي توكن محفوظ: git remote set-url origin https://github.com/$GITHUB_USER/$REPO_NAME.git"
