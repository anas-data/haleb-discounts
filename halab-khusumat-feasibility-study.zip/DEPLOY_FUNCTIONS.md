# ⚙️ نشر Cloud Functions — حلب خصومات

> نشر `verifyOtdCode`, `recordTransaction`, `checkExpiredSubscriptions`, `setUserRole` على بيئة الإنتاج.

---

## 1. المتطلبات

```bash
node -v        # 20.x
npm i -g firebase-tools
firebase login
firebase use haleb-discounts
```

المشروع يحتوي:

```
functions/
├── package.json
├── tsconfig.json
└── src/index.ts
```

الوظائف تستخدم: `firebase-admin`, `firebase-functions`, `speakeasy` (TOTP).

---

## 2. تثبيت وبناء محلي

```bash
cd functions
npm ci
npm run build          # ينتج lib/index.js
```

للتشغيل ضد المحاكيات:

```bash
firebase emulators:start --only functions,firestore,auth
```

> في بيئة المحاكي، نقاط النهاية تكون على:
> `http://localhost:5001/haleb-discounts/europe-west1/verifyOtdCode`

---

## 3. إعداد المتغيرات والأسرار

```bash
# ضبط مشروع Firebase
firebase use --add

# المتغيرات غير السرية في functions/.env
cat > functions/.env <<'ENV'
OTD_WINDOW_SECONDS=60
ENV=production
ENV

# مفاتيح حساسة (اختياري: بوابة الدفع)
firebase functions:secrets:set PAYMENT_GATEWAY_KEY
```

منح صلاحيات تشغيل الوظائف:

```bash
gcloud projects add-iam-policy-binding haleb-discounts \
  --member="serviceAccount:haleb-discounts@appspot.gserviceaccount.com" \
  --role="roles/datastore.user"
```

---

## 4. النشر

```bash
cd functions && npm run build
cd ..

# نشر كل الوظائف
firebase deploy --only functions

# أو وظيفة محددة
firebase deploy --only functions:verifyOtdCode,functions:recordTransaction

# نشر القواعد والوظائف معاً
firebase deploy --only firestore:rules,functions
```

### النشر التدريجي (Canary)

```bash
firebase deploy --only functions --force   # عند الحاجة لتحديث triggers
```

> `checkExpiredSubscriptions` وظيفة مجدولة:
> `pubsub.schedule('5 0 * * *').timeZone('Asia/Damascus')`
> تعمل يومياً 00:05 وتُوقف الاشتراكات المنتهية وتكتب سجل تدقيق.

---

## 5. الأمان والتحقق في الخادم

| الوظيفة | التحقق |
|---|---|
| `verifyOtdCode` | المصادقة + ملكية التاجر + اشتراك نشط + TOTP + منع إعادة الاستخدام داخل نافذة 60 ثانية |
| `recordTransaction` | إعادة التحقق من TOTP + حساب الخصم على الخادم + Transaction ذري |
| `checkExpiredSubscriptions` | جدولة يومية + سجل تدقيق |
| `setUserRole` | مدير فقط + تحديث Custom Claims + سجل تدقيق |

**مهم:** نسبة الخصم تُقرأ من مستند التاجر على الخادم فقط، ولا يعتمد الخادم على قيمة قادمة من العميل.

---

## 6. مراقبة وسجلات

```bash
firebase functions:log
firebase functions:log --only verifyOtdCode
```

من Google Cloud Console:
- Cloud Functions → Metrics (Invocations / Errors / Latency)
- Logs Explorer: `resource.labels.function_name="verifyOtdCode"`
- إنشاء Alerts على:
  - معدل الأخطاء `> 5%` لمدة 5 دقائق.
  - زمن التنفيذ `p95 > 2s`.
  - فشل تحقق OTD المتكرر (مؤشر تلاعب محتمل).

---

## 7. الاختبار بعد النشر

```bash
# اختبار وظيفة callable مع توكن Auth
curl -X POST \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <ID_TOKEN>" \
  https://europe-west1-haleb-discounts.cloudfunctions.net/verifyOtdCode \
  -d '{"data":{"code":"123456","merchantId":"m1","branchId":"m1-b1","userId":"u-sara"}}'
```

الاستجابات المتوقعة:

| الحالة | HTTP/Code |
|---|---|
| كود صالح وعضوية نشطة | `200` + `valid:true` |
| كود منتهي/خاطئ | `invalid-argument` |
| كود مستخدم سابقاً في نفس الدقيقة | `already-exists` |
| حساب غير مشترك | `permission-denied` |
| مستدعٍ ليس التاجر | `permission-denied` |

---

## 8. التراجع (Rollback)

```bash
# سجل الإصدارات
gcloud functions list

# عرض إصدارات دالة
gcloud functions versions list verifyOtdCode --region=europe-west1

# الرجوع لإصدار سابق عبر البحث عن revision في Firebase Console
firebase functions:delete verifyOtdCode --region europe-west1
firebase deploy --only functions:verifyOtdCode
```

> احتفظ بملف `firestore.rules` و`functions/src/index.ts` ضمن Git للرجوع السريع.

---

## 9. قائمة فحص الإنتاج

- [ ] جميع الوظائف في منطقة `europe-west1` (قريبة من سوريا).
- [ ] `npm run build` ينجح دون أخطاء TypeScript.
- [ ] `.env` غير مضمّن في Git.
- [ ] `speakeasy` و`firebase-admin` مثبتان في package.json.
- [ ] قواعد `otd_uses` تمنع إعادة الاستخدام.
- [ ] جدولة الاشتراكات تعمل في المنطقة الزمنية الصحيحة.
- [ ] Firebase App Check مفعّل على الوظائف القابلة للنداء.
- [ ] تنبيهات الأخطاء مفعّلة في Cloud Monitoring.
