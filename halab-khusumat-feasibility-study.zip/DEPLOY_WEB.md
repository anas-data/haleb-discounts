# 🌐 نشر لوحة تحكم حلب خصومات (Flutter Web / PWA)

> **الهدف:** نشر لوحة التحكم (`web_admin/`) على `haleb-admin.web.app` أو سيرفر خاص.

---

## 1. البناء الإنتاجي

```bash
cd web_admin
flutter pub get
flutter build web --release \
  --dart-define=ENV=production \
  --dart-define=FIREBASE_PROJECT_ID=haleb-discounts
```

المخرجات في `web_admin/build/web/` وتشمل:

```
index.html
main.dart.js
flutter_service_worker.js
assets/
canvaskit/
manifest.json
```

### ضبط `base href`
- النشر على الجذر (`https://admin.halab-discounts.com/`) → أبقِ `<base href="/">`.
- النشر داخل مجلد فرعي (`/admin/`) → عدّل في `web_admin/web/index.html`:

```html
<base href="/admin/">
```

---

## 2. الخيار المفضّل: Firebase Hosting

### أ) الإعداد لمرة واحدة

```bash
npm i -g firebase-tools
firebase login
firebase init hosting
# ? Use an existing project → haleb-discounts
# ? Public directory → web_admin/build/web
# ? Configure as a single-page app → Yes
# ? Set up automatic builds with GitHub → No (لدينا CI)
```

ثم أضف هدف الموقع:

```bash
firebase target:apply hosting admin haleb-admin
```

`firebase.json` يستخدم `target: admin` و`public: web_admin/build/web` مع `rewrites` إلى `index.html` (موجود في جذر المستودع).

### ب) النشر

```bash
cd web_admin && flutter build web --release
cd ..
firebase deploy --only hosting:admin
```

### ج) النطاق المخصص

```bash
firebase hosting:sites:list
# Firebase Console → Hosting → haleb-admin → Custom domain
# أضف admin.halab-discounts.com وسجّل TXT ثم A/AAAA كما يظهر.
```

الشهادة (SSL) تُصدر تلقائياً خلال دقائق.

---

## 3. الخيار البديل: سيرفر Apache

```bash
flutter build web --release
rsync -av --delete web_admin/build/web/ user@server:/var/www/html/haleb-admin/
```

`.htaccess` داخل مجلد الموقع:

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /haleb-admin/
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /haleb-admin/index.html [L]
</IfModule>

<IfModule mod_headers.c>
  <FilesMatch "\.(js|css|woff2|png|jpg|svg)$">
    Header set Cache-Control "public, max-age=31536000, immutable"
  </FilesMatch>
  Header set X-Content-Type-Options nosniff
  Header set X-Frame-Options SAMEORIGIN
</IfModule>
```

لتمكين ضغط النقل:

```apache
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/css application/javascript application/json image/svg+xml
</IfModule>
```

---

## 4. الخيار البديل: Nginx

```nginx
server {
  listen 80;
  server_name admin.halab-discounts.com;
  root /var/www/haleb-admin;
  index index.html;

  location / {
    try_files $uri $uri/ /index.html;
  }

  location ~* \.(js|css|woff2|png|jpg|svg)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
  }

  add_header X-Content-Type-Options nosniff always;
  add_header X-Frame-Options SAMEORIGIN always;
  add_header Referrer-Policy strict-origin-when-cross-origin always;
}
```

ثم:

```bash
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d admin.halab-discounts.com
```

---

## 5. متغيرات البيئة في Flutter Web

مرّرها وقت البناء (لا تُضمّن أسراراً في الواجهة):

```bash
flutter build web --release \
  --dart-define=ENV=production \
  --dart-define=FIREBASE_API_KEY=... \
  --dart-define=FIREBASE_PROJECT_ID=haleb-discounts \
  --dart-define=FIREBASE_AUTH_DOMAIN=haleb-discounts.firebaseapp.com
```

> مفاتيح Firebase Web ليست أسراراً بحد ذاتها، لكن الحماية الحقيقية تأتي من:
> `firestore.rules` + Firebase App Check + قيود Authorized Domains.

---

## 6. قائمة فحص ما بعد النشر

- [ ] تسجيل الدخول بحساب `admin` يعمل ويوجّه إلى لوحة التحكم.
- [ ] محاولة فتح `/admin` بحساب مشترك تُرفض (RoleGuard).
- [ ] إضافة/إيقاف شريك ينعكس في تطبيق الجوال.
- [ ] تصدير تقرير CSV يعمل بالعربية (BOM مضاف).
- [ ] HTTPS مفعّل ولا توجد Mixed Content في Console.
- [ ] `rewrites` تعمل: تحديث الصفحة على `/merchants` لا يعطي 404.
- [ ] Authorized Domains في Firebase Auth تتضمن النطاق الإنتاجي.

---

## 7. استكشاف الأخطاء

| المشكلة | السبب | الحل |
|---|---|---|
| شاشة بيضاء | `base href` خاطئ أو مجلد فرعي | صحّح `base` وأعد البناء |
| 404 عند التحديث | لا يوجد rewrite | أضف إعداد Apache/Nginx/Firebase |
| `auth/unauthorized-domain` | النطاق غير مصرح | Firebase Console → Authentication → Settings |
| فشل تسجيل الدخول بحساب الأدمن | Custom Claim غير مضبوط | أعد تشغيل سكربت منح الأدوار |
