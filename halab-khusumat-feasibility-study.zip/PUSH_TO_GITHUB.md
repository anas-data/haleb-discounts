# 🚀 رفع مشروع حلب خصومات إلى GitHub

المستودع المحلي **مهيأ ومُلتزم بالكامل** (git init + commit). المتبقي هو إنشاء المستودع البعيد على حسابك ودفع الفرع.

---

## 1. الطريقة الأسرع: GitHub CLI

```bash
# تثبيت gh (أوبونتو/ديبيان)
sudo apt install gh          # أو: brew install gh

# المصادقة عبر المتصفح
gh auth login

# إنشاء المستودع ورفع المشروع
gh repo create haleb-discounts --private --source=. --remote=origin --push
```

> استبدل `--private` بـ `--public` إن أردت مستودعاً عاماً.

---

## 2. الطريقة القياسية: Personal Access Token (HTTPS)

1. أنشئ توكن من: **GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)**
2. الصلاحيات المطلوبة: `repo` (واختيارياً `workflow` لتشغيل GitHub Actions).
3. أنشئ المستودع الفارغ من الواجهة باسم `haleb-discounts` **بدون README/.gitignore**.
4. نفّذ:

```bash
cd /home/user/sandbox

git remote add origin https://github.com/USERNAME/haleb-discounts.git
git branch -M main
git push -u origin main
```

عند طلب اسم المستخدم وكلمة المرور:
- Username: اسم حسابك على GitHub
- Password: **التوكن** (وليس كلمة المرور)

### إنشاء المستودع عبر API مباشرة

```bash
TOKEN=ghp_xxxxxxxxxxxxxxxxx
USER=USERNAME

curl -s -X POST https://api.github.com/user/repos \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  -d '{"name":"haleb-discounts","private":true,"description":"حلب خصومات — نظام العضوية والصلاحيات"}' \
  | grep -E '"html_url"|"message"'

git remote add origin https://$USER:$TOKEN@github.com/$USER/haleb-discounts.git
git branch -M main
git push -u origin main
```

> بعد الدفع، أزل التوكن من الـ remote لتجنّب تخزينه:
> `git remote set-url origin https://github.com/USERNAME/haleb-discounts.git`

---

## 3. الطريقة الآمنة: SSH

```bash
ssh-keygen -t ed25519 -C "your-email@example.com"
cat ~/.ssh/id_ed25519.pub
```

أضف المفتاح في **GitHub → Settings → SSH and GPG keys → New SSH key**، ثم:

```bash
git remote add origin git@github.com:USERNAME/haleb-discounts.git
git branch -M main
git push -u origin main
```

---

## 4. رفع توكن في CI/CD للنشر التلقائي

المشروع يتضمن `.github/workflows/deploy.yml`. أضف في **Settings → Secrets and variables → Actions**:

| Secret | القيمة |
|---|---|
| `FIREBASE_SERVICE_ACCOUNT` | محتوى JSON لمفتاح خدمة Firebase |
| `FIREBASE_PROJECT_ID` | `haleb-discounts` |
| `PRODUCTION_URL` | رابط لوحة التحكم بعد النشر |

> لا تُضف Firebase token إلى الكود أو إلى `.env` المرفوع. ملف `.gitignore` يمنع رفع `google-services.json`, `GoogleService-Info.plist`, `serviceAccount*.json`, `.env` وغيرها.

---

## 5. التحقق بعد الرفع

```bash
git remote -v
git log --oneline -1
git ls-remote --heads origin
```

ثم افتح `https://github.com/USERNAME/haleb-discounts` وتأكد من ظهور:
- `src/` والموقع التفاعلي
- `haleb_discounts/lib/` ومشروع Flutter
- `functions/src/index.ts`
- `firestore.rules`, `firebase.json`
- `.github/workflows/deploy.yml`
- ملفات التوثيق (`README.md`, `QA_AUTH_RBAC_REPORT.md`, `DEPLOY_WEB.md`, `DEPLOY_FUNCTIONS.md`)

---

## 6. ملاحظات

- `node_modules/` (140MB) و`dist/` و`build/` **مستبعدة** من المستودع لتبقى خفيفة.
- إعادة البناء: `npm install && npm run build`.
- لرفع وسم إصدار: `git tag -a v2.0.0 -m "حلب خصومات v2.0" && git push origin v2.0.0`.
- لحماية الفرع الرئيسي: **Settings → Branches → Add branch protection rule → main** مع إلزام PRs وفحوص CI.
