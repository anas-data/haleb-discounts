// ═══════════════════════════════════════════════════════════════════
// مكتبة الأكواد الأولية - مشروع "حلب خصومات"
// Flutter/Dart Starter Pack
// ═══════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════
// 1. الصفحة الرئيسية المزدوجة (Free vs Subscriber Mode)
// ═══════════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

/// Model لبيانات التاجر
class Merchant {
  final String merchantId;
  final String businessName;
  final String logo;
  final String category;
  final double rating;
  final int totalReviews;
  final DiscountInfo? discount; // null في الوضع المجاني
  final List<Branch> branches;
  
  Merchant({
    required this.merchantId,
    required this.businessName,
    required this.logo,
    required this.category,
    required this.rating,
    required this.totalReviews,
    this.discount,
    required this.branches,
  });
  
  factory Merchant.fromFirestore(DocumentSnapshot doc, bool isSubscriber) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    
    return Merchant(
      merchantId: doc.id,
      businessName: data['businessName'],
      logo: data['logo'],
      category: data['category'],
      rating: (data['stats']['rating'] as num).toDouble(),
      totalReviews: data['stats']['totalReviews'] as int,
      // الخصم يظهر فقط للمشتركين
      discount: isSubscriber 
        ? DiscountInfo.fromMap(data['discount'])
        : null,
      branches: (data['branches'] as List)
        .map((b) => Branch.fromMap(b))
        .toList(),
    );
  }
}

class DiscountInfo {
  final int percentage;
  final String description;
  final int? minPurchase;
  
  DiscountInfo({
    required this.percentage,
    required this.description,
    this.minPurchase,
  });
  
  factory DiscountInfo.fromMap(Map<String, dynamic> map) {
    return DiscountInfo(
      percentage: map['percentage'],
      description: map['description'],
      minPurchase: map['minPurchase'],
    );
  }
}

class Branch {
  final String branchId;
  final String name;
  final String address;
  final GeoPoint location;
  
  Branch({
    required this.branchId,
    required this.name,
    required this.address,
    required this.location,
  });
  
  factory Branch.fromMap(Map<String, dynamic> map) {
    return Branch(
      branchId: map['branchId'],
      name: map['name'],
      address: map['address'],
      location: map['location'] as GeoPoint,
    );
  }
}

/// الصفحة الرئيسية
class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool isSubscriber = false;
  bool isLoading = true;
  List<Merchant> merchants = [];
  
  @override
  void initState() {
    super.initState();
    _checkUserStatus();
    _loadMerchants();
  }
  
  /// التحقق من حالة المستخدم
  Future<void> _checkUserStatus() async {
    User? user = FirebaseAuth.instance.currentUser;
    
    if (user != null) {
      DocumentSnapshot userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .get();
      
      if (userDoc.exists) {
        Map<String, dynamic> userData = userDoc.data() as Map<String, dynamic>;
        setState(() {
          isSubscriber = userData['accountType'] == 'subscriber' &&
                        userData['subscription']['status'] == 'active';
        });
      }
    }
  }
  
  /// جلب قائمة التجار
  Future<void> _loadMerchants() async {
    setState(() => isLoading = true);
    
    QuerySnapshot snapshot = await FirebaseFirestore.instance
      .collection('merchants')
      .where('subscription.status', isEqualTo: 'active')
      .orderBy('stats.rating', descending: true)
      .limit(20)
      .get();
    
    List<Merchant> loadedMerchants = snapshot.docs
      .map((doc) => Merchant.fromFirestore(doc, isSubscriber))
      .toList();
    
    setState(() {
      merchants = loadedMerchants;
      isLoading = false;
    });
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('حلب خصومات'),
        backgroundColor: Colors.indigo,
        actions: [
          IconButton(
            icon: Icon(Icons.notifications),
            onPressed: () {
              // فتح صفحة الإشعارات
            },
          ),
          IconButton(
            icon: Icon(Icons.person),
            onPressed: () {
              // فتح الملف الشخصي
            },
          ),
        ],
      ),
      
      body: RefreshIndicator(
        onRefresh: _loadMerchants,
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Banner للتشجيع على الاشتراك (يظهر للمستخدمين المجانيين)
              if (!isSubscriber)
                _buildSubscriptionBanner(),
              
              // رسالة ترحيب للمشتركين
              if (isSubscriber)
                _buildWelcomeCard(),
              
              SizedBox(height: 16),
              
              // شريط البحث
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'ابحث عن محل أو تصنيف...',
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    filled: true,
                    fillColor: Colors.grey[100],
                  ),
                  onChanged: (value) {
                    // تطبيق فلترة البحث
                  },
                ),
              ),
              
              SizedBox(height: 20),
              
              // التصنيفات
              _buildCategories(),
              
              SizedBox(height: 20),
              
              // قائمة التجار
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  isSubscriber ? 'التجار القريبون' : 'التجار المميزون',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              
              SizedBox(height: 12),
              
              isLoading
                ? Center(child: CircularProgressIndicator())
                : _buildMerchantsList(),
            ],
          ),
        ),
      ),
      
      bottomNavigationBar: _buildBottomNav(),
    );
  }
  
  /// Banner للاشتراك (للمستخدمين المجانيين)
  Widget _buildSubscriptionBanner() {
    return Container(
      margin: EdgeInsets.all(16),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.indigo, Colors.purple],
        ),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '🎯 اشترك الآن واحصل على:',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          _buildBenefitRow('✓ خصومات 15-30% في 20+ محل'),
          _buildBenefitRow('✓ هدية ترحيبية مجانية'),
          _buildBenefitRow('✓ سعر خاص: \$10 فقط (بدلاً من \$20)'),
          SizedBox(height: 12),
          ElevatedButton(
            onPressed: () {
              Navigator.pushNamed(context, '/subscription');
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: Colors.indigo,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25),
              ),
              padding: EdgeInsets.symmetric(horizontal: 40, vertical: 12),
            ),
            child: Text(
              'اشترك الآن →',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildBenefitRow(String text) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 2),
      child: Text(
        text,
        style: TextStyle(color: Colors.white, fontSize: 14),
      ),
    );
  }
  
  /// بطاقة ترحيب للمشتركين
  Widget _buildWelcomeCard() {
    return Container(
      margin: EdgeInsets.all(16),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.green[50],
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.green[200]!),
      ),
      child: Row(
        children: [
          Icon(Icons.verified, color: Colors.green, size: 40),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'مرحباً بك! 👋',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.green[800],
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'لديك 125 يوماً متبقية في اشتراكك',
                  style: TextStyle(fontSize: 14, color: Colors.green[700]),
                ),
                Text(
                  '💰 وفرت حتى الآن: 15,500 ل.س',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.green[900],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  /// شريط التصنيفات
  Widget _buildCategories() {
    final categories = [
      {'icon': '🍽️', 'label': 'مطاعم', 'value': 'restaurant'},
      {'icon': '☕', 'label': 'مقاهي', 'value': 'cafe'},
      {'icon': '👕', 'label': 'ألبسة', 'value': 'fashion'},
      {'icon': '💇', 'label': 'صالونات', 'value': 'beauty'},
      {'icon': '📚', 'label': 'مكتبات', 'value': 'books'},
      {'icon': '🎁', 'label': 'هدايا', 'value': 'gifts'},
    ];
    
    return Container(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 12),
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final category = categories[index];
          return GestureDetector(
            onTap: () {
              // فلترة حسب التصنيف
            },
            child: Container(
              width: 80,
              margin: EdgeInsets.symmetric(horizontal: 4),
              child: Column(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: Colors.indigo[50],
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Center(
                      child: Text(
                        category['icon']!,
                        style: TextStyle(fontSize: 30),
                      ),
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    category['label']!,
                    style: TextStyle(fontSize: 12),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
  
  /// قائمة التجار
  Widget _buildMerchantsList() {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      padding: EdgeInsets.symmetric(horizontal: 16),
      itemCount: merchants.length,
      itemBuilder: (context, index) {
        return _buildMerchantCard(merchants[index]);
      },
    );
  }
  
  /// بطاقة تاجر واحد
  Widget _buildMerchantCard(Merchant merchant) {
    return Card(
      margin: EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 2,
      child: InkWell(
        onTap: () {
          if (isSubscriber) {
            // فتح صفحة التاجر الكاملة
            Navigator.pushNamed(
              context,
              '/merchant-detail',
              arguments: merchant,
            );
          } else {
            // عرض رسالة للاشتراك
            _showSubscriptionDialog();
          }
        },
        borderRadius: BorderRadius.circular(15),
        child: Padding(
          padding: EdgeInsets.all(12),
          child: Row(
            children: [
              // الشعار
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.network(
                  merchant.logo,
                  width: 70,
                  height: 70,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      width: 70,
                      height: 70,
                      color: Colors.grey[300],
                      child: Icon(Icons.store, color: Colors.grey),
                    );
                  },
                ),
              ),
              
              SizedBox(width: 12),
              
              // المعلومات
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      merchant.businessName,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.star, color: Colors.amber, size: 16),
                        SizedBox(width: 4),
                        Text(
                          '${merchant.rating} (${merchant.totalReviews})',
                          style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                        ),
                      ],
                    ),
                    SizedBox(height: 4),
                    Text(
                      '📍 ${merchant.branches[0].address}',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              
              // الخصم أو القفل
              if (merchant.discount != null)
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.green,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    '🎁 ${merchant.discount!.percentage}%',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                )
              else
                Icon(Icons.lock, color: Colors.grey, size: 30),
            ],
          ),
        ),
      ),
    );
  }
  
  /// رسالة للاشتراك
  void _showSubscriptionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('🔐 سجّل لرؤية التفاصيل'),
        content: Text(
          'هذا الخصم متاح فقط للمشتركين.\n'
          'اشترك الآن واحصل على خصم 50% على الاشتراك السنوي!',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('لاحقاً'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/subscription');
            },
            child: Text('اشترك الآن'),
          ),
        ],
      ),
    );
  }
  
  /// Bottom Navigation
  Widget _buildBottomNav() {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      selectedItemColor: Colors.indigo,
      unselectedItemColor: Colors.grey,
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: 'الرئيسية'),
        BottomNavigationBarItem(icon: Icon(Icons.search), label: 'بحث'),
        BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'مفضلة'),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: 'حسابي'),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// 2. نظام توليد QR Code المتغير ديناميكياً (OTD System)
// ═══════════════════════════════════════════════════════════════════

import 'dart:async';
import 'dart:convert';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:http/http.dart' as http;

/// خدمة توليد OTD
class OTDService {
  static const String apiUrl = 'https://api.halab-discounts.com';
  
  /// طلب توليد OTD من السيرفر
  static Future<OTDToken> generateOTD({
    required String merchantId,
    required String branchId,
  }) async {
    try {
      // الحصول على التوكن الخاص بالمستخدم
      User? user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('User not authenticated');
      
      String? token = await user.getIdToken();
      
      // إرسال الطلب
      final response = await http.post(
        Uri.parse('$apiUrl/api/v1/discounts/generate-otd'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'merchantId': merchantId,
          'branchId': branchId,
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return OTDToken.fromJson(data['data']);
      } else {
        final error = jsonDecode(response.body);
        throw Exception(error['error'] ?? 'فشل توليد الكود');
      }
    } catch (e) {
      print('Error generating OTD: $e');
      rethrow;
    }
  }
}

/// Model لبيانات OTD Token
class OTDToken {
  final String otdToken;
  final String qrCodeData;
  final DateTime generatedAt;
  final DateTime expiresAt;
  final MerchantInfo merchantInfo;
  
  OTDToken({
    required this.otdToken,
    required this.qrCodeData,
    required this.generatedAt,
    required this.expiresAt,
    required this.merchantInfo,
  });
  
  factory OTDToken.fromJson(Map<String, dynamic> json) {
    return OTDToken(
      otdToken: json['otdToken'],
      qrCodeData: json['qrCodeData'],
      generatedAt: DateTime.parse(json['generatedAt']),
      expiresAt: DateTime.parse(json['expiresAt']),
      merchantInfo: MerchantInfo.fromJson(json['merchantInfo']),
    );
  }
  
  /// الوقت المتبقي
  Duration get remainingTime => expiresAt.difference(DateTime.now());
  
  /// هل ما زال صالحاً؟
  bool get isValid => DateTime.now().isBefore(expiresAt);
}

class MerchantInfo {
  final String name;
  final String branch;
  final int discount;
  
  MerchantInfo({
    required this.name,
    required this.branch,
    required this.discount,
  });
  
  factory MerchantInfo.fromJson(Map<String, dynamic> json) {
    return MerchantInfo(
      name: json['name'],
      branch: json['branch'] ?? '',
      discount: json['discount'],
    );
  }
}

/// شاشة عرض QR Code
class OTDDisplayScreen extends StatefulWidget {
  final String merchantId;
  final String branchId;
  
  const OTDDisplayScreen({
    required this.merchantId,
    required this.branchId,
  });
  
  @override
  _OTDDisplayScreenState createState() => _OTDDisplayScreenState();
}

class _OTDDisplayScreenState extends State<OTDDisplayScreen> {
  OTDToken? otdData;
  bool isLoading = true;
  String? error;
  
  late Timer _timer;
  Duration _remaining = Duration.zero;
  
  @override
  void initState() {
    super.initState();
    _generateOTD();
  }
  
  Future<void> _generateOTD() async {
    setState(() {
      isLoading = true;
      error = null;
    });
    
    try {
      OTDToken token = await OTDService.generateOTD(
        merchantId: widget.merchantId,
        branchId: widget.branchId,
      );
      
      setState(() {
        otdData = token;
        _remaining = token.remainingTime;
        isLoading = false;
      });
      
      // بدء المؤقت
      _startTimer();
    } catch (e) {
      setState(() {
        error = e.toString();
        isLoading = false;
      });
    }
  }
  
  void _startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (otdData == null) {
        timer.cancel();
        return;
      }
      
      setState(() {
        _remaining = otdData!.remainingTime;
        
        // إذا انتهت الصلاحية
        if (_remaining.isNegative || _remaining.inSeconds == 0) {
          timer.cancel();
          _showExpiredDialog();
        }
      });
    });
  }
  
  void _showExpiredDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text('⏰ انتهت صلاحية الكود'),
        content: Text('يمكنك توليد كود جديد للاستفادة من الخصم.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // إغلاق الـ Dialog
              Navigator.pop(context); // العودة للصفحة السابقة
            },
            child: Text('حسناً'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context); // إغلاق الـ Dialog
              _generateOTD(); // توليد كود جديد
            },
            child: Text('توليد كود جديد'),
          ),
        ],
      ),
    );
  }
  
  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('استخدم خصمك الآن'),
        backgroundColor: Colors.indigo,
      ),
      body: isLoading
        ? Center(child: CircularProgressIndicator())
        : error != null
          ? _buildErrorView()
          : _buildQRView(),
    );
  }
  
  Widget _buildErrorView() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 80, color: Colors.red),
            SizedBox(height: 20),
            Text(
              'حدث خطأ',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              error!,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey[600]),
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: _generateOTD,
              child: Text('حاول مرة أخرى'),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildQRView() {
    if (otdData == null) return SizedBox();
    
    // لون المؤقت يتغير مع الوقت
    Color timerColor = _remaining.inSeconds <= 10 ? Colors.red : Colors.blue;
    Color bgColor = _remaining.inSeconds <= 10 
      ? Colors.red.shade50 
      : Colors.blue.shade50;
    
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            // اسم التاجر
            Text(
              otdData!.merchantInfo.name,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            
            if (otdData!.merchantInfo.branch.isNotEmpty)
              Text(
                otdData!.merchantInfo.branch,
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
            
            SizedBox(height: 16),
            
            // نسبة الخصم
            Container(
              padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
              decoration: BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.circular(25),
              ),
              child: Text(
                'خصم ${otdData!.merchantInfo.discount}%',
                style: TextStyle(
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            
            SizedBox(height: 40),
            
            // QR Code
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 15,
                    offset: Offset(0, 5),
                  ),
                ],
              ),
              child: QrImageView(
                data: otdData!.qrCodeData,
                version: QrVersions.auto,
                size: 250.0,
                backgroundColor: Colors.white,
                errorCorrectionLevel: QrErrorCorrectLevel.H,
                embeddedImage: AssetImage('assets/logo.png'), // اختياري
                embeddedImageStyle: QrEmbeddedImageStyle(
                  size: Size(40, 40),
                ),
              ),
            ),
            
            SizedBox(height: 40),
            
            // المؤقت
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: bgColor,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  Text(
                    'الوقت المتبقي',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black54,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    '${_remaining.inSeconds}',
                    style: TextStyle(
                      fontSize: 72,
                      fontWeight: FontWeight.bold,
                      color: timerColor,
                    ),
                  ),
                  Text(
                    'ثانية',
                    style: TextStyle(
                      fontSize: 20,
                      color: timerColor,
                    ),
                  ),
                  
                  SizedBox(height: 15),
                  
                  // Progress Bar
                  LinearProgressIndicator(
                    value: _remaining.inSeconds / 60,
                    backgroundColor: Colors.grey[300],
                    valueColor: AlwaysStoppedAnimation<Color>(timerColor),
                    minHeight: 8,
                  ),
                ],
              ),
            ),
            
            SizedBox(height: 30),
            
            // تحذير
            if (_remaining.inSeconds <= 10)
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red[100],
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.red),
                ),
                child: Row(
                  children: [
                    Icon(Icons.warning, color: Colors.red),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        '⚠️ أسرع! الكود على وشك الانتهاء',
                        style: TextStyle(
                          color: Colors.red[900],
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            
            SizedBox(height: 20),
            
            // تعليمات
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                children: [
                  Icon(Icons.info_outline, color: Colors.indigo, size: 30),
                  SizedBox(height: 10),
                  Text(
                    'اطلب من أمين الصندوق مسح هذا الكود',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text(
                    '• هذا الكود صالح لمرة واحدة فقط\n'
                    '• لا تشارك هذه الشاشة مع أحد\n'
                    '• الكود سينتهي تلقائياً بعد 60 ثانية',
                    style: TextStyle(fontSize: 12, color: Colors.grey[700]),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// 3. تطبيق التاجر - ماسح QR Code والتحقق
// ═══════════════════════════════════════════════════════════════════

import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:geolocator/geolocator.dart';

/// خدمة التحقق من OTD (للتاجر)
class MerchantOTDService {
  static const String apiUrl = 'https://api.halab-discounts.com';
  
  /// التحقق من صحة الكود
  static Future<VerificationResult> verifyOTD({
    required String otdToken,
    required String branchId,
    double? originalAmount,
    Position? location,
  }) async {
    try {
      // الحصول على توكن التاجر
      User? user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Merchant not authenticated');
      
      String? token = await user.getIdToken();
      
      // إرسال الطلب
      final response = await http.post(
        Uri.parse('$apiUrl/api/v1/merchant/verify-otd'),
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'otdToken': otdToken,
          'branchId': branchId,
          'originalAmount': originalAmount,
          'location': location != null
            ? {
                'latitude': location.latitude,
                'longitude': location.longitude,
              }
            : null,
        }),
      );
      
      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200) {
        return VerificationResult.success(data['data']);
      } else {
        return VerificationResult.failure(
          data['error']['code'] ?? 'UNKNOWN_ERROR',
          data['error']['message'] ?? 'حدث خطأ غير معروف',
        );
      }
    } catch (e) {
      print('Error verifying OTD: $e');
      return VerificationResult.failure('NETWORK_ERROR', e.toString());
    }
  }
}

/// نتيجة التحقق
class VerificationResult {
  final bool isSuccess;
  final String? errorCode;
  final String? errorMessage;
  final VerificationData? data;
  
  VerificationResult.success(Map<String, dynamic> json)
    : isSuccess = true,
      errorCode = null,
      errorMessage = null,
      data = VerificationData.fromJson(json);
  
  VerificationResult.failure(this.errorCode, this.errorMessage)
    : isSuccess = false,
      data = null;
}

class VerificationData {
  final CustomerInfo customerInfo;
  final DiscountDetails discount;
  final String transactionId;
  final DateTime scannedAt;
  
  VerificationData({
    required this.customerInfo,
    required this.discount,
    required this.transactionId,
    required this.scannedAt,
  });
  
  factory VerificationData.fromJson(Map<String, dynamic> json) {
    return VerificationData(
      customerInfo: CustomerInfo.fromJson(json['customerInfo']),
      discount: DiscountDetails.fromJson(json['discount']),
      transactionId: json['transactionId'],
      scannedAt: DateTime.parse(json['scannedAt']),
    );
  }
}

class CustomerInfo {
  final String membershipId;
  final String fullName;
  final String? profilePhoto;
  final String memberSince;
  
  CustomerInfo({
    required this.membershipId,
    required this.fullName,
    this.profilePhoto,
    required this.memberSince,
  });
  
  factory CustomerInfo.fromJson(Map<String, dynamic> json) {
    return CustomerInfo(
      membershipId: json['membershipId'],
      fullName: json['fullName'],
      profilePhoto: json['profilePhoto'],
      memberSince: json['memberSince'],
    );
  }
}

class DiscountDetails {
  final int percentage;
  final double? discountAmount;
  final double? finalAmount;
  
  DiscountDetails({
    required this.percentage,
    this.discountAmount,
    this.finalAmount,
  });
  
  factory DiscountDetails.fromJson(Map<String, dynamic> json) {
    return DiscountDetails(
      percentage: json['percentage'],
      discountAmount: json['discountAmount']?.toDouble(),
      finalAmount: json['finalAmount']?.toDouble(),
    );
  }
}

/// شاشة مسح الكود (للتاجر)
class MerchantScannerScreen extends StatefulWidget {
  final String branchId;
  
  const MerchantScannerScreen({required this.branchId});
  
  @override
  _MerchantScannerScreenState createState() => _MerchantScannerScreenState();
}

class _MerchantScannerScreenState extends State<MerchantScannerScreen> {
  MobileScannerController cameraController = MobileScannerController();
  bool isProcessing = false;
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('مسح كود الخصم'),
        backgroundColor: Colors.indigo,
        actions: [
          IconButton(
            icon: Icon(Icons.flash_on),
            onPressed: () => cameraController.toggleTorch(),
          ),
          IconButton(
            icon: Icon(Icons.flip_camera_ios),
            onPressed: () => cameraController.switchCamera(),
          ),
        ],
      ),
      body: Stack(
        children: [
          // الكاميرا
          MobileScanner(
            controller: cameraController,
            onDetect: (capture) {
              if (!isProcessing && mounted) {
                final List<Barcode> barcodes = capture.barcodes;
                if (barcodes.isNotEmpty) {
                  final String? code = barcodes.first.rawValue;
                  if (code != null && code.startsWith('halab-discounts://redeem/')) {
                    _handleScannedCode(code);
                  }
                }
              }
            },
          ),
          
          // إطار التوجيه
          Center(
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white, width: 3),
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
          
          // التعليمات
          Positioned(
            bottom: 50,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.all(16),
              margin: EdgeInsets.symmetric(horizontal: 40),
              decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Text(
                'وجّه الكاميرا نحو QR Code',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),
            ),
          ),
          
          // مؤشر المعالجة
          if (isProcessing)
            Container(
              color: Colors.black54,
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(color: Colors.white),
                    SizedBox(height: 20),
                    Text(
                      'جاري التحقق...',
                      style: TextStyle(color: Colors.white, fontSize: 18),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
  
  Future<void> _handleScannedCode(String scannedCode) async {
    setState(() => isProcessing = true);
    
    try {
      // استخراج OTD Token من الرابط
      final uri = Uri.parse(scannedCode);
      final otdToken = uri.pathSegments.last;
      
      // الحصول على الموقع الحالي (اختياري)
      Position? position;
      try {
        position = await Geolocator.getCurrentPosition();
      } catch (e) {
        print('Could not get location: $e');
      }
      
      // إرسال الطلب للتحقق
      final result = await MerchantOTDService.verifyOTD(
        otdToken: otdToken,
        branchId: widget.branchId,
        location: position,
      );
      
      // إيقاف الكاميرا
      cameraController.stop();
      
      // عرض النتيجة
      if (result.isSuccess) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => VerificationSuccessScreen(data: result.data!),
          ),
        );
      } else {
        _showErrorDialog(result.errorMessage ?? 'حدث خطأ غير معروف');
      }
      
    } catch (e) {
      _showErrorDialog('حدث خطأ أثناء التحقق من الكود: $e');
    } finally {
      if (mounted) {
        setState(() => isProcessing = false);
      }
    }
  }
  
  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('❌ فشل التحقق'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              cameraController.start(); // إعادة تشغيل الكاميرا
            },
            child: Text('حاول مرة أخرى'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context); // العودة للشاشة السابقة
            },
            child: Text('إلغاء'),
          ),
        ],
      ),
    );
  }
  
  @override
  void dispose() {
    cameraController.dispose();
    super.dispose();
  }
}

/// شاشة نجاح التحقق (للتاجر)
class VerificationSuccessScreen extends StatelessWidget {
  final VerificationData data;
  
  const VerificationSuccessScreen({required this.data});
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // أيقونة النجاح
                Icon(
                  Icons.check_circle,
                  color: Colors.green,
                  size: 120,
                ),
                
                SizedBox(height: 30),
                
                // العنوان
                Text(
                  '✅ تم التحقق بنجاح!',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.green.shade800,
                  ),
                ),
                
                SizedBox(height: 40),
                
                // معلومات المشترك
                Container(
                  padding: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 10,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      // الصورة الشخصية
                      if (data.customerInfo.profilePhoto != null)
                        CircleAvatar(
                          radius: 50,
                          backgroundImage: NetworkImage(
                            data.customerInfo.profilePhoto!,
                          ),
                          onBackgroundImageError: (_, __) {},
                          child: data.customerInfo.profilePhoto == null
                            ? Icon(Icons.person, size: 50)
                            : null,
                        )
                      else
                        CircleAvatar(
                          radius: 50,
                          backgroundColor: Colors.indigo[100],
                          child: Icon(Icons.person, size: 50, color: Colors.indigo),
                        ),
                      
                      SizedBox(height: 16),
                      
                      // الاسم
                      Text(
                        data.customerInfo.fullName,
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      
                      SizedBox(height: 8),
                      
                      // رقم العضوية
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.indigo[50],
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          'عضو رقم: ${data.customerInfo.membershipId}',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.indigo[800],
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      
                      SizedBox(height: 4),
                      
                      Text(
                        'عضو منذ ${data.customerInfo.memberSince}',
                        style: TextStyle(color: Colors.grey),
                      ),
                      
                      Divider(height: 30),
                      
                      // الخصم
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'الخصم: ',
                            style: TextStyle(fontSize: 20),
                          ),
                          Text(
                            '${data.discount.percentage}%',
                            style: TextStyle(
                              fontSize: 48,
                              fontWeight: FontWeight.bold,
                              color: Colors.green,
                            ),
                          ),
                        ],
                      ),
                      
                      if (data.discount.discountAmount != null) ...[
                        SizedBox(height: 20),
                        Container(
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.green[50],
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('قيمة الخصم:', style: TextStyle(fontSize: 16)),
                                  Text(
                                    '${data.discount.discountAmount!.toStringAsFixed(0)} ل.س',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.green[800],
                                    ),
                                  ),
                                ],
                              ),
                              Divider(),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('المبلغ النهائي:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                                  Text(
                                    '${data.discount.finalAmount!.toStringAsFixed(0)} ل.س',
                                    style: TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.indigo,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                
                SizedBox(height: 40),
                
                // زر الإنهاء
                ElevatedButton(
                  onPressed: () => Navigator.popUntil(
                    context,
                    (route) => route.isFirst,
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(horizontal: 60, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    elevation: 5,
                  ),
                  child: Text(
                    'إنهاء',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// نهاية مكتبة الأكواد الأولية
// ═══════════════════════════════════════════════════════════════════
