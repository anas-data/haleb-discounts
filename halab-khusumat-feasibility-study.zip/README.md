# حلب خصومات — نظام العضوية والصلاحيات (نسخة تفاعلية)

> **دراسة جدوى إصدار 2.0 + تطبيق ويب تفاعلي كامل لاختبار رحلة العضوية، المصادقة، RBAC، أكواد OTD، الهدايا، وتطبيق التاجر ولوحة الإدارة.**

---

## ⚡ التشغيل

```bash
npm install
npm run dev      # بيئة التطوير
npm run build    # بناء الإنتاج (dist/index.html)
```

---

## 🎭 الحسابات التجريبية

| الدور | البريد | كلمة المرور | ما يراه |
|---|---|---|---|
| مدير المنصة | `admin@halab.com` | `admin123` | لوحة تحكم كاملة + مركز الجودة |
| تاجر (مطعم الأمير) | `merchant@halab.com` | `merchant123` | تطبيق الماسح وسجل المعاملات فقط |
| مشتركة نشطة | `sara@halab.com` | `123456` | خصومات حقيقية، OTD، الهدية، الحساب |
| حساب غير مشترك | `free@halab.com` | `free123` | الوضع المجاني + دعوة للاشتراك |
| زائر | — | — | تصفح أسماء الشركاء فقط، الخصم «؟» |

> يمكن أيضاً إنشاء حساب جديد، تأكيد البريد برمز العرض **123456**، شراء اشتراك عبر **دفع محاكى**، ثم اختيار الهدية الترحيبية (3 هدايا) واستخدام كود OTD واختباره في تطبيق التاجر.

---

## 🔐 مصفوفة الصلاحيات

| المسار | زائر | مشترك غير مدفوع | مشترك نشط | تاجر | مدير |
|---|---|---|---|---|---|
| الرئيسية والكتالوج | ✅ | ✅ | ✅ | ❌ | ✅ |
| تفاصيل الشريك | ✅ | ✅ | ✅ | ❌ | ✅ |
| رؤية نسبة الخصم | ❌ «؟» | ❌ «؟» | ✅ | — | ✅ |
| صفحة الاشتراك | ✅ | ✅ | ✅ | ❌ | ✅ |
| الهدية الترحيبية | ❌ | ❌ | ✅ (مرة واحدة) | ❌ | ✅ |
| كود OTD | ❌ | ❌ | ✅ (60 ثانية) | — | ✅ |
| تطبيق المسح | ❌ | ❌ | ❌ | ✅ | ✅ (للفحص) |
| لوحة التحكم / مركز الجودة | ❌ | ❌ | ❌ | ❌ | ✅ |

---

## 🧪 الاختبارات

- **31/31 اختباراً منطقياً** لدوال OTD والصلاحيات والعضوية والبيانات (تم تشغيلها فعلياً خارجياً).
- **23 اختباراً داخل التطبيق** في **مركز الجودة** داخل لوحة المدير (يتحدّث حسب البيانات الحالية).
- **12 خطوة UAT يدوية** قابلة للتأشير داخل المركز.
- فحص TypeScript: `npx tsc --noEmit` بدون أخطاء.
- بناء إنتاجي: `npm run build` ناجح.

التفاصيل: [`QA_AUTH_RBAC_REPORT.md`](./QA_AUTH_RBAC_REPORT.md).

---

## 📦 المخرجات التقنية المرافقة

```
haleb_discounts/                 # مشروع Flutter (Scaffold جاهز)
├── lib/services/auth_service.dart
├── lib/providers/auth_provider.dart
├── lib/main.dart                # AuthGate + توجيه حسب الدور
└── lib/ui/user/                 # welcome / login / register / forgot
    ├── home_page.dart           # العرض المزدوج (خَصم أم «؟»)
    └── merchant_details_page.dart
functions/src/index.ts           # verifyOtdCode / recordTransaction / checkExpiredSubscriptions
firestore.rules                  # قواعد RBAC النهائية
storage.rules
firebase.json
.github/workflows/deploy.yml     # CI/CD لبناء الويب ونشر Functions/Rules/Hosting
DEPLOY_WEB.md
DEPLOY_FUNCTIONS.md
```

بقية الدراسات (التقنية، التسويقية، المالية، UX) موجودة في:
`technical-specs/`, `implementation-plan/`, `business-model/`, `ux-design/`, `EXECUTIVE_SUMMARY.md`.

---

## 🧱 التقنيات

- **النسخة التفاعلية الحالية:** React 18 + TypeScript + Tailwind CSS + Lucide + qrcode.react، وتخزين الحالة في `localStorage` لمحاكاة Firestore أثناء العرض.
- **الإنتاج المستهدف:** Flutter + Firebase (Auth / Firestore / Functions / Hosting) وفق دراسة الجدوى.

> **تنبيه:** الاشتراك والدفع والتحقق من OTD في هذه النسخة **محاكاة آمنة للعرض**. التكامل الحقيقي مع Firebase موجود في ملفات `functions/`, `firestore.rules`, ومشروع Flutter، ويحتاج فقط بيانات مشروع Firebase وصلاحيات النشر.

---

© 2026 حلب خصومات — جميع الحقوق محفوظة.
