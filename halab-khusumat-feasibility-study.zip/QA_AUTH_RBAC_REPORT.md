# ✅ تقرير الاختبار والجاهزية — المصادقة والصلاحيات والنشر

**المشروع:** حلب خصومات — إصدار 2.0  
**النطاق:** إعادة تصميم تسجيل الدخول · RBAC · التحزيم والنشر  
**التاريخ:** مايو 2026

---

## 1. ما تم تنفيذه

### أ) رحلة المصادقة (4 شاشات)
| الشاشة | المسار في الويب | مكافئ Flutter |
|---|---|---|
| الترحيب | `route = welcome` | `lib/ui/user/welcome_page.dart` |
| تسجيل الدخول | `login` | `login_page.dart` |
| إنشاء حساب + التحقق | `register` | `register_page.dart` |
| نسيت كلمة المرور | `forgot` | `forgot_password_page.dart` |

- إنشاء حساب جديد يبدأ بعضوية **غير مدفوعة** (`isSubscriber = false`).
- تأكيد البريد برمز عرض `123456` قبل تفعيل الدخول.
- بعد الدخول: مشترك نشط → الرئيسية، غير مدفوع → صفحة الاشتراك، تاجر → الماسح، مدير → لوحة التحكم.
- معالجة أخطاء واضحة: بريد مسجّل، كلمة مرور خاطئة، حساب غير مفعّل، شبكة.

### ب) نظام الأدوار RBAC
- الأدوار: `anonymous` / `subscriber` / `merchant` / `admin`.
- الزائر يرى أسماء الشركاء و«؟» فقط، ولا يظهر له زر الحصول على الخصم.
- المشترك يرى النسب، OTD، الهدية، سجل التوفير.
- التاجر لا يستطيع فتح تطبيق المستخدم — يُعاد توجيهه للماسح.
- المدير فقط يصل إلى لوحة التحكم ومركز الجودة.
- إدارة الأدوار من لوحة المدير + قواعد Firestore للأمان على الخادم.
- نسبة الخصم: يعرضها التطبيق للمشترك النشط، وتُعاد من Cloud Function في الإنتاج (Firestore لا يسمح بإخفاء حقل مفرد).

### ج) التحزيم والنشر
- `firebase.json` (Hosting + rewrites + functions + firestore + storage).
- `firestore.rules` و`storage.rules`.
- `functions/src/index.ts`: `verifyOtdCode`, `recordTransaction`, `checkExpiredSubscriptions`, `setUserRole`.
- `DEPLOY_WEB.md` (Firebase Hosting + Apache/Nginx + base href + فحص ما بعد النشر).
- `DEPLOY_FUNCTIONS.md` (بناء، نشر، متغيرات، مراقبة، Rollback).
- `.github/workflows/deploy.yml` (بناء Flutter Web، نشر Functions/Rules/Hosting، فحص إنتاجي).

---

## 2. الاختبارات المنفّذة

### الاختبارات الآلية الخارجية — 31/31 ✅

```
PASS — OTD code is 6 digits
PASS — OTD rotates every 60s window
PASS — OTD is merchant-scoped
PASS — remaining seconds within 1..60
PASS — valid OTD accepted for active subscriber
PASS — tampered OTD rejected
PASS — expired-window OTD rejected
PASS — active subscriber sees real discount
PASS — guest sees masked discount
PASS — free/expired user sees masked discount
PASS — anonymous blocked from admin
PASS — subscriber blocked from admin
PASS — merchant blocked from admin
PASS — admin allowed admin
PASS — merchant blocked from home
PASS — merchant allowed merchantApp
PASS — anonymous blocked from OTD
PASS — subscriber allowed OTD
PASS — public welcome allowed to anonymous
PASS — gift claim requires active + unclaimed
PASS — at least 3 gift options
PASS — active subscription validity
PASS — admin can be active subscriber (demo)
PASS — annual plan cheaper per month
PASS — discount math 20% of 12000
PASS — merchants discounts in 10..30 and branches>0
PASS — transactions have 6-digit codes & positive amounts
PASS — all four roles represented
PASS — category taxonomy complete
PASS — membership ids unique
PASS — merchant filtering by owner works (m1 only)

TOTAL: 31 passed, 0 failed, 31 tests
```

### اختبارات داخلية — 23 اختباراً في «مركز الجودة»
متاحة داخل حساب المدير → تبويب **مركز الجودة**، وتغطي:
- OTD: 6 أرقام، التدوير، ربط الكود بالتاجر، النافذة الزمنية، رفض التعديل، رفض النافذة القديمة.
- الصلاحيات: الخصم للمشترك، «؟» للزائر، حجب غير النشط، وصول المدير فقط، منع التاجر، حماية OTD، تصفية معاملات التاجر.
- العضوية: الهدية مرة واحدة، 3 خيارات، صلاحية الأيام، رفض العملية بعد الانتهاء، تسعير الباقات.
- البيانات: حساب الخصم، نطاق النسب، سلامة المعاملات، الأدوار الأربعة، حالة الدخول.

### فحص ثابت
```
npx tsc --noEmit   → 0 errors
npm run build      → success (dist/index.html)
```

### UAT اليدوي (12 خطوة)
موجودة كقائمة تفاعلية في مركز الجودة. المسار:
1. شاشة الترحيب → 2. تصفح زائر → 3. حجب النسبة → 4. إنشاء حساب → 5. تحقق `123456` → 6. باقة + دفع محاكى → 7. هدية واحدة → 8. تفاصيل تاجر → 9. كود OTD + مؤقت → 10. دخول التاجر → 11. مسح وتحقق → 12. لوحة المدير.

---

## 3. قيود النسخة والانتقال للإنتاج

| العنصر | النسخة التفاعلية | الإنتاج |
|---|---|---|
| المصادقة | محاكاة + `localStorage` | Firebase Auth (Email/Password + التحقق) |
| قاعدة البيانات | حالة محلية | Firestore + قواعد `firestore.rules` |
| OTD | TOTP مبسّط (FNV) للعرض | TOTP حقيقي بـ `speakeasy` على الخادم + `otp` في Flutter |
| الدفع | محاكاة | بوابة دفع محلية |
| الإشعارات | Toast | FCM + Geofencing |
| النشر | — | Firebase Hosting + Functions (يتطلب بيانات المشروع) |

> لم يتم رفع نسخة إلى Firebase فعلياً لعدم توفر بيانات اعتماد المشروع في الجلسة. جميع ملفات البناء والنشر جاهزة ومُختبرة محلياً.

---

## 4. Checklist الإطلاق

- [x] شاشات المصادقة الأربع + التحقق.
- [x] توجيه حسب الدور والاشتراك (AuthGate/RoleGuard).
- [x] حجب الخصومات في الوضع المجاني.
- [x] الهدية الترحيبية لمرة واحدة.
- [x] كود OTD + مؤقت 60 ثانية + منع التكرار.
- [x] تطبيق التاجر للتحقق والتسجيل.
- [x] لوحة إدارة + تقارير CSV + إدارة شركاء وإعلانات.
- [x] اختبارات آلية ناجحة 31/31.
- [x] قواعد Firestore وStorage.
- [x] Cloud Functions + نشر موثّق.
- [x] CI/CD عبر GitHub Actions.
- [ ] إدخال مفاتيح Firebase الحقيقية و`FIREBASE_SERVICE_ACCOUNT`.
- [ ] منح Custom Claims للأدمن.
- [ ] تفعيل App Check قبل الإطلاق العام.

---

© 2026 حلب خصومات — تقرير الاختبار والجاهزية.
